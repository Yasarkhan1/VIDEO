import { getForm, postForm, patchForm, deleteForm, postByFormData, patchByFormData } from "../apiConfig";
import { toast } from "react-toastify";
import { getSessionStorageOrDefault } from "../utils";

class authenticationServices {

  async checkEmailIdExit(data) {
    try {
      const response = await postForm("checkEmailIdExit", data, "");
      return response;
    } catch (err) {
      toast.error(err.response.data.responseMessage, {
        position: toast.POSITION.TOP_RIGHT,
      });
      return err.response;
    }
  }


  async patientSignup(data) {
    try {
      const response = await postByFormData("patients/create", data, "");
      return response;
    } catch (err) {
      console.log("error===--patientSignup-");
      toast.error(err.response.data.responseMessage, {
        position: toast.POSITION.TOP_RIGHT,
      });
      return err.response;
    }
  }

  async patientLogin(data) {
    try {
      const response = await postForm("patients/login", data, "");

      return response;
    } catch (err) {
      console.log("catch errro==1", err);
      toast.error(err.response.data.responseMessage, {
        position: toast.POSITION.TOP_RIGHT,
      });
      return err.response;
    }
  }

  async patientUpdate(data) {
    try {
      const response = await patchByFormData(`patients/updateProfile`, data, "token");

      return response;
    } catch (err) {
      toast.error(err.response.data.responseMessage, {
        position: toast.POSITION.TOP_RIGHT,
      });
      return err.response;
    }
  }

  async appointmentBook(data, stepNumber) {
    try {
      const response = await patchForm(`appointmentBook?step=${stepNumber}`, data, "token");

      return response;
    } catch (err) {
      toast.error(err.response.data.responseMessage, {
        position: toast.POSITION.TOP_RIGHT,
      });
      return err.response;
    }
  }

  async appointmentBookStep6(data) {
    try {
      const response = await patchByFormData(`appointmentBook?step=6`, data, "token");

      return response;
    } catch (err) {
      toast.error(err.response.data.responseMessage, {
        position: toast.POSITION.TOP_RIGHT,
      });
      return err.response;
    }
  }

  async addCardDetails(data) {
    try {
      const response = await patchForm(`add-card-details`, data, "token");

      return response;
    } catch (err) {
      toast.error(err.response.data.responseMessage, {
        position: toast.POSITION.TOP_RIGHT,
      });
      return err.response;
    }
  }

  async patientForgetPassword(data) {
    try {
      const response = await postForm("forgetPassword", data, "");

      return response;
    } catch (err) {
      toast.error(err.response.data.responseMessage, {
        position: toast.POSITION.TOP_RIGHT,
      });
      return err.response;
    }
  }

  async getAllcountry() {
    try {
      const response = await getForm(`getAllcountry`, "");
      return response;
    } catch (err) {
      toast.error(err.response.data.responseMessage, {
        position: toast.POSITION.TOP_RIGHT,
      });
      return err.response;
    }
  }

  async dropdownOptions() {
    try {
      const response = await getForm(`dropdownOptions`, "");
      return response;
    } catch (err) {
      toast.error(err.response.data.responseMessage, {
        position: toast.POSITION.TOP_RIGHT,
      });
      return err.response;
    }
  }

  async getAggrement(data) {
    try {
      const response = await postForm(`getAggrement`, data, "");
      return response;
    } catch (err) {
      toast.error(err.response.data.responseMessage, {
        position: toast.POSITION.TOP_RIGHT,
      });
      return err.response;
    }
  }

  async getPetientDetails() {
    try {
      const response = await getForm(`patients/getPatientDetails`, "token");
      return response;
    } catch (err) {
      toast.error(err.response.data.responseMessage, {
        position: toast.POSITION.TOP_RIGHT,
      });
      return err.response;
    }
  }

  async getAllAppointments() {
    try {
      const response = await getForm(`getAllAppointment`, "token");
      return response;
    } catch (err) {
      toast.error(err.response.data.responseMessage, {
        position: toast.POSITION.TOP_RIGHT,
      });
      return err.response;
    }
  }

  async getAllCard() {
    try {
      const response = await getForm(`patients/getAllCard`, "token");
      return response;
    } catch (err) {
      toast.error(err.response.data.responseMessage, {
        position: toast.POSITION.TOP_RIGHT,
      });
      return err.response;
    }
  }

  async getAllAppointmentByID(id) {
    try {
      const response = await getForm(`appointment/${id}`, "token");
      return response;
    } catch (err) {
      toast.error(err.response.data.responseMessage, {
        position: toast.POSITION.TOP_RIGHT,
      });
      return err.response;
    }
  }

  async patientResetpassword(data) {
    try {
      const response = await postForm("resetPassword", data, "");

      return response;
    } catch (err) {
      toast.error(err.response.data.responseMessage, {
        position: toast.POSITION.TOP_RIGHT,
      });
      return err.response;
    }
  }


  async verifyOtp(data) {
    try {
      const response = await postForm("verifyOTP", data, "");

      return response;
    } catch (err) {
      toast.error(err.response.data.responseMessage, {
        position: toast.POSITION.TOP_RIGHT,
      });
      return err.response;
    }
  }


  async getTwilioToken(data) {
    try {
      const response = await postForm(`call/getTwilioToken`, data, "token");
      return response;
    } catch (err) {
      toast.error(err.response.data.responseMessage, {
        position: toast.POSITION.TOP_RIGHT,
      });
      return err.response;
    }
  }

  async callDisconnect(data) {
    try {
      const response = await postForm(`call/callDisconnect`, data, "token");
      return response;
    } catch (err) {
      toast.error(err.response.data.responseMessage, {
        position: toast.POSITION.TOP_RIGHT,
      });
      return err.response;
    }
  }

  async getPetientFaq() {
    try {
      const response = await getForm(`faq/getDetails`, "token");
      return response;
    } catch (err) {
      toast.error(err.response.data.responseMessage, {
        position: toast.POSITION.TOP_RIGHT,
      });
      return err.response;
    }
  }

  async getMessageWithCPN() {
    try {
      const response = await getForm(`cpn/getMessageWithCPN`, "token");
      return response;
    } catch (err) {
      toast.error(err.response.data.responseMessage, {
        position: toast.POSITION.TOP_RIGHT,
      });
      return err.response;
    }
  }

  async bookingCancellation(data) {
    try {
      const response = await postForm(`patients/bookingCancellation`, data, "token");
      return response;
    } catch (err) {
      toast.error(err.response.data.responseMessage, {
        position: toast.POSITION.TOP_RIGHT,
      });
      return err.response;
    }
  }

  async getEcDertailsById(id) {
    try {
      const response = await getForm(`admin/consultant/${id}`, "");
      return response;
    } catch (err) {
      toast.error(err.response.data.responseMessage, {
        position: toast.POSITION.TOP_RIGHT,
      });
      return err.response;
    }
  }

}


export default new authenticationServices();
