import { getForm, postForm, patchForm, deleteForm, postByFormData, patchByFormData } from "../apiConfig";
import { toast } from "react-toastify";
import { getSessionStorageOrDefault } from "../utils";

class authenticationCpnIsServices {

    async checkEmailIdExit(data) {
        try {
            const response = await postForm("checkEmailIdExit", data, "");
            return response;
        } catch (err) {
            toast.error(err.response.data.responseMessage, {
                position: toast.POSITION.TOP_RIGHT,
            });
            return err.response;
        }
    }


    async cpnSignup(data) {
        try {
            const response = await postForm("cpn/create", data, "");
            return response;
        } catch (err) {
            toast.error(err.response.data.responseMessage, {
                position: toast.POSITION.TOP_RIGHT,
            });
            return err.response;
        }
    }

    async cpnLogin(data) {
        try {
            const response = await postForm("cpn/login", data, "");

            return response;
        } catch (err) {
            toast.error(err.response.data.responseMessage, {
                position: toast.POSITION.TOP_RIGHT,
            });
            return err.response;
        }
    }

    async cpnForgetPassword(data) {
        try {
            const response = await postForm("cpn/forgetPassword", data, "");
            return response;
        } catch (err) {
            toast.error(err.response.data.responseMessage, {
                position: toast.POSITION.TOP_RIGHT,
            });
            return err.response;
        }
    }

    async cpnResetpassword(data) {
        try {
            const response = await postForm("cpn/resetPassword", data, "");

            return response;
        } catch (err) {
            toast.error(err.response.data.responseMessage, {
                position: toast.POSITION.TOP_RIGHT,
            });
            return err.response;
        }
    }

    async cpnSeheduleAppointment(data) {
        try {
            const response = await patchByFormData("cpn/seheduleAppointment", data, "token");
            return response;
        } catch (err) {
            toast.error(err.response.data.responseMessage, {
                position: toast.POSITION.TOP_RIGHT,
            });
            return err.response;
        }
    }

    async getCpnDetails() {
        try {
            const response = await getForm(`cpn/getDetails`, "token");
            return response;
        } catch (err) {
            toast.error(err.response.data.responseMessage, {
                position: toast.POSITION.TOP_RIGHT,
            });
            return err.response;
        }
    }

    async getAllNewAppointment(page, appointmentsPerPage) {
        try {
            const response = await getForm(`cpn/getAllAppointment?page=${page}&pageSize=${appointmentsPerPage}&status=requested`, "token");
            return response;
        } catch (err) {
            toast.error(err.response.data.responseMessage, {
                position: toast.POSITION.TOP_RIGHT,
            });
            return err.response;
        }
    }

    async getAllScheduledAppointment(page, appointmentsPerPage) {
        try {
            const response = await getForm(`cpn/getAllAppointment?page=${page}&pageSize=${appointmentsPerPage}&status=scheduled`, "token");
            return response;
        } catch (err) {
            toast.error(err.response.data.responseMessage, {
                position: toast.POSITION.TOP_RIGHT,
            });
            return err.response;
        }
    }

    async getAllExpert() {
        try {
            const response = await getForm(`admin/getAllDoctors`, "token");
            return response;
        } catch (err) {
            toast.error(err.response.data.responseMessage, {
                position: toast.POSITION.TOP_RIGHT,
            });
            return err.response;
        }
    }

    async getAppointmentDetailsByID(id) {
        try {
            const response = await getForm(`appointment/${id}`, "token");
            return response;
        } catch (err) {
            toast.error(err.response.data.responseMessage, {
                position: toast.POSITION.TOP_RIGHT,
            });
            return err.response;
        }
    }

    async getSlotById(EcId, date) {
        try {
            const response = await getForm(`cpn/getSlot?userId=${EcId}&bookingDate=${date}`, "token");
            return response;
        } catch (err) {
            toast.error(err.response.data.responseMessage, {
                position: toast.POSITION.TOP_RIGHT,
            });
            return err.response;
        }
    }

    async cpnUpdate(data) {
        try {
            const response = await patchByFormData(`cpn/updateProfile`, data, "token");

            return response;
        } catch (err) {
            toast.error(err.response.data.responseMessage, {
                position: toast.POSITION.TOP_RIGHT,
            });
            return err.response;
        }
    }

    async sendMessageWithExpert(data) {
        try {
            const response = await postForm("inqury/sendMessageWithExpert", data, "");

            return response;
        } catch (err) {
            toast.error(err.response.data.responseMessage, {
                position: toast.POSITION.TOP_RIGHT,
            });
            return err.response;
        }
    }

    async sendMessageWithPatient(data) {
        try {
            const response = await postForm("inqury/sendMessageWithPatient", data, "");

            return response;
        } catch (err) {
            toast.error(err.response.data.responseMessage, {
                position: toast.POSITION.TOP_RIGHT,
            });
            return err.response;
        }
    }


    async getMessageWithCPN() {
        try {
            const response = await getForm(`cpn/getMessageWithCPN`, "token");
            return response;
        } catch (err) {
            toast.error(err.response.data.responseMessage, {
                position: toast.POSITION.TOP_RIGHT,
            });
            return err.response;
        }
    }

    async getExpertWithCPN() {
        try {
            const response = await getForm(`cpn/getAllMessageCPN`, "token");
            return response;
        } catch (err) {
            toast.error(err.response.data.responseMessage, {
                position: toast.POSITION.TOP_RIGHT,
            });
            return err.response;
        }
    }

}

export default new authenticationCpnIsServices();
