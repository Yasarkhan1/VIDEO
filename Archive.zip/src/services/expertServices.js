import { getForm, postForm, patchForm, deleteForm, postByFormData, patchByFormData } from "../apiConfig";
import { toast } from "react-toastify";
import { getSessionStorageOrDefault } from "../utils";

class authenticationExpertServices {

    async checkEmailIdExit(data) {
        try {
            const response = await postForm("checkEmailIdExit", data, "");
            return response;
        } catch (err) {
            toast.error(err.response.data.responseMessage, {
                position: toast.POSITION.TOP_RIGHT,
            });
            return err.response;
        }
    }


    async expertSignup(data) {
        try {
            const response = await postByFormData("consultant/create", data, "");
            return response;
        } catch (err) {
            console.log("error===--expertSignup-");
            toast.error(err.response.data.responseMessage, {
                position: toast.POSITION.TOP_RIGHT,
            });
            return err.response;
        }
    }

    async expertLogin(data) {
        try {
            const response = await postForm("consultant/login", data, "");

            return response;
        } catch (err) {
            console.log("catch errro==1", err);
            toast.error(err.response.data.responseMessage, {
                position: toast.POSITION.TOP_RIGHT,
            });
            return err.response;
        }
    }

    async expertResetPassword(data) {
        try {
            const response = await postForm("consultant/resetPassword", data, "");

            return response;
        } catch (err) {
            console.log("catch errro==1", err);
            toast.error(err.response.data.responseMessage, {
                position: toast.POSITION.TOP_RIGHT,
            });
            return err.response;
        }
    }

    async expertForgetPassword(data) {
        try {
            const response = await postForm("consultant/forgetPassword", data, "");

            return response;
        } catch (err) {
            console.log("catch errro==1", err);
            toast.error(err.response.data.responseMessage, {
                position: toast.POSITION.TOP_RIGHT,
            });
            return err.response;
        }
    }

    async updateAvailability(data) {
        try {
            const response = await postForm("consultant/updateAvailability", data, "token");

            return response;
        } catch (err) {
            console.log("catch errro==1", err);
            toast.error(err.response.data.responseMessage, {
                position: toast.POSITION.TOP_RIGHT,
            });
            return err.response;
        }
    }

    async getConsultantDetails() {
        try {
            const response = await getForm("consultant/getConsultantDetails", "token");
            return response;
        } catch (err) {
            toast.error(err.response.data.responseMessage, {
                position: toast.POSITION.TOP_RIGHT,
            });
            return err.response;
        }
    }

    async getAllSurvey() {
        try {
            const response = await getForm(`getAllSurvey`, "token");
            return response;
        } catch (err) {
            toast.error(err.response.data.responseMessage, {
                position: toast.POSITION.TOP_RIGHT,
            });
            return err.response;
        }
    }



}

export default new authenticationExpertServices();
