// import logo from './logo.svg';
import './App.css';
import React, { useEffect, lazy, Suspense, useState } from 'react';
import { Route, Routes, useLocation, useNavigate } from 'react-router-dom';
import PageNotFound from './components/pages/PageNotFound/PageNotFound';
import publicRoutes from './routerManagement/publicRoutes';
import { getSessionStorageOrDefault } from "./utils";
import SpinnerLoader from './components/common/Spinner';
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import privateRoutes from './routerManagement/privateRoutes';
import RouterManagement from './routerManagement';
import getDeviceToken from "./getDeviceToken";
function App() {
  const navigate = useNavigate()
  const location = useLocation()
  const [isLogin, setIsLogin] = useState(false)

  // function to get all the public routes
  const renderPublicRoutes = () => {
    return publicRoutes.map((data, index) => {
      return <Route {...data} key={index} />;
    });
  };

  useEffect(() => {
    getDeviceToken(navigate);
    checkNotificationPermission();
    // checkLocationPermission();
  }, []);

  const checkNotificationPermission = async () => {
    return navigator.permissions
      .query({ name: 'notifications' })
      .then(permissionQuery)
      .catch((error) => {
        console.log("Error info", error);
      });
  }

  function permissionQuery(result) {
    console.debug('permissions query===>>', { result });
    var newPrompt;

    if (result.state == 'granted') {
      // notifications allowed, go wild

    } else if (result.state == 'prompt') {
      // we can ask the user

      newPrompt = Notification.requestPermission();

    } else if (result.state == 'denied') {
      // notifications were disabled;
      window.confirm("Please enable notfication to use all features of web")
    }

    result.onchange = () => console.debug({ updatedPermission: result });

    return newPrompt || result;
  }

  // function to get all the private routes
  const renderPrivateRoutes = () => {
    return privateRoutes.map((data, index) => {
      return <Route {...data} key={index} />;
    });
  };

  // useEffect to prevent unauthorize access
  useEffect(() => {
    const token = sessionStorage.getItem("token");
    if (!token) {
      if (
        privateRoutes.filter((route) => route.path == location.pathname).length > 0 &&
        privateRoutes.filter((route) => route.path == location.pathname)?.[0].authorized
      ) {
        navigate("/")
        setIsLogin(true)
      }
    }

  }, [location])

  //   window.onbeforeunload = function() {
  //    localStorage.clear();
  // }

  useEffect(() => {
    if (sessionStorage.getItem("token")) {
      setIsLogin(true)
    } else {
      setIsLogin(false)

    }
  }, [sessionStorage.getItem("token")])


  return (
    <div className="App">
      <ToastContainer />
      <Suspense fallback={<SpinnerLoader />}>
        <Routes>
          {isLogin ? renderPrivateRoutes() : renderPublicRoutes()}
        </Routes>
      </Suspense>
    </div>
  );
}

export default App;