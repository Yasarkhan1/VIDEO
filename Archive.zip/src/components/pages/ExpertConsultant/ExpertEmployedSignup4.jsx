import React, { useState, useEffect, useRef } from 'react'
import { FormGroup, Input, Label, Form, FormText, Button, Progress, Row, Col } from 'reactstrap';
import tick from "../../../assests/images/check-circle-svgrepo-com (2).svg";
import blueTick from "../../../assests/images/blue-tick.svg";
import cpnLogo from "../../../assests/images/CPNHealthFINAL_fontembed.svg";
import { ReactComponent as CrossIcon } from "../../../assests/images/close-circle-svgrepo-com.svg";
import calenderImg from "../../../assests/images/calender-svgrepo-com.svg";
import Footer from '../../common/Footer/Footer';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { useFormik } from "formik";
import * as Yup from "yup";
import { checkSpace } from "../../../utils";
import dayjs from "dayjs";
import { toast } from "react-toastify";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import e from 'cors';
import { async } from 'q';
import authenticationServices from "../../../services";

function ExpertEmployedSignup4() {


    const navigate = useNavigate()
    const location = useLocation()
    // console.log("useLocation_+_+_", location.state?.previousStepPayload);
    const previousStepPayload = location?.state?.previousStepPayload
    const profileImage = location?.state?.profileImage
    const [IsLoader, setIsLoader] = useState(false);
    const [dropDownData, setdropdownData] = useState([]);
    const [empCountryCode, setempCountryCode] = useState('');

    useEffect(() => {
        const step1Data = localStorage.getItem("expertSignupData")
            ? JSON.parse(localStorage.getItem("expertSignupData"))
            : "";
        const { email, password } = step1Data
        if (!email || !password) {
            // navigate('/signup-as-expert-5')
        } else {
            getPatchform();
        }
    }, [])

    // fill data in fields after back.
    const getPatchform = () => {
        const curretStepData = localStorage.getItem("expertSignupData")
            ? JSON.parse(localStorage.getItem("expertSignupData"))
            : "";
        // console.log("step2Data++++", step2Data);
        const { name, address, contactNumber } = curretStepData
        if (name) {
            formik.setValues({
                employerName: curretStepData?.employerName,
                employerAddress: curretStepData?.employerAddress,
                employerContactNumber: curretStepData?.employerContactNumber,
                employerEmail: curretStepData?.employerEmail,
                employerFax_number: curretStepData?.employerFax_number,
                current_role: curretStepData?.current_role,
                area_expertise: curretStepData?.area_expertise,
                web_profile: curretStepData?.web_profile,
                professional_fees: curretStepData?.professional_fees,
            });
        }
    };

    const formik = useFormik({
        initialValues: {
            employerName: "",
            employerAddress: "",
            employerContactNumber: "",
            employerEmail: "",
            employerFax_number: "",
            current_role: "",
            area_expertise: "",
            web_profile: "",
            professional_fees: "",

        },
        validationSchema: Yup.object({
            employerName: Yup.string().required("*Employer Name is required."),
            employerAddress: Yup.string().required("*Employer Address is required."),
            employerContactNumber: Yup.string().required("*Contact number is required."),
            employerFax_number: Yup.string().required("*Fax number is required."),
            employerEmail: Yup.string().required("*Email Address is required."),
            current_role: Yup.string().required("*Current Role is required."),
            area_expertise: Yup.string().required("*Area of Expertise is required."),
            web_profile: Yup.string().required("*Web Profile is required."),
            professional_fees: Yup.string().required("*Professional Fees is required."),


        }),

        onSubmit: async (values) => {
            const previousStepPayload = localStorage.getItem("expertSignupData")
                ? JSON.parse(localStorage.getItem("expertSignupData"))
                : "";
            const { email, password } = previousStepPayload

            const payload = {
                ...previousStepPayload,
                ...values,
                empCountryCode
            };

            try {
                console.log("patient details payload=", payload, JSON.stringify(payload));
                localStorage.setItem("expertSignupData", JSON.stringify(payload));
                navigate("/signup-as-expert-5", { state: { previousStepPayload: payload, profileImage: profileImage } })
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        }
    });

    // console.log("empCountryCode", empCountryCode);
    const handleMobileChange = (value, data) => {
        console.log("Dfdata.dialCode", data.dialCode);
        setempCountryCode(data.dialCode)
        formik.setFieldValue("employerContactNumber", value)

    }

    return (
        <>
            <div className='expert-employed-signup-4'>
                <div className="container">
                    <div className="logo-container">
                        <div className="logo-cpn">
                            <img src={cpnLogo} alt="Logo" />
                        </div>
                        <div className="login-button">
                            <Link to="/login-as-patient">
                                <Button>
                                    Login
                                </Button>
                            </Link>
                        </div>
                    </div>
                    <div className="otp-input">

                        <Progress multi>
                            <Progress
                                bar
                                value="33.33"
                                style={{
                                    height: '5px'
                                }}
                            />
                            <Progress
                                bar
                                color="success"
                                value="33.33"

                            />
                            <Progress
                                bar
                                color="info"
                                value="33.33"

                            />
                        </Progress>
                    </div>
                    <div className="text-sign-up">
                        <h1>Sign Up as a Expert Consultants</h1>
                    </div>

                    <div className="text-sign-up-2">
                    <img src={tick} alt="" />
                                <h1>Employment Details</h1>
                    </div>
                </div>
                <div className="container">
                    <div className="content-date">
                        <div className="login-detail">
                            <div className="login-detail-img">
                                <img src={tick} alt="" />
                                <h1>Login Details</h1>
                            </div>
                            <div className="login-detail-img2-data">
                                <img src={tick} alt="" />
                                <h1>Personal Details</h1>
                            </div>
                            <div className="login-detail-img2-data">
                                <img src={tick} alt="" />
                                <h1>Professional Details</h1>
                            </div>
                            <div className="login-detail-img2-data" >
                                <img src={tick} alt="" />
                                <h1>Employment Details</h1>
                            </div>
                            <div className="login-detail-img2-data" style={{ opacity: '0.32' }}>
                                <img src={tick} alt="" />
                                <h1>Availability & Payment Method</h1>
                            </div>
                            <div className="login-detail-img2-data" style={{ opacity: '0.32' }}>
                                <img src={tick} alt="" />
                                <h1>Upload W-9</h1>
                            </div>
                            <div className="login-detail-img3-data">
                                <img src={tick} alt="" />
                                <h1>Sign HIPAA/GDPR Agreement & CPN Agreement</h1>

                            </div>
                        </div>
                        <div className="form-data-container">
                            <Form onSubmit={formik.handleSubmit}>

                                <FormGroup>
                                    <Label>
                                        Employer Name
                                    </Label>
                                    <Input
                                        id='exampletext'
                                        type='text'
                                        name='employerName'
                                        placeholder='Enter Employer Name'
                                        {...formik.getFieldProps("employerName")}
                                        className={formik.touched.employerName && formik.errors.employerName ? 'is-invalid' : ""}
                                    />
                                    {formik.touched.employerName && formik.errors.employerName ? <small className="validation_error">{formik.errors.employerName}</small> : null}
                                </FormGroup>
                                <FormGroup>
                                    <Label>
                                        Employer Address
                                    </Label>
                                    <Input
                                        id='exampletext'
                                        type='text'
                                        name='employerAddress'
                                        placeholder='Enter Employer Address'
                                        {...formik.getFieldProps("employerAddress")}
                                        className={formik.touched.employerAddress && formik.errors.employerAddress ? 'is-invalid' : ""}
                                    />
                                    {formik.touched.employerAddress && formik.errors.employerAddress ? <small className="validation_error">{formik.errors.employerAddress}</small> : null}
                                </FormGroup>

                                <FormGroup>
                                    <Label for=''>
                                        Contact Number
                                    </Label>
                                    <PhoneInput
                                        country="us"
                                        name="employerContactNumber"
                                        preferredCountries={["us"]}
                                        placeholder="Type your contact number here"
                                        value={formik.values.employerContactNumber}
                                        onBlur={formik.handleBlur}
                                        // onChange={(value) => formik.setFieldValue("employerContactNumber", value)}
                                        onChange={handleMobileChange}
                                        enableSearch={true}
                                        // {...formik.getFieldProps("employerContactNumber")}
                                        inputStyle={{ width: "100%" }}
                                        inputClass={formik.touched.employerContactNumber && formik.errors.employerContactNumber ? " is-invalid" : ""}
                                        inputProps={{ name: "employerContactNumber" }}
                                    />
                                    {formik.touched.employerContactNumber && formik.errors.employerContactNumber ? <small className="validation_error">{formik.errors.employerContactNumber}</small> : null}
                                </FormGroup>

                                <FormGroup>
                                    <Label for='exampleFax'>
                                        Fax Number
                                    </Label>
                                    <Input
                                        id='exampleText'
                                        name='employerFax_number'
                                        placeholder='Enter Fax Number'
                                        {...formik.getFieldProps("employerFax_number")}
                                        onKeyDown={checkSpace}
                                        type='text'
                                        className={formik.touched.employerFax_number && formik.errors.employerFax_number ? 'is-invalid' : ""}
                                    />
                                    {formik.touched.employerFax_number && formik.errors.employerFax_number ? <small className="validation_error">{formik.errors.employerFax_number}</small> : null}
                                </FormGroup>

                                <FormGroup>
                                    <Label for='exampleEmail'>
                                        Email Address
                                    </Label>
                                    <Input
                                        id='exampleEmail'
                                        name='employerEmail'
                                        placeholder='Enter Email Address'
                                        {...formik.getFieldProps("employerEmail")}
                                        onKeyDown={checkSpace}
                                        type='employerEmail'
                                        className={formik.touched.employerEmail && formik.errors.employerEmail ? 'is-invalid' : ""}
                                    />
                                    {formik.touched.employerEmail && formik.errors.employerEmail ? <small className="validation_error">{formik.errors.employerEmail}</small> : null}
                                </FormGroup>

                                <FormGroup>
                                    <Label for='exampleCurrent'>
                                        Current Role
                                    </Label>
                                    <Input
                                        id='exampleText'
                                        name='current_role'
                                        placeholder='Enter Role'
                                        {...formik.getFieldProps("current_role")}
                                        onKeyDown={checkSpace}
                                        type='text'
                                        className={formik.touched.current_role && formik.errors.current_role ? 'is-invalid' : ""}
                                    />
                                    {formik.touched.current_role && formik.errors.current_role ? <small className="validation_error">{formik.errors.current_role}</small> : null}
                                </FormGroup>
                                <FormGroup>
                                    <Label for='exampleArea'>
                                        Area of Expertise
                                    </Label>
                                    <Input
                                        id='exampleText'
                                        name='area_expertise'
                                        placeholder='Enter Area of Expertise'
                                        {...formik.getFieldProps("area_expertise")}
                                        onKeyDown={checkSpace}
                                        type='text'
                                        className={formik.touched.area_expertise && formik.errors.area_expertise ? 'is-invalid' : ""}
                                    />
                                    {formik.touched.area_expertise && formik.errors.area_expertise ? <small className="validation_error">{formik.errors.area_expertise}</small> : null}
                                </FormGroup>
                                <FormGroup>
                                    <Label for='exampleWeb'>
                                        Web Profile
                                    </Label>
                                    <Input
                                        id='exampleWeb'
                                        name='web_profile'
                                        placeholder='Enter Url '
                                        {...formik.getFieldProps("web_profile")}
                                        onKeyDown={checkSpace}
                                        type='text'
                                        className={formik.touched.web_profile && formik.errors.web_profile ? 'is-invalid' : ""}
                                    />
                                    {formik.touched.web_profile && formik.errors.web_profile ? <small className="validation_error">{formik.errors.web_profile}</small> : null}
                                </FormGroup>
                                <FormGroup>
                                    <Label for='exampleProfessional'>
                                        Professional Fees
                                    </Label>
                                    <Input
                                        id='exampleSelect'
                                        name='professional_fees'
                                        placeholder='Enter Professional Fees'
                                        {...formik.getFieldProps("professional_fees")}
                                        onKeyDown={checkSpace}
                                        type='text'
                                        className={formik.touched.professional_fees && formik.errors.professional_fees ? 'is-invalid' : ""}
                                    />
                                    {formik.touched.professional_fees && formik.errors.professional_fees ? <small className="validation_error">{formik.errors.professional_fees}</small> : null}
                                </FormGroup>



                                <Button className='btn-secondry mb-4' type='submit'>
                                    Next
                                </Button>
                            </Form>
                        </div>
                    </div>
                </div>
                
            </div>
            <Footer />
        </>
    )
}

export default ExpertEmployedSignup4
