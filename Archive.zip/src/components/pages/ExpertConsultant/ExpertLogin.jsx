import React, { useState, useEffect } from 'react'
import { FormGroup, Input, Label, Form, FormText, Button } from 'reactstrap';
import patinetImage from "../../../assests/images/Group 905.png";
import cpnLogo from "../../../assests/images/CPNHealthFINAL_fontembed.svg";
import { useNavigate, Link } from 'react-router-dom';
import { ReactComponent as HideIcon } from "../../../assests/images/hide.svg";
import { ReactComponent as ShowIcon } from "../../../assests/images/view.svg";
import { useFormik } from "formik";
import * as Yup from "yup";
import { checkSpace, detectPlatform } from "../../../utils";
import { deviceToken } from "../../../getDeviceToken";
import authenticationExpertServices from "../../../services/expertServices";
import { toast } from "react-toastify";
import SpinnerLoader from '../../common/Spinner';
const ExpertLogin = () => {

    const navigate = useNavigate()
    const [rememberME, setRememberME] = useState(false);
    const [IsLoader, setIsLoader] = useState(false);
    const [toggleIcon, setToggleIcon] = useState(false)

    const togglePassword = () => {
        setToggleIcon(!toggleIcon)
    }
    const deviceType = detectPlatform()
    let devicetoken = "";
    deviceToken.subscribe((res) => {
        devicetoken = res;
    });

    const formik = useFormik({
        initialValues: {
            email: localStorage.getItem("emailID_expert") ? localStorage.getItem("emailID_expert") : "",
            password: localStorage.getItem("password_expert") ? window.atob(localStorage.getItem("password_expert")) : "",
        },
        validationSchema: Yup.object({
            email: Yup.string().email("Invalid email address").required("*Email is required."),
            password: Yup.string()
                .required("*Password is required")
                .matches(
                    /^(?=.*?[A-Z])(?=(.*[a-z]){1,})(?=(.*[\d]){1,})(?=(.*[\W]){1,})(?!.*\s).{8,}$/,
                    "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character"
                ),
        }),

        onSubmit: async (values) => {
            const payload = {
                email: values.email,
                password: values.password,
                deviceType: deviceType,
                deviceToken: devicetoken,
            };

            if (rememberME) {
                localStorage.setItem("emailID_expert", values.email);
                localStorage.setItem("password_expert", window.btoa(values.password));
                localStorage.setItem("rememberME_expert", rememberME);
            } else {
                localStorage.removeItem("emailID_expert", values.email);
                localStorage.removeItem("password_expert", window.btoa(values.password));
                localStorage.removeItem("rememberME_expert", rememberME);
            }
            try {
                setIsLoader(true);
                let res = await authenticationExpertServices.expertLogin(payload);
                if (res.data.status === 200) {
                    setIsLoader(false);
                    const token = res.data.data.token
                    sessionStorage.setItem("token", JSON.stringify(token));
                    toast.success(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                    sessionStorage.setItem("userType", "2")
                    navigate("/expert-dashboard", { replace: true })
                } else {
                    setIsLoader(false);
                    toast.error(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                }
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        },
    });


    const handleRememberMe = (event) => {
        setRememberME(event.target.checked);
    };

    useEffect(() => {
        if (localStorage.getItem("rememberME_expert")) {
            setRememberME(true);
        }
    }, []);

    return (
        <div className='expert-login'>
            {IsLoader && <SpinnerLoader />}
            <div className="container-fluid">
                <div className="image">
                    <img src={patinetImage} />
                    <div className="content-image">
                        <p>The Checkpoint Now</p>
                        <h1> Consult our trusted cancer experts</h1>
                        <h6>- We understand cancer, its treatments and its side effects </h6>
                        <h6>- Make An Appointment </h6>
                    </div>
                </div>

                {/* <div className="form">
                    <div className="container-form-data">
                        <div className="logo">
                            <img src={cpnLogo} alt="Logo" />
                        </div>

                        <div className="patient-form-content">
                            <div className="logo-as-patient">
                                <h1>Login as a Expert Consultant</h1>
                            </div>
                            <Form onSubmit={formik.handleSubmit}>
                                <FormGroup>
                                    <Label for="exampleEmail">
                                        Email Address
                                    </Label>
                                    <Input

                                        name="email"
                                        placeholder="Enter Email Address"
                                        type="text"
                                        {...formik.getFieldProps("email")}
                                        onKeyDown={checkSpace}
                                        invalid={formik.touched.email && formik.errors.email ? true : false}
                                    />
                                    {formik.touched.email && formik.errors.email ? <small className="validation_error">{formik.errors.email}</small> : null}
                                </FormGroup>
                                <FormGroup className="pasword">


                                    <Label for="examplePassword">
                                        Password
                                    </Label>
                                    <Input
                                        onKeyDown={checkSpace}
                                        {...formik.getFieldProps("password")}

                                        name="password"
                                        autoComplete="off"
                                        placeholder="Enter Password"
                                        type={!toggleIcon ? "password" : "text"}
                                        invalid={formik.touched.password && formik.errors.password ? true : false}
                                        className='extracsc' />
                                    <span className={formik.touched.password && formik.errors.password ? 'pwdToggleError' : 'pwdToggle'}>
                                        {toggleIcon ? (
                                            <span onClick={togglePassword}>
                                                <ShowIcon />
                                            </span>
                                        ) : (
                                            <span onClick={togglePassword}>
                                                <HideIcon />
                                            </span>
                                        )}
                                    </span>
                                    {formik.touched.password && formik.errors.password ? (
                                        <span className="validation_error">{formik.errors.password}</span>
                                    ) : null}

                                </FormGroup>

                                <FormGroup check>
                                    <Input type="checkbox" checked={rememberME} onChange={handleRememberMe} />
                                    {' '}
                                    <Label check className='remember-me'>
                                        Remember me
                                    </Label>
                                </FormGroup>
                                <Button className='btn-secondry' type="submit">
                                    Login
                                </Button>
                            </Form>
                            <br />
                            <div className="last-form-content">
                                <p><Link to="/forgot-password" state={{ comingFrom: "expert-login" }}> Forgot Password </Link></p>
                                <h6>Don't have an account? <Link to="/signup-as-expert-1" style={{ fontSize: "14px" }}> Sign Up </Link></h6>
                                <h3 onClick={() => navigate("/")}>Go to Home</h3>
                            </div>
                        </div>
                    </div>

                </div> */}


                <div className="right-side">
                    <div className="form-container">
                        <img className='right-div-logo' src={cpnLogo} alt="" />
                        <h2 className='login-expert'>Login as a Expert Consultant</h2>
                        <Form onSubmit={formik.handleSubmit} className='form-size'>

                            <FormGroup>
                                <Label for="exampleEmail">
                                    Email Address
                                </Label>
                                <Input

                                    name="email"
                                    placeholder="Enter Email Address"
                                    type="text"
                                    {...formik.getFieldProps("email")}
                                    onKeyDown={checkSpace}
                                    invalid={formik.touched.email && formik.errors.email ? true : false}
                                />
                                {formik.touched.email && formik.errors.email ? <small className="validation_error">{formik.errors.email}</small> : null}
                            </FormGroup>
                            <FormGroup className="pasword">


                                <Label for="examplePassword">
                                    Password
                                </Label>
                                <Input
                                    onKeyDown={checkSpace}
                                    {...formik.getFieldProps("password")}

                                    name="password"
                                    autoComplete="off"
                                    placeholder="Enter Password"
                                    type={!toggleIcon ? "password" : "text"}
                                    invalid={formik.touched.password && formik.errors.password ? true : false}
                                    className='extracsc' />
                                <span className={formik.touched.password && formik.errors.password ? 'pwdToggleError' : 'pwdToggle'}>
                                    {toggleIcon ? (
                                        <span onClick={togglePassword}>
                                            <ShowIcon />
                                        </span>
                                    ) : (
                                        <span onClick={togglePassword}>
                                            <HideIcon />
                                        </span>
                                    )}
                                </span>
                                {formik.touched.password && formik.errors.password ? (
                                    <span className="validation_error">{formik.errors.password}</span>
                                ) : null}

                            </FormGroup>

                            <FormGroup check>
                                <Input type="checkbox" checked={rememberME} onChange={handleRememberMe} />
                                {' '}
                                <Label check className='remember-me mb-4'>
                                    Remember me
                                </Label>
                            </FormGroup>
                            <Button className='login-button' type="submit">
                                Login
                            </Button>

                        </Form>
                        <div className="last-form-content mt-4">
                            <p><Link to="/forgot-password" state={{ comingFrom: "expert-login" }}> Forgot Password </Link></p>
                            <h6>Don't have an account? <Link to="/signup-as-expert-1" style={{ fontSize: "14px" }}> Sign Up </Link></h6>
                            <h3 onClick={() => navigate("/")}>Go to Home</h3>
                        </div>
                    </div>

                </div>

            </div>
        </div>



    )
}

export default ExpertLogin