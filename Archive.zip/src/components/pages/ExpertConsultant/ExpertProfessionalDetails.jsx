
import React, { useState } from 'react'
import { useSelector, useDispatch } from 'react-redux';
import dayjs from "dayjs";
import { Link } from 'react-router-dom'
import { Progress, Form, FormGroup, Button } from 'reactstrap'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import ExpertSidebar from '../../common/ExpertSidebar/ExpertSidebar'

const ExpertProfessionalDetails = () => {
  const [IsLoader, setIsLoader] = useState(false);
  const expertData = useSelector((state) => state?.user.expertUser)
  console.log("expertData===", expertData);
  return (
    <>
      <div className='expert-professional-details'>
        <LoginNavbar />
        <div className="container-fluid custom-container-fluid mb-5">
          <div className="parent-div">

            <ExpertSidebar />
            <div className="child-div">
              <div className="middle-contnet">
                <div className="row g-0 py-2  border-bottom">
                  <div className="col-sm-6 col-md-4">
                    <h3 className='heading-profile'>Speciality</h3>
                  </div>
                  <div className="col-sm-2 col-md-6">
                    <h4 className='heading-profile1'>{expertData?.professionalDetails?.specialty}</h4>
                  </div>
                  <div className="line"></div>
                </div>
                {/* Date of Birth */}
                <div className="row g-0  py-2 border-bottom ">
                  <div className="col-sm-6 col-md-4">
                    <h3 className='heading-profile'>Degree</h3>

                  </div>
                  <div className="col-sm-2 col-md-6">
                    <h4 className='heading-profile1'>{expertData?.professionalDetails?.degree}</h4>
                    {/* <h4 className='heading-profile1'>12/01/2003</h4> */}
                  </div>
                  <div className="line"></div>
                </div>
                {/* Gender */}
                <div className="row g-0  py-2 border-bottom ">
                  <div className="col-sm-6 col-md-4">
                    <h3 className='heading-profile'>Name of Instituttion</h3>
                  </div>
                  <div className="col-sm-2 col-md-6">
                    <h4 className='heading-profile1'>{expertData?.professionalDetails?.institution?.name}</h4>
                  </div>
                  <div className="line"></div>
                </div>
                {/* Email Address */}
                <div className="row g-0  py-2 border-bottom">
                  <div className="col-sm-6 col-md-4">
                    <h3 className='heading-profile'>Year</h3>
                  </div>
                  <div className="col-sm-2 col-md-6">
                    <h4 className='heading-profile1'>{expertData?.professionalDetails?.years}</h4>
                  </div>
                  <div className="line"></div>
                </div>
                {/* Country */}
                <div className="row g-0  py-2 border-bottom">
                  <div className="col-sm-6 col-md-4">
                    <h3 className='heading-profile'>Residency</h3>
                  </div>
                  <div className="col-sm-2 col-md-6">
                    <h4 className='heading-profile1'>{expertData?.professionalDetails?.residency?.name}</h4>
                  </div>
                  <div className="line"></div>
                </div>
                {/* Contact Number */}
                <div className="row g-0  py-2 border-bottom ">
                  <div className="col-sm-6 col-md-4">
                    <h3 className='heading-profile'>Followship</h3>
                  </div>
                  <div className="col-sm-2 col-md-6">
                    <h4 className='heading-profile1'>{expertData?.professionalDetails?.fellowship?.name}</h4>
                  </div>
                  <div className="line"></div>
                </div>
                {/* Country */}
                <div className="row g-0  py-2 border-bottom ">
                  <div className="col-sm-6 col-md-4">
                    <h3 className='heading-profile'>Current Credentailing</h3>
                  </div>
                  <div className="col-sm-2 col-md-6">
                    <h4 className='heading-profile1'>{expertData?.professionalDetails?.currentCredentialing}</h4>
                  </div>
                  <div className="line"></div>
                </div>
                {/* Medical License */}
                <div className="row g-0  py-2 ">
                  <div className="col-sm-6 col-md-4">
                    <h3 className='heading-profile'>Medical License</h3>
                  </div>
                  <div className="col-sm-2 col-md-6">
                    <h4 className='heading-profile1'>{expertData?.professionalDetails?.medicalLicenseNumber}</h4>
                  </div>
                </div>
              </div>
            

            </div>
          </div>
        </div>
      </div>

      <Footer />


    </>
  )
}

export default ExpertProfessionalDetails
