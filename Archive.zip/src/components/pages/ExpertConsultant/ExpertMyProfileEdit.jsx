import React, { useState, useEffect, useRef } from 'react'
import { Table } from 'reactstrap'
import { Link, useNavigate } from 'react-router-dom'
import { Progress, Form, FormGroup, Button, Row, Label, Input, Col } from 'reactstrap'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import { ReactComponent as CrossIcon } from "../../../assests/images/close-circle-svgrepo-com.svg";
import Logoimage from '../../../assests/images/ys.png'
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import { useFormik } from 'formik'
import { checkSpace } from "../../../utils";
import * as Yup from "yup";
import authenticationServices from "../../../services";
import { toast } from "react-toastify";
import { setUser } from '../../../stateManagement/userSlice';
import dayjs from "dayjs";
import Sidebar from '../../common/Sidebar/Sidebar'
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import { useSelector, useDispatch } from 'react-redux';
import { async } from 'q'
import SpinnerLoader from '../../common/Spinner'
import ExpertSidebar from '../../common/ExpertSidebar/ExpertSidebar'
import 'font-awesome/css/font-awesome.min.css';

const ExpertMyProfileEdit = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const [dob, setDob] = useState("")
    const [IsLoader, setIsLoader] = useState(false);
    const [gender, setGender] = useState("")
    const userData = useSelector((state) => state.user.expertUser);
    const [countryData, setCountryData] = useState([])
    const [profileImage, setProfileImage] = useState(null);
    const [ImageChange, setImageChange] = useState(false);
    const [imageSrc, setImageSrc] = useState(null);


    // const { userData, formik } = useUserData(); // Assuming you have a way to get user data and formik configuration
    const fileInputRef = useRef(null);

    const handleUpdatePhotoClick = () => {
        if (fileInputRef.current) {
            fileInputRef.current.click();
        }
    };

    const handleFileChange = (event) => {
        const selectedFile = event.target.files[0];
        // Handle the selected file here, e.g., upload it to the server
        setProfileImage(selectedFile);
        // const imageURL = URL.createObjectURL(selectedFile);
        // setProfileImage(imageURL)
        // setImageSrc(imageURL);
    };
    const handleImageUpload = () => {
        // Trigger the hidden file input when the placeholder is clicked
        fileInputRef.current.click();

    };

    useEffect(() => {
        getAllcountryApi()
    }, [])


    const handleImageChange = (e) => {
        const file = e.target.files[0];
        // console.log("image file==", file);
        setProfileImage(file);
    }


    useEffect(() => {
        if (userData && Object.keys(userData).length) {
            getPatchform()
        }
    }, [userData])

    const getPatchform = () => {
        console.log("userData", userData);
        formik.setValues({
            name: userData?.personalDetails?.name,
            dateOfBirth: dayjs(userData?.personalDetails?.dateofbirth).format('YYYY-MM-DD'),
            gender: userData?.personalDetails?.sex,
            address: userData?.personalDetails?.address,
            mobileNumber: userData?.personalDetails?.contactNumber,
            country: userData?.personalDetails?.country,
            email: userData?.email,
        });
        // setProfileImage(userData?.personalDetails?.image)
        setProfileImage(userData?.personalDetails?.image)

        // console.log("dateOfBirth==", new Date(dateOfBirth).toString());
        // setDob(dateOfBirth)
        setGender(userData?.personalDetails?.sex)

    };

    // useEffect(() => {
    //     if (!profileImage) {
    //         setImageChange(true)
    //     }
    // }, [profileImage])



    const validationSchema = Yup.object().shape({
        name: Yup.string().required('Name is required'),
        // email: Yup.string().email('Invalid email').required('Email is required'),
        // dateOfBirth: Yup.string().required("*Date Of birth is required."),
        // gender: Yup.string().required('Please select your gender'),
        mobileNumber: Yup.string().required("*Contact number is required."),

        // .matches(
        //     /^[6-9]{1}[0-9]{9}$/,
        //     "Enter valid contact number"
        // ),
        country: Yup.string().required("*Country is required."),
        address: Yup.string()
            .required("*Address is required.")
            .min(5, "minimum five character are required."),
        // Add more fields and validation rules as needed
    });


    const getAllcountryApi = async () => {
        try {
            let res = await authenticationServices.getAllcountry();
            console.log("getCountry==", res);
            if (res.data.status === 200) {
                setCountryData(res.data.countries)
            }
        } catch (error) {
            toast.error(error, {
                position: toast.POSITION.TOP_RIGHT,
            });
        }
    }

    const formik = useFormik({
        initialValues: {
            name: '',
            email: '',
            dateOfBirth: "",
            gender: "",
            address: "",
            mobileNumber: "",
            country: "",
        },
        validationSchema: validationSchema,
        onSubmit: async (values) => {
            try {

                setIsLoader(true);
                const formData = new FormData();
                formData.append("name", values.name);
                formData.append("country", values.country);
                formData.append("address", values.address)
                formData.append("contactNumber", "+" + values.mobileNumber)
                // formData.append("file", profileImage)

                let res = await authenticationServices.patientUpdate(formData);
                console.log("update profile result==", res);
                if (res.status === 200) {
                    setIsLoader(false);
                    toast.success(res.data.status, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                    const userData = res.data.user
                    dispatch(setUser(userData));
                    navigate("/expert-my-profile")
                } else {
                    setIsLoader(false);
                    toast.error(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                }
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }

        },
    });

    // console.log(formik.errors)
    const handleGanderChange = (e) => {
        const { name, value } = e.target;
        setGender(value);
        formik.setFieldValue("gender", value)
        formik.setFieldTouched("gender", false)

    }

    const handleMobileChange = (value, data) => {
        // setCountryCode(data.dialCode)
        formik.setFieldValue("mobileNumber", value)

    }
    const handleRemoveImage = () => {
        setProfileImage(null);
        setImageChange(true);
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
        }
    };

    return (
        <>

            <div className='expert-my-profile-edit'>
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className="parent-div">
                        <ExpertSidebar />

                        <div className="child-div">
                            <div className="my-profile-edit-content">
                                <div className="middle-content-form">
                                    <Form onSubmit={formik.handleSubmit}>
                                        <h1>Edit Profile</h1>
                                        <Row>
                                            <Col md={6}>
                                                <FormGroup>
                                                    <Label for="exampleText">
                                                        Name
                                                    </Label>
                                                    <Input
                                                        id="name"
                                                        name="name"
                                                        // placeholder="Abdullah Zaheer"
                                                        type="text"
                                                        {...formik.getFieldProps("name")}
                                                        className={formik.touched.name && formik.errors.name ? 'is-invalid' : ""}
                                                    />
                                                    {formik.touched.name && formik.errors.name ? <small className="validation_error">{formik.errors.name}</small> : null}

                                                </FormGroup>
                                            </Col>
                                            <Col md={6}>
                                                <FormGroup>
                                                    <Label>Date of Birth</Label>
                                                    <Input
                                                        id="dateOfBirth"
                                                        name="dateOfBirth"
                                                        placeholder="Enter Dob"
                                                        max={new Date().toISOString().split('T')[0]}
                                                        min="1980-01-01"
                                                        type="date"
                                                        {...formik.getFieldProps("dateOfBirth")}
                                                        className={formik.touched.dateOfBirth && formik.errors.dateOfBirth ? 'is-invalid form-control' : "form-control"}
                                                    />
                                                    {formik.touched.dateOfBirth && formik.errors.dateOfBirth ? <small className="validation_error">{formik.errors.dateOfBirth}</small> : null}


                                                </FormGroup>
                                            </Col>
                                        </Row>

                                        <Row>
                                            <Col md={6} >
                                                <Label>Gender</Label>
                                                <FormGroup {...formik.getFieldProps("gender")}>
                                                    <div className='gender-radiotype' >
                                                        <FormGroup check>
                                                            <Input
                                                                name="gander"
                                                                type="radio"
                                                                value="Male"
                                                                onChange={handleGanderChange}
                                                                checked={gender == "Male"}
                                                            />
                                                            {' '}
                                                            <span check>
                                                                Male
                                                            </span>
                                                        </FormGroup>
                                                        <FormGroup check>
                                                            <Input
                                                                name="gander"
                                                                type="radio"
                                                                value="Female"
                                                                onChange={handleGanderChange}
                                                                checked={gender == "Female"}
                                                            />
                                                            {' '}
                                                            <span check>
                                                                Female
                                                            </span>
                                                        </FormGroup>
                                                        <FormGroup check>
                                                            <Input
                                                                name="gander"
                                                                type="radio"
                                                                value="ntos"
                                                                onChange={handleGanderChange}
                                                                checked={gender == "ntos"}
                                                            />
                                                            {' '}
                                                            <span check>
                                                                Prefer not to say
                                                            </span>
                                                        </FormGroup>
                                                    </div>
                                                    {formik.touched.gender && formik.errors.gender ? <small className="validation_error">{formik.errors.gender}</small> : null}
                                                </FormGroup>
                                            </Col>
                                            <Col md={6}>
                                                <FormGroup>
                                                    <Label for="exampleEmail">
                                                        Email Address
                                                    </Label>
                                                    <Input
                                                        id="exampleEmail"
                                                        name="email"
                                                        disabled
                                                        placeholder="abdullahzaheer@yahoo.com"
                                                        type="email"
                                                        {...formik.getFieldProps("email")}
                                                        onKeyDown={checkSpace}
                                                        className={formik.touched.email && formik.errors.email ? "is-invalid" : ""}
                                                    />
                                                    {formik.touched.email && formik.errors.email ? <small className="validation_error">{formik.errors.email}</small> : null}
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                        <Row>
                                            <Col md={6}>
                                                <FormGroup>
                                                    <Label for=''>
                                                        Contact Number
                                                    </Label>
                                                    <PhoneInput
                                                        country="us"
                                                        preferredCountries={["us"]}
                                                        placeholder="Type your contact number here"
                                                        value={formik.values.mobileNumber}
                                                        onBlur={formik.handleBlur}
                                                        // onChange={(value) => formik.setFieldValue("mobileNumber", value)}
                                                        onChange={handleMobileChange}
                                                        enableSearch={true}
                                                        // {...formik.getFieldProps("mobileNumber")}
                                                        inputStyle={{ width: "100%" }}
                                                        inputClass={formik.touched.mobileNumber && formik.errors.mobileNumber ? " is-invalid" : ""}
                                                        inputProps={{ name: "mobileNumber" }}
                                                    />
                                                    {formik.touched.mobileNumber && formik.errors.mobileNumber ? <small className="validation_error">{formik.errors.mobileNumber}</small> : null}
                                                </FormGroup>
                                            </Col>

                                        </Row>
                                        <Row>
                                            <Col md={6}>
                                                <FormGroup>
                                                    <Label for="exampleAddress">
                                                        Address
                                                    </Label>
                                                    <Input
                                                        id='exampleAddress'
                                                        name='Address'
                                                        placeholder='Enter Your Address'
                                                        {...formik.getFieldProps("address")}
                                                        onKeyDown={checkSpace}
                                                        type='text'
                                                        className={formik.touched.address && formik.errors.address ? 'is-invalid' : ""}
                                                    />
                                                    {formik.touched.address && formik.errors.address ? <small className="validation_error">{formik.errors.address}</small> : null}

                                                </FormGroup>
                                            </Col>
                                            <Col md={6} >
                                                <FormGroup>
                                                    <Label for="exampleSelect">
                                                        Country
                                                    </Label>
                                                    <Input
                                                        id="exampleSelect"
                                                        name="country"
                                                        type="select"
                                                        {...formik.getFieldProps("country")}
                                                        className={formik.touched.country && formik.errors.country ? 'is-invalid' : ""}
                                                    >
                                                        <option value=''>Select Country</option>
                                                        <option value="usa">USA</option>

                                                        {
                                                            countryData?.length ? countryData?.map((item, index) => (
                                                                <option value={item?._id} key={index

                                                                }>{item?.name}</option>
                                                            ))
                                                                : null
                                                        }

                                                    </Input>
                                                    {formik.touched.country && formik.errors.country ? <small className="validation_error">{formik.errors.country}</small> : null}
                                                </FormGroup>

                                            </Col>
                                        </Row>


                                        <Button type='submit' className='custom-button mt-3'>Update</Button>
                                    </Form>
                                </div>

                                <div className="right-side-profile-image">
                                    <div className="profile-image-container">
                                        {profileImage ? (
                                            <>
                                                {!ImageChange ?
                                                    <img
                                                        src={profileImage || Logoimage}

                                                        alt="img"
                                                    />
                                                    : <img
                                                        src={URL.createObjectURL(profileImage)}

                                                    />}
                                                {/* <img
                                                    src={profileImage?profileImage:Logoimage}
                                                    alt=""
                                                /> */}
                                                <span className="close-icon" onClick={handleRemoveImage}>
                                                    <CrossIcon />
                                                </span>
                                            </>
                                        ) : (
                                            <div className="profile-image-placeholder" onClick={handleImageUpload}>
                                                <input
                                                    type="file"
                                                    accept="image/*"
                                                    capture="camera"
                                                    ref={fileInputRef}
                                                    style={{ display: 'none' }}
                                                    onChange={handleFileChange}
                                                />
                                                <i className="fa fa-camera"></i>
                                                <p>Upload Image</p>
                                            </div>
                                        )}

                                    </div>

                                </div>


                            </div>


                        </div>
                    </div>
                </div>
            </div>
            <Footer />


        </>
    )
}

export default ExpertMyProfileEdit
