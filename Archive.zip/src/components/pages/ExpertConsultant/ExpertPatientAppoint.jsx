import React from 'react'
import { Row, Table, FormGroup, Form, Input, Label, Col } from 'reactstrap'
import { Link, useNavigate } from 'react-router-dom'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import Logoimage from '../../../assests/images/ys.png'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import Sidebar from '../../common/Sidebar/Sidebar'
import ExpertSidebar from '../../common/ExpertSidebar/ExpertSidebar'


const ExpertPatientAppoint = () => {
    const navigate = useNavigate();
    return (
        <>
            <div className='expert-patient-appiont'>
                <LoginNavbar />
                <div className="container mb-5">
                    <div className="parent-div">
                        <ExpertSidebar />
                          <div className="child-div">
                            <div className="container-table">
                                <div className="table-row">
                                    
                                </div>
                                <table className="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">S.No.</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">Age</th>
                                            <th scope='col'>Date</th>
                                            <th scope='col'>Appointment ID</th>
                                            <th scope="col">Appointment Status</th>
                                            <th scope='col'>Payment Status</th>
                                            <th scope='col'>Call Status</th>
                                            <th scope='col'>EC Survey Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row">1</th>
                                            <td>Dr. Abdul Kareem</td>
                                            <td>32</td>
                                            <td>25 May, 2023</td>
                                            <td>Medicam</td>
                                            <td>Scheduled</td>
                                            <td>-</td>
                                            <td> <Link to="/initiate-call">Initiate Call </Link></td>
                                            <td><a href='#'>Note & Survey</a></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">2</th>
                                            <td>Dr. Abdul Kareem</td>
                                            <td>36</td>
                                            <td>25 May, 2023</td>
                                            <td>Medicam</td>
                                            <td>Scheduled</td>
                                            <td>Pending</td>
                                            <td> <Link to="/initiate-call">Initiate Call </Link></td>
                                            <td><a href='#'>Note & Survey</a></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">3</th>
                                            <td>Dr. Abdul Kareem</td>
                                            <td>47</td>
                                            <td>25 May, 2023</td>
                                            <td>Medicam</td>
                                            <td>Complete</td>
                                            <td>Paid</td>
                                            <td> <a href="#">Initiate Call </a></td>
                                            <td><a href='#'>Note & Survey</a></td>
                                        </tr>
                                        
                                        <tr>
                                            <th scope="row">4</th>
                                            <td>Dr. Abdul Kareem</td>
                                            <td>36</td>
                                            <td>25 May, 2023</td>
                                            <td>Medicam</td>
                                            <td>Scheduled</td>
                                            <td>-</td>
                                            <td> <a href="#">- </a></td>
                                            <td><a href='#'>Note & Survey</a></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">5</th>
                                            <td>Dr. Abdul Kareem</td>
                                            <td>32</td>
                                            <td>25 May, 2023</td>
                                            <td>Medicam</td>
                                            <td>Completed</td>
                                            <td>Pending</td>
                                            <td> <a href="#"> Initiate Call</a></td>
                                            <td><a href='#'>Note & Survey</a></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">6</th>
                                            <td>Dr. Abdul Kareem</td>
                                            <td>47</td>
                                            <td>25 May, 2023</td>
                                            <td>Medicam</td>
                                            <td>Scheduled</td>
                                            <td>Paid</td>
                                            <td> <Link to="/initiate-call">Initiate Call </Link></td>
                                            <td><a href='#'>Note & Survey</a></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <Footer />


        </>
    )
}

export default ExpertPatientAppoint
