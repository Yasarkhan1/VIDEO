import React, { useState, useEffect, useRef } from 'react'
import { FormGroup, Input, Label, Form, FormText, Button, Progress, Row, Col } from 'reactstrap';
import tick from "../../../assests/images/check-circle-svgrepo-com (2).svg";
import blueTick from "../../../assests/images/blue-tick.svg";
import cpnLogo from "../../../assests/images/CPNHealthFINAL_fontembed.svg";
import { ReactComponent as CrossIcon } from "../../../assests/images/close-circle-svgrepo-com.svg";
import calenderImg from "../../../assests/images/calender-svgrepo-com.svg";
import Footer from '../../common/Footer/Footer';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { useNavigate, Link } from 'react-router-dom';
import { useFormik } from "formik";
import * as Yup from "yup";
import { checkSpace } from "../../../utils";
import dayjs from "dayjs";
import { toast } from "react-toastify";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import e from 'cors';
import { async } from 'q';
import authenticationServices from "../../../services";

const ExpertPersonalSignUp2 = () => {

    const fileInputRef = useRef(null);
    const navigate = useNavigate()
    const [IsLoader, setIsLoader] = useState(false);
    const [countryData, setCountryData] = useState([])
    const [profileImage, setProfileImage] = useState(null);
    const [dob, setDob] = useState("")
    const [gender, setGender] = useState("")
    const [aggrementData, setAggrementData] = useState({})
    const [selectedCountryId, setSelectedCountryId] = useState('');
    const [selectedCountryName, setSelectedCountryName] = useState('');
    const [countryCode, setCountryCode] = useState('');
    const handleGanderChange = (e) => {
        const { name, value } = e.target;
        setGender(value);
        formik.setFieldValue("gender", value)

    }

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        // console.log("image file==", file);
        setProfileImage(file);
    }

    const getAllcountryApi = async () => {
        try {
            let res = await authenticationServices.getAllcountry();
            // console.log("getCountry==", res);
            if (res.data.status === 200) {
                setCountryData(res.data.countries)
            }
        } catch (error) {
            toast.error(error, {
                position: toast.POSITION.TOP_RIGHT,
            });
        }
    }

    const getAggrementApi = async (countryId) => {
        const payload = {
            "countryId": countryId
        }
        console.log("payload", payload);
        try {
            let res = await authenticationServices.getAggrement(payload);
            // console.log("getAggrementApi==", res);
            if (res.data.status === 200) {
                setAggrementData(res.data.agreements[0])
            }
        } catch (error) {
            toast.error(error, {
                position: toast.POSITION.TOP_RIGHT,
            });
        }
    }

    useEffect(() => {
        const step1Data = localStorage.getItem("expertSignupData")
            ? JSON.parse(localStorage.getItem("expertSignupData"))
            : "";
        const { email, password } = step1Data
        if (!email || !password) {
            navigate('/signup-as-expert-3')
        } else {
            getPatchform();
            getAllcountryApi()
        }
    }, [])
    // fill data in fields after back.
    const getPatchform = () => {
        const step2Data = localStorage.getItem("expertSignupData")
            ? JSON.parse(localStorage.getItem("expertSignupData"))
            : "";
        console.log("step2Data++++", step2Data);
        const { name, dateOfBirth, sex, address, address1, contactNumber, selectedCountryId, city, state, zip_code, } = step2Data
        const dateString = dayjs(dateOfBirth).format('DD/MM/YYYY');
        // console.log("Date: ", dateString);
        if (name && dateOfBirth) {
            formik.setValues({
                name: name,
                dateOfBirth: dateString,
                gender: sex,
                address: address,
                address1:address1,
                mobileNumber: contactNumber,
                country: selectedCountryId,
                city: city,
                state: state,
                zip_code: zip_code,
            });
            // console.log("dateOfBirth==", new Date(dateOfBirth).toString());
            // setDob(dateOfBirth)
            setGender(sex)
        }
    };

    const formik = useFormik({
        initialValues: {
            name: "",
            dateOfBirth: "",
            gender: "",
            address: "",
            address1:"",
            city: "",
            state: "",
            zip_code: "",
            mobileNumber: "",
            country: "",
        },
        validationSchema: Yup.object({
            name: Yup.string()
                .required("*First name is required.")
                .min(3, "minimum three character are required."),
            dateOfBirth: Yup.string()
                .required("*Date Of birth is required."),
            gender: Yup.string()
                .required("*Gender is required."),
            address: Yup.string()
                .required("*Address is required.")
                .min(5, "minimum five character are required."),
            address1: Yup.string()
                .required("*Address is required")
                .min(5, "minimum five character are required."),
            city: Yup.string().required("Enter city name"),
            state: Yup.string().required("Enter state name"),
            zip_code: Yup.string().required("Enter zip code"),
            mobileNumber: Yup.string()
                .required("*Contact number is required."),
            // .matches(
            //     /^[6-9]{1}[0-9]{9}$/,
            //     "Enter valid contact number"
            // ),
            country: Yup.string()
                .required("*Country is required."),
        }),

        onSubmit: async (values) => {
            const step1Data = localStorage.getItem("expertSignupData")
                ? JSON.parse(localStorage.getItem("expertSignupData"))
                : "";
            const { email, password } = step1Data

            if (!profileImage) {
                toast.warn("Please upload a profile image.", {
                    position: toast.POSITION.TOP_RIGHT,
                });
                return; // Prevent form submission
            }
            const payload = {
                email: email,
                password: password,
                name: values.name,
                dateOfBirth: dayjs(values.dateOfBirth).format('DD/MM/YYYY'),
                sex: values.gender,
                address: values.address,
                address1:values.address1,
                contactNumber: values.mobileNumber,
                selectedCountryId: values.country,
                country: selectedCountryName,
                city: values.city,
                state: values.state,
                zip_code: values.zip_code,
                image: profileImage,
                hipaaAgreement: [{
                    "key": aggrementData?.name,
                    "_id": aggrementData?._id,
                    "status": true
                }],
                countryCode: "+" + countryCode
            };

            try {
                // console.log("patient details payload=", payload, JSON.stringify(payload));
                localStorage.setItem("expertSignupData", JSON.stringify(payload));
                navigate("/signup-as-expert-1", { state: { step2Payload: payload } })
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        }
    });


    useEffect(() => {
        // Make your API call using selectedCountryId
        if (selectedCountryId) {
            getAggrementApi(selectedCountryId)
            const countryName = countryData?.length ? countryData?.find(x => x._id === selectedCountryId) : ""
            setSelectedCountryName(countryName?.name)
        }

    }, [selectedCountryId]);


    const handleMobileChange = (value, data) => {
        setCountryCode(data.dialCode)
        formik.setFieldValue("mobileNumber", value)

    }

    const handleRemoveImage = () => {
        setProfileImage(null); // Remove the uploaded image by setting the state to null
        // Reset the file input value to clear the selected image
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
        }
    };
    return (
        <div className='expert-signup-details-2'>
            <div className="container">
                <div className="logo-container">
                    <div className="logo-cpn">
                        <img src={cpnLogo} alt="Logo" />
                    </div>
                    <div className="login-button">
                        <Link to="/login-as-patient">
                            <Button>
                                Login
                            </Button>
                        </Link>
                    </div>
                </div>
                <div className="otp-input">

                    <Progress multi>
                        <Progress
                            bar
                            value="33.33"
                            style={{
                                height: '5px'
                            }}
                        />
                        <Progress
                            bar
                            color="success"
                            value="33.33"

                        />
                        <Progress
                            bar
                            color="info"
                            value="33.33"

                        />
                    </Progress>
                </div>
                <div className="text-sign-up">
                    <h1>Sign Up as a Expert Consultants</h1>
                </div>
            </div>
            <div className="container">
                <div className="content-date">
                    <div className="login-detail">
                        <div className="login-detail-img">
                            <img src={tick} alt="" />
                            <h1>Login Details</h1>
                        </div>
                        <div className="login-detail-img2-data">
                            <img src={tick} alt="" />
                            <h1>Personal Details</h1>
                        </div>
                        <div className="login-detail-img2-data" style={{ opacity: '0.32' }}>
                            <img src={tick} alt="" />
                            <h1>Professional Details</h1>
                        </div>
                        <div className="login-detail-img2-data" style={{ opacity: '0.32' }}>
                            <img src={tick} alt="" />
                            <h1>Employment Details</h1>
                        </div>
                        <div className="login-detail-img2-data" style={{ opacity: '0.32' }}>
                            <img src={tick} alt="" />
                            <h1>Availability & Payment Method</h1>
                        </div>
                        <div className="login-detail-img2-data" style={{ opacity: '0.32' }}>
                            <img src={tick} alt="" />
                            <h1>Upload W-9</h1>
                        </div>
                        <div className="login-detail-img3-data">
                            <img src={tick} alt="" />
                            <h1>Sign HIPAA/GDPR Agreement & CPN Agreement</h1>

                        </div>
                    </div>
                    <div className="form-data-container">
                        <Form onSubmit={formik.handleSubmit}>
                            <FormGroup>
                                <Label for="exampleFullname">
                                    Name
                                </Label>
                                <Input
                                    name="name"
                                    placeholder="Enter Name"
                                    type="text"
                                    {...formik.getFieldProps("name")}
                                    onKeyDown={checkSpace}
                                    className={formik.touched.name && formik.errors.name ? 'is-invalid' : ""}
                                />
                                {formik.touched.name && formik.errors.name ? <small className="validation_error">{formik.errors.name}</small> : null}
                            </FormGroup>
                            {/* <FormGroup className='dob-select'>
                                <Label for="exampleDate">
                                    Date of Birth
                                </Label>
                                <DatePicker
                                    selected={dob}
                                    placeholderText="Enter Dob"
                                    dateFormat="dd/MM/yyyy"
                                    showIcon={true}
                                    // required
                                    maxDate={new Date()}
                                    showYearDropdown={true}
                                    isClearable={dob}
                                    // className="form-control"
                                    name="startDate"
                                    {...formik.getFieldProps("dateOfBirth")}
                                    // withPortal
                                    className={formik.touched.dateOfBirth && formik.errors.dateOfBirth ? 'is-invalid form-control' : "form-control"}
                                    onChange={(date) => { setDob(date); formik.setFieldValue("dateOfBirth", date) }} //only when value has changed
                                />
                                {formik.touched.dateOfBirth && formik.errors.dateOfBirth ? <small className="validation_error">{formik.errors.dateOfBirth}</small> : null}
                            </FormGroup> */}

                            <FormGroup>
                                <Label>
                                    Address 1
                                </Label>
                                <Input
                                    id='exampleText'
                                    name='address'
                                    placeholder='Enter Address'
                                    type='text'
                                    {...formik.getFieldProps("address")}
                                    onKeyDown={checkSpace}
                                    className={formik.touched.address && formik.errors.address ? 'is-invalid' : ""}
                                />
                                {formik.touched.address && formik.errors.address ? <small className="validation_error">{formik.errors.address}</small> : null}

                            </FormGroup>
                            <FormGroup>
                                <Label>
                                    Address 2
                                </Label>
                                <Input
                                    id='exampleText'
                                    name='address1'
                                    placeholder='Enter Address'
                                    type='text'
                                    {...formik.getFieldProps("address1")}
                                    onKeyDown={checkSpace}
                                    className={formik.touched.address1 && formik.errors.address1 ? 'is-invalid' : ""}
                                />
                                {formik.touched.address1 && formik.errors.address1 ? <small className="validation_error">{formik.errors.address1}</small> : null}

                            </FormGroup>


                            <FormGroup>
                                <Label for='exampleAddress'>
                                    City
                                </Label>
                                <Input
                                    id='exampleText'
                                    name='city'
                                    placeholder='Enter City Name'
                                    {...formik.getFieldProps("city")}
                                    onKeyDown={checkSpace}
                                    type='text'
                                    className={formik.touched.city && formik.errors.city ? 'is-invalid' : ""}
                                />
                                {formik.touched.city && formik.errors.city ? <small className="validation_error">{formik.errors.city}</small> : null}
                            </FormGroup>
                            <FormGroup>
                                <Label for='exampleText'>
                                    State
                                </Label>
                                <Input
                                    id='exampleText'
                                    name='state'
                                    placeholder='Enter State'
                                    {...formik.getFieldProps("state")}
                                    onKeyDown={checkSpace}
                                    type='text'
                                    className={formik.touched.state && formik.errors.state ? 'is-invalid' : ""}
                                />
                                {formik.touched.state && formik.errors.state ? <small className="validation_error">{formik.errors.state}</small> : null}
                            </FormGroup>

                            <FormGroup>
                                <Label for="exampleSelect">Country</Label>
                                <Input
                                    id="exampleSelect"
                                    name="country"
                                    type="select"
                                    // {...formik.getFieldProps("country")}
                                    value={formik.values.country}
                                    onChange={(e) => {
                                        const selectedId = e.target.value;
                                        setSelectedCountryId(selectedId); // Update the selected country ID
                                        formik.handleChange(e); // Update Formik's state
                                    }}
                                    onBlur={formik.handleBlur}

                                    className={formik.touched.country && formik.errors.country ? 'is-invalid' : ""}

                                >
                                    <option value="">Select Country</option>
                                    {
                                        countryData?.length ? countryData?.map((item, index) => (
                                            <option value={item?._id} key={index

                                            }>{item?.name}</option>
                                        ))
                                            : null
                                    }
                                    {/* <option value="india">INDIA</option>
                                    <option>USA</option>
                                    <option>UAE</option>
                                    <option>US</option> */}

                                </Input>
                                {formik.touched.country && formik.errors.country ? <small className="validation_error">{formik.errors.country}</small> : null}
                            </FormGroup>
                            <FormGroup>
                                <Label for='exampleText'>
                                    Zip Code
                                </Label>
                                <Input
                                    id='exampleText'
                                    name='zip_code'
                                    placeholder='Enter Zipcode'
                                    {...formik.getFieldProps("zip_code")}
                                    onKeyDown={checkSpace}
                                    type='text'
                                    className={formik.touched.zip_code && formik.errors.zip_code ? 'is-invalid' : ""}
                                />
                                {formik.touched.zip_code && formik.errors.zip_code ? <small className="validation_error">{formik.errors.zip_code}</small> : null}
                            </FormGroup>

                            <Row>
                                <Col md={4}>
                                    <FormGroup>
                                        <label htmlFor="imageUpload" className="form-label">
                                            Upload Image
                                        </label>
                                    </FormGroup>
                                </Col>
                                <Col md={8}>
                                    <FormGroup>
                                        <input
                                            type="file"
                                            className="form-control"
                                            id="imageUpload"
                                            accept="image/*"
                                            onChange={handleImageChange}
                                            ref={fileInputRef}
                                            style={{ height: '32px' }}
                                        />
                                        {profileImage && (
                                            <div className="image-preview">
                                                <img
                                                    src={URL.createObjectURL(profileImage)}
                                                    alt="Uploaded"
                                                    className="mt-3"
                                                />
                                                <span className="remove-icon" onClick={handleRemoveImage}>
                                                    <CrossIcon />
                                                </span>
                                            </div>

                                        )}
                                    </FormGroup>
                                </Col>
                                <FormGroup>
                                    <Label for=''>
                                        Contact Number
                                    </Label>
                                    <PhoneInput
                                        country="us"
                                        preferredCountries={["us"]}
                                        placeholder="Type your contact number here"
                                        value={formik.values.mobileNumber}
                                        onBlur={formik.handleBlur}
                                        // onChange={(value) => formik.setFieldValue("mobileNumber", value)}
                                        onChange={handleMobileChange}
                                        enableSearch={true}
                                        // {...formik.getFieldProps("mobileNumber")}
                                        inputStyle={{ width: "100%" }}
                                        inputClass={formik.touched.mobileNumber && formik.errors.mobileNumber ? " is-invalid" : ""}
                                        inputProps={{ name: "mobileNumber" }}
                                    />
                                    {formik.touched.mobileNumber && formik.errors.mobileNumber ? <small className="validation_error">{formik.errors.mobileNumber}</small> : null}
                                </FormGroup>
                            </Row>

                            <Button className='btn-secondry' type='submit'>
                                Next
                            </Button>
                        </Form>


                    </div>
                </div>
            </div>
            <Footer />
        </div>
    )
}

export default ExpertPersonalSignUp2