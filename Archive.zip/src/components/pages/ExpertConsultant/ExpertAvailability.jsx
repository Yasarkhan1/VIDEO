import React, { useState, useEffect, useRef } from 'react'
import { Row, Table, FormGroup, Form, Input, Label, Col, Button } from 'reactstrap'
import { useNavigate, Link, useLocation } from 'react-router-dom';
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import ExpertSidebar from '../../common/ExpertSidebar/ExpertSidebar'
import TimePicker from "rc-time-picker";
import "rc-time-picker/assets/index.css"
import moment from "moment";
import { ReactComponent as CrossIcon } from "../../../assests/images/close-circle-svgrepo-com.svg";
import { toast } from "react-toastify"
import { useSelector } from 'react-redux';
import authenticationExpertServices from "../../../services/expertServices";
import SpinnerLoader from '../../common/Spinner';


const ExpertAvailability = () => {
    const location = useLocation()
    const profileImage = location?.state?.profileImage
    const navigate = useNavigate()
    const format = 'h:mm a';
    const [IsLoader, setIsLoader] = useState(false);
    const [open, setPickerOpen] = useState(false);
    const [openEnd, setPickerOpenEnd] = useState(false);
    const now = moment().hour(0).minute(0);
    const [timeInterval, setTimeInterval] = useState('');
    const [selectedDays, setSelectedDays] = useState([]);
    const [startTime, setStartTime] = useState('');
    const [endTime, setEndTime] = useState('');
    const [paymentMethod, setPaymentMethod] = useState('');
    const [generatedSlots, setGeneratedSlots] = useState([]);
    const [sameForAllDays, setSameForAllDays] = useState(false);
    const [editAvailability, setEditAvailability] = useState(false);
    const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const slotsData = useSelector((state) => state?.user?.expertUser?.slots)

    useEffect(() => {
        if (slotsData?.length) {
            setGeneratedSlots(slotsData)
            const days = slotsData.map(slot => slot.day);
            const interval = slotsData.length > 0 ? slotsData[0].interval : '';
            setSelectedDays(days);
            setTimeInterval(interval);

            // Extract start and end times from the first item in slotsData(assuming they are the same for all days)
            const firstDayData = slotsData[0];
            const commonStartTime = firstDayData ? firstDayData.startTime : '';
            const commonEndTime = firstDayData ? firstDayData.endTime : '';

            // // Format the Date objects into a desired string format
            const formattedStartTime = commonStartTime ? moment(commonStartTime, 'hh:mm A') : '';
            const formattedEndTime = commonEndTime ? moment(commonEndTime, 'hh:mm A') : '';

            // // Set the start and end times in the state
            setStartTime(formattedStartTime);
            setEndTime(formattedEndTime);
        }
    }, [slotsData])

    const isEndTimeDiabale = () => {
        if (startTime)
            return false;
        return true;
    };


    const handleTimeIntervalChange = (e) => {
        setTimeInterval(e.target.value);
    };

    const handleDayChange = (e) => {
        const day = e.target.value;
        const isChecked = e.target.checked;

        setSelectedDays((prevSelectedDays) => {
            let updatedSelectedDays;

            if (isChecked) {
                updatedSelectedDays = [...prevSelectedDays, day];
            } else {
                updatedSelectedDays = prevSelectedDays.filter((d) => d !== day);
            }

            const isAllDaysSelected = updatedSelectedDays.length === 7;

            setSameForAllDays(isAllDaysSelected);

            return updatedSelectedDays;
        });
    };

    const handleStartTimeChange = (value) => {
        console.log(value);
        setStartTime(value ? new moment(value, ["HH.mm"]).format("hh:mm A") : null);
    };

    const handleEndTimeChange = (value) => {
        setEndTime(value ? new moment(value, ["HH.mm"]).format("hh:mm A") : null);
    };

    useEffect(() => {
        generateSlots();
    }, [endTime, startTime, timeInterval, selectedDays]);

    const generateSlotsUTC = () => {
        const slots = selectedDays.map((day) => {
            const startTimeMoment = moment(startTime, ['HH:mm']).utc();
            const endTimeMoment = moment(endTime, ['HH:mm']).utc();
            const interval = parseInt(timeInterval, 10);

            const timeSlots = [];
            let currentTimeMoment = startTimeMoment.clone();

            while (currentTimeMoment.isBefore(endTimeMoment)) {
                const slotStartTime = currentTimeMoment.format('hh:mm A');
                currentTimeMoment.add(interval, 'minutes');
                const slotEndTime = currentTimeMoment.format('hh:mm A');

                timeSlots.push({
                    enabled: true,
                    slotId: timeSlots.length + 1,
                    label: `${slotStartTime} - ${slotEndTime} `,
                    start_time: `${slotStartTime} `,
                    end_time: `${slotEndTime} `,
                });
            }

            return {
                enabled: true,
                day,
                startTime: startTimeMoment.format('hh:mm A'),
                endTime: endTimeMoment.format('hh:mm A'),
                interval,
                time: timeSlots,
            };
        });

        setGeneratedSlots(slots);
    };

    const generateSlots = () => {
        const slots = selectedDays.map((day) => {
            const startTimeMoment = moment(startTime, ['hh:mm A']);
            const endTimeMoment = moment(endTime, ['hh:mm A']);
            const interval = parseInt(timeInterval, 10);

            const timeSlots = [];
            let currentTimeMoment = startTimeMoment.clone();

            while (currentTimeMoment.isBefore(endTimeMoment) || currentTimeMoment.isSame(endTimeMoment)) {
                const slotStartTime = currentTimeMoment.format('hh:mm A');
                currentTimeMoment.add(interval, 'minutes');
                const slotEndTime = currentTimeMoment.format('hh:mm A');

                if (currentTimeMoment.isBefore(endTimeMoment) || currentTimeMoment.isSame(endTimeMoment)) {
                    timeSlots.push({
                        enabled: true,
                        slotId: timeSlots.length + 1,
                        label: `${slotStartTime} - ${slotEndTime}`,
                        start_time: slotStartTime,
                        end_time: slotEndTime,
                    });
                }
            }

            return {
                enabled: true,
                day,
                startTime: startTimeMoment.format('hh:mm A'),
                endTime: endTimeMoment.format('hh:mm A'),
                interval,
                time: timeSlots,
            };
        });

        setGeneratedSlots(slots);
    };
    const handleSameForAllDaysChange = (e) => {
        const isChecked = e.target.checked;
        setSameForAllDays(isChecked);

        if (isChecked) {
            const allDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
            setSelectedDays(allDays);
        } else {
            setSelectedDays([]);
        }
    };

    const handleRemoveTimeSlot = (dayToRemove, slotToRemove) => {
        const updatedGeneratedSlots = generatedSlots.map((slot) => {
            if (slot.day === dayToRemove) {
                slot.time = slot.time.filter((timeSlot) => timeSlot.slotId !== slotToRemove);
            }
            return slot;
        });

        setGeneratedSlots(updatedGeneratedSlots);
    };

    const handleEdit = (e) => {
        e.preventDefault()
        setEditAvailability(true)
    }

    const handleAvailabilityUpdate = async (e) => {
        e.preventDefault()
        const payload = {
            "slots": generateSlots
        }
        try {
            let response

            setIsLoader(true)
            response = await authenticationExpertServices.updateAvailability(payload);
            if (response.data.status === 200) {
                setEditAvailability(false)
                setIsLoader(false)
                toast.success(response.data.message, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        } catch (error) {
            setIsLoader(false)
            toast.error(error, {
                position: toast.POSITION.TOP_RIGHT,
            });
        }
    }
    return (
        <>
            {IsLoader && <SpinnerLoader />}
            <div className='expert-availability'>
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className="parent-div">
                        <ExpertSidebar />
                        <div className="child-div">
                            <div className="container-table">
                                <div className="form-data-container">

                                    <Form >
                                        <Row>


                                            <Col md={6}>
                                                <div className="form-group mb-1">
                                                    <label>Time Slot</label>
                                                </div>
                                                <Input
                                                    type='select'
                                                    id='exampleSlect'
                                                    disabled={!editAvailability}
                                                    onChange={handleTimeIntervalChange}
                                                    value={timeInterval}
                                                >
                                                    <option value="">Select Time</option>
                                                    <option value="15">15 min</option>
                                                    <option value="30">30 min</option>
                                                    <option value="45">45 min</option>
                                                    <option value="60">60 min</option>
                                                </Input>
                                            </Col>
                                            <Col md={6} className="d-flex align-items-end justify-content-end" >
                                                <div className="form-group mb-1">
                                                    <label></label>
                                                </div>
                                                {!editAvailability
                                                    ?

                                                    < Button color="primary" style={{ width: '150px' }} onClick={handleEdit}>Edit</Button>
                                                    :
                                                    < Button color="primary" style={{ width: '150px' }} onClick={handleAvailabilityUpdate}>Update</Button>
                                                }
                                            </Col>
                                        </Row>
                                        <h6 className='mt-2'>Select day</h6>
                                        <div className='gender-radiotype'>
                                            {daysOfWeek.map((day) => (
                                                <FormGroup check key={day}>
                                                    <Input
                                                        name={day}
                                                        type="checkbox"
                                                        value={day}
                                                        disabled={!editAvailability}
                                                        onChange={handleDayChange}
                                                        checked={selectedDays.includes(day)}
                                                    />
                                                    <Label check>{day}</Label>
                                                </FormGroup>
                                            ))}
                                        </div>

                                    </Form>

                                    <div className="time-slot mt-3 d-flex">
                                        <div className="form-group ">
                                            <label>Start Time</label>
                                            <TimePicker
                                                showSecond={false}
                                                className="timePickerClass "
                                                onOpen={() => setPickerOpen(true)}
                                                onAmPmChange={() => setPickerOpen(!open)}
                                                format={format}
                                                use12Hours
                                                open={open}
                                                allowEmpty
                                                disabled={selectedDays.length === 0 || !timeInterval || !editAvailability}
                                                placeholder="--:-- --"
                                                value={
                                                    startTime ? new moment(startTime, "HH:mm A").local() : null
                                                }
                                                onChange={handleStartTimeChange}
                                            />
                                        </div>


                                        <div className="form-group mx-4">
                                            <label>End Time</label>

                                            <TimePicker
                                                showSecond={false}
                                                disabled={isEndTimeDiabale() || !editAvailability}
                                                className=" timePickerClass "
                                                onAmPmChange={() => setPickerOpenEnd(!openEnd)}
                                                onOpen={() => setPickerOpenEnd(true)}
                                                format={format}
                                                use12Hours
                                                open={openEnd}
                                                allowEmpty
                                                placeholder="--:-- --"
                                                value={
                                                    endTime
                                                        ? new moment(endTime, "HH:mm A").local() : null
                                                }
                                                onChange={handleEndTimeChange}
                                            />
                                        </div>
                                        <FormGroup check>
                                            <Input name="gender" type="checkbox" disabled={!editAvailability} onChange={handleSameForAllDaysChange}
                                                checked={sameForAllDays} value="ntos" id="radioSaturday" />
                                            <Label check htmlFor="radioSaturday" className='same-label'>
                                                Same for all days
                                            </Label>
                                        </FormGroup>
                                    </div>

                                    <div className="slot-time-area mt-2">
                                        <div className="for-all-days">
                                            <Label>Time Slots (For all days)</Label>
                                        </div>

                                        <div className="box-time-slot">
                                            {generatedSlots && generatedSlots?.length > 0 && generatedSlots?.map((slot, index) => (
                                                <div className="form-group box mt-4 d-flex" key={index}>
                                                    <Row>
                                                        <div className="slot-contnet mb-2">
                                                            {/* <h5>{slot.day}</h5> */}
                                                            <h5>Time Slots {slot.day}</h5>
                                                        </div>
                                                        {slot?.time?.length ? slot?.time?.map((timeSlot) => (
                                                            <Col key={timeSlot.slotId} className='slot-col mx-3 mb-3'>
                                                                <label>{timeSlot.label}</label>
                                                                <span className="remove-icon" onClick={() => handleRemoveTimeSlot(slot.day, timeSlot.slotId)}>
                                                                    <CrossIcon />

                                                                </span>
                                                            </Col>
                                                        ))
                                                            : <Col className=' mx-3 mb-3'>
                                                                <label>Data not found</label>
                                                            </Col>}
                                                    </Row>
                                                </div>
                                            ))}
                                        </div>

                                    </div>
                                </div>
                                {/* <table className="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">Sun</th>
                                            <th scope="col">Mon</th>
                                            <th scope="col">Tue</th>
                                            <th scope='col'>Wed</th>
                                            <th scope='col'>Thu</th>
                                            <th scope="col">Fri</th>
                                            <th scope='col'>Sat</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row" style={{ background: "red", color: "white" }}>Unavailability
                                                <br />09:00 AM to 9:30 AM
                                            </th>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>

                                        </tr>
                                        <tr>
                                            <th scope="row" style={{ background: "red", color: "white" }}>Unavailability
                                                <br />09:00 AM to 9:30 AM
                                            </th>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "red", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "red", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>

                                        </tr>
                                        <tr>
                                            <th scope="row" style={{ background: "skyblue", color: "white" }}>Unavailability
                                                <br />09:00 AM to 9:30 AM
                                            </th>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "red", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>

                                        </tr>

                                        <tr>
                                            <th scope="row" style={{ background: "skyblue", color: "white" }}>Unavailability
                                                <br />09:00 AM to 9:30 AM
                                            </th>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "red", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>

                                        </tr>
                                        <tr>
                                            <th scope="row" style={{ background: "skyblue", color: "white" }}>Unavailability
                                                <br />09:00 AM to 9:30 AM
                                            </th>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>

                                        </tr>
                                        <tr>
                                            <th scope="row" style={{ background: "red", color: "white" }}>Unavailability
                                                <br />09:00 AM to 9:30 AM
                                            </th>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "red", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>
                                            <td style={{ background: "skyblue", color: "white" }}>Availability
                                                <br />09:00 AM to 9:30 AM</td>

                                        </tr>
                                    </tbody>
                                </table> */}
                            </div>
                        </div>
                    </div>
                </div>
            </div >

            <Footer />


        </>
    )
}

export default ExpertAvailability
