import React, { useState, useEffect } from 'react'
import { FormGroup, Input, Progress, Label, Button, Form, Row, Col } from 'reactstrap';
import tick from "../../../assests/images/check-circle-svgrepo-com (2).svg";
import blueTick from "../../../assests/images/blue-tick.svg";
import cpnLogo from "../../../assests/images/CPNHealthFINAL_fontembed.svg";
import Footer from '../../common/Footer/Footer';
import { useNavigate, Link } from 'react-router-dom';
import { useFormik } from "formik";
import * as Yup from "yup";
import { checkSpace } from "../../../utils";
import authenticationServices from "../../../services";
import { toast } from "react-toastify";
import { useDropzone } from 'react-dropzone'
import Badal from '../../../assests/images/upload-cloud-svgrepo-com.svg';
import { ReactComponent as Delete } from '../../../assests/images/delete-2-svgrepo-com (2).svg';


const ExpertUploadSignUp6 = (props) => {
    const navigate = useNavigate()
    const [IsLoader, setIsLoader] = useState(false);
    const [acceptPrivacy, setAcceptPrivacy] = useState(false)
    const [acceptTnC, setAcceptTnC] = useState(false)
    const [acceptedFiles, setAcceptedFiles] = useState([]);
    const [rejectedFiles, setRejectedFiles] = useState([]);

    const onDrop = (accepted, rejected) => {
        setAcceptedFiles(accepted);
        setRejectedFiles(rejected);
    };
    const { getRootProps, getInputProps } = useDropzone({
        accept: ['image/jpeg', 'image/png', 'image/gif', 'application/pdf'],
        maxSize: 20 * 1024 * 1024,
        multiple: false,
        onDrop,
    });

    const files = acceptedFiles.map(file => <div key={file.path} className='file-name'>{file.path}</div>);
    console.log("files", acceptedFiles);

    useEffect(() => {
        const expertSignupData = localStorage.getItem("expertSignupData")
            ? JSON.parse(localStorage.getItem("expertSignupData"))
            : "";
        const { email, password } = expertSignupData
        if (!email || !password) {
            navigate('/signup-as-expert-5')
        }
    }, [])

    const formik = useFormik({
        initialValues: {
            fullName: "",
        },
        validationSchema: Yup.object({

        }),

        onSubmit: async (values) => {
            const expertSignupData = localStorage.getItem("expertSignupData")
                ? JSON.parse(localStorage.getItem("expertSignupData"))
                : "";
            if (acceptedFiles.length) {
                navigate('/signup-as-expert-7')

            } else {
                toast.error("Please upload File", {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }

        }
    });

    const clearUpload = () => {
        setAcceptedFiles([])
    }



    return (

        <>
         <div className='Expert-Sign-Up4'>
            <div className="container">
                <div className="logo-container">
                    <div className="logo-cpn">
                        <img src={cpnLogo} alt="Logo" />
                    </div>
                    <div className="login-button">
                        <Link to="/login-as-patient">
                            <Button>
                                Login
                            </Button>
                        </Link>
                    </div>
                </div>
                <div className="otp-input">

                    <Progress multi>
                        <Progress
                            bar
                            value="33.33"
                            style={{
                                height: '5px'
                            }}
                        />
                        <Progress
                            bar
                            color="success"
                            value="33.33"

                        />
                        <Progress
                            bar
                            color="info"
                            value="33.33"

                        />
                    </Progress>
                </div>
                <div className="text-sign-up">
                    <h1>Sign Up as a Expert Consultants</h1>
                </div>
                <div className="text-sign-up-2">
                <img src={tick} alt="" />
                            <h1>Upload W-9</h1>
                </div>
            </div>
            <div className="container mb-5">
                <div className="content-date">
                    <div className="login-detail">
                        <div className="login-detail-img">
                            <img src={tick} alt="" />
                            <h1>Login Details</h1>
                        </div>
                        <div className="login-detail-img2-data">
                            <img src={tick} alt="" />
                            <h1>Personal Details</h1>
                        </div>
                        <div className="login-detail-img2-data">
                            <img src={tick} alt="" />
                            <h1>Professional Details</h1>
                        </div>
                        <div className="login-detail-img2-data" >
                            <img src={tick} alt="" />
                            <h1>Employment Details</h1>
                        </div>
                        <div className="login-detail-img2-data">
                            <img src={tick} alt="" />
                            <h1>Availability & Payment Method</h1>
                        </div>
                        <div className="login-detail-img2-data">
                            <img src={tick} alt="" />
                            <h1>Upload W-9</h1>
                        </div>
                        <div className="login-detail-img3-data" style={{ opacity: '0.32' }}>
                            <img src={tick} alt="" />
                            <h1>Sign HIPAA/GDPR Agreement & CPN Agreement</h1>

                        </div>
                    </div>
                    <div className="form-data-container">

                        <Form onSubmit={formik.handleSubmit}>
                            <FormGroup>
                                <Label for="">
                                    Upload W-9
                                </Label>
                                <div {...getRootProps({ className: 'dropzone' })}>
                                    <img src={Badal} />
                                    <h6>Browse FIle</h6>
                                    <p>(PDF, PNG, JPG and Gif files are allowed)</p>
                                    <p>Maximum file size is 20MB</p>
                                </div>
                                {/* <aside>
                                    <ul>{files}</ul>
                                </aside> */}
                            </FormGroup>

                            <FormGroup>

                                {acceptedFiles.length > 0 && (
                                    <div className="file-name">
                                        {acceptedFiles[0].name}
                                        <Delete className="delete-upload" onClick={clearUpload} />
                                    </div>
                                )}
                                {rejectedFiles.length > 0 && (
                                    <small className="validation_error">
                                        File size exceeds the limit of 20MB.
                                    </small>

                                )}


                            </FormGroup>

                            <Button className='btn-secondry' type='submit'>
                                Next
                            </Button>
                        </Form>


                    </div>
                </div>
            </div>
            
        </div>
        <Footer />
        </>
       
    )
}

export default ExpertUploadSignUp6