import React, { useState, useEffect } from 'react'
import { FormGroup, Input, Progress, Label, Button, Form } from 'reactstrap';
import tick from "../../../assests/images/check-circle-svgrepo-com (2).svg";
import blueTick from "../../../assests/images/blue-tick.svg";
import cpnLogo from "../../../assests/images/CPNHealthFINAL_fontembed.svg";
import Footer from '../../common/Footer/Footer';
import { useNavigate, Link } from 'react-router-dom';
import { useFormik } from "formik";
import * as Yup from "yup";
import { checkSpace } from "../../../utils";
import authenticationServices from "../../../services";
import { toast } from "react-toastify";

const ExpertSignHipaaSignUp7 = () => {
    const navigate = useNavigate()
    const [IsLoader, setIsLoader] = useState(false);
    const [acceptPrivacy, setAcceptPrivacy] = useState(false)
    const [acceptTnC, setAcceptTnC] = useState(false)
    useEffect(() => {
        const expertSignupData = localStorage.getItem("expertSignupData")
            ? JSON.parse(localStorage.getItem("expertSignupData"))
            : "";
        const { email, password } = expertSignupData
        if (!email || !password) {
            navigate('/signup-as-expert-7')
        }
    }, [])

    const formik = useFormik({
        initialValues: {
            fullName: "",
        },
        validationSchema: Yup.object({
            fullName: Yup.string()
                .required("*First name is required.")
                .min(3, "minimum three character are required."),
        }),

        onSubmit: async (values) => {
            const expertSignupData = localStorage.getItem("expertSignupData")
                ? JSON.parse(localStorage.getItem("expertSignupData"))
                : "";
            if (!acceptPrivacy) {
                toast.error("Please select Data privacy aggrement", {
                    position: toast.POSITION.TOP_RIGHT,
                });
                return
            }
            else if (!acceptTnC) {
                toast.error("Please select Terms & conditions", {
                    position: toast.POSITION.TOP_RIGHT,
                });
                return
            } else {
                const payload = {
                    ...expertSignupData,
                    fullName: values.fullName
                };
                navigate("/expert-availability")
            }
        }
    });



    return (
        <div className='Expert-Sign-Up-5'>
            <div className="container">
                <div className="logo-container">
                    <div className="logo-cpn">
                        <img src={cpnLogo} alt="Logo" />
                    </div>
                    <div className="login-button">
                        <Link to="/login-as-patient">
                            <Button>
                                Login
                            </Button>
                        </Link>
                    </div>
                </div>
                <div className="otp-input">

                    <Progress multi>
                        <Progress
                            bar
                            value="33.33"
                            style={{
                                height: '5px'
                            }}
                        />
                        <Progress
                            bar
                            color="success"
                            value="33.33"

                        />
                        <Progress
                            bar
                            color="info"
                            value="33.33"

                        />
                    </Progress>
                </div>
                <div className="text-sign-up">
                    <h1>Sign Up as a Expert Consultants</h1>
                </div>
            </div>
            <div className="container">
                <div className="content-date">
                <div className="login-detail mb-4">
                        <div className="login-detail-img">
                            <img src={tick} alt="" />
                            <h1>Login Details</h1>
                        </div>
                        <div className="login-detail-img2-data">
                            <img src={tick} alt="" />
                            <h1>Personal Details</h1>
                        </div>
                        <div className="login-detail-img2-data">
                            <img src={tick} alt="" />
                            <h1>Professional Details</h1>
                        </div>
                        <div className="login-detail-img2-data" >
                            <img src={tick} alt="" />
                            <h1>Employment Details</h1>
                        </div>
                        <div className="login-detail-img2-data">
                            <img src={tick} alt="" />
                            <h1>Availability & Payment Method</h1>
                        </div>
                        <div className="login-detail-img2-data">
                            <img src={tick} alt="" />
                            <h1>Upload W-9</h1>
                        </div>
                        <div className="login-detail-img3-data" style={{ opacity: '1' }}>
                            <img src={tick} alt="" />
                            <h1>Sign HIPAA/GDPR Agreement & CPN Agreement</h1>

                        </div>
                    </div>
                
                    <div className="form-data-container">

                        <Form onSubmit={formik.handleSubmit}>
                            <h6 className='sign-line'>Please read and sign agreement before proceeding</h6>
                            <FormGroup check>
                                <Input type="checkbox" onChange={(e) => setAcceptPrivacy(e.target.checked)} checked={acceptPrivacy} />
                                {' '}
                                <Label check>
                                    <Link to=""> Data Privacy Agreement</Link>
                                </Label>
                            </FormGroup>
                            <FormGroup check>
                                <Input type="checkbox" onChange={(e) => setAcceptTnC(e.target.checked)} checked={acceptTnC} />
                                {' '}
                                <Label check>
                                    <Link to=""> Terms & Conditions</Link>
                                </Label>
                            </FormGroup>
                            <FormGroup>
                                <div className="signagreement-c">
                                    <Label for="exampleAddress" className='exampleaddress'>
                                        Sign Agreement
                                    </Label>
                                    <Input
                                        id="exampleAddress"
                                        name="Sign Agreement"
                                        placeholder="Enter Full Name"
                                        type="text"
                                        {...formik.getFieldProps("fullName")}
                                        onKeyDown={checkSpace}
                                        className={formik.touched.fullName && formik.errors.fullName ? 'is-invalid' : ""}
                                    />
                                    {formik.touched.fullName && formik.errors.fullName ? <small className="validation_error">{formik.errors.fullName}</small> : null}

                                </div>
                            </FormGroup>



                            <Button className='btn-secondry mb-4' type='submit'>
                                Submit
                            </Button>
                        </Form>
                        
                    </div>
                </div>
            </div>
            <Footer />
        </div>
    )
}

export default ExpertSignHipaaSignUp7