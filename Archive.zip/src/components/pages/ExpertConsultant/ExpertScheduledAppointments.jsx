import React, { useEffect, useState } from 'react'
import { Progress, Form, FormGroup, Button, Modal, ModalHeader, ModalBody, ModalFooter, Input, Label } from 'reactstrap'
import { Link, useNavigate } from 'react-router-dom'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import Logoimage from '../../../assests/images/ys.png'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import Sidebar from '../../common/Sidebar/Sidebar'
import ExpertSidebar from '../../common/ExpertSidebar/ExpertSidebar'
import authenticationExpertServices from "../../../services/expertServices";
import { toast } from "react-toastify";
import SpinnerLoader from '../../common/Spinner';
import { useSelector, useDispatch } from 'react-redux';


const ExpertScheduledAppoint = () => {

    const [open1, setOpen1] = useState(false);
    const [open2, setOpen2] = useState(false);
    const [open3, setOpen3] = useState(false);
    const [open4, setOpen4] = useState(false);
    const surveyToggle = () => { setOpen1(!open1) };
    const summaryToggle = () => { setOpen2(!open2) };
    const initialToggle = () => { setOpen3(!open3) };
    const notesToggle = () => { setOpen4(!open4) };
    const navigate = useNavigate();

    const handleCall = () => {

        navigate(`/video-call/65083c187852bf8b0d1704dc/65083bfe7852bf8b0d1704d3/video/outgoing`, { 'path': "WFCM" });
        // saveToSessionStorage(
        //     "callerDetails",
        //     JSON.stringify({
        //         fullName: `${UpcomingAppointsList?.patientId?.firstName} ${UpcomingAppointsList?.patientId?.lastName}`,
        //         profilePic: UpcomingAppointsList?.patientId?.profilePic,
        //     })
        // );

    };
    const [IsLoader, setIsLoader] = useState(false);
    const userData = useSelector((state) => state.user.data);
    const [allsurvey, setAllsurvey] = useState([]);

    const AllSurvey = async () => {
        try {
            setIsLoader(true);
            let res = await authenticationExpertServices.getAllSurvey();
            console.log("getAllSurvey ===>>", res);
            if (res.data.status === 200) {
                const result = res.data.survey[0]?.questions;
                setAllsurvey(result);
                setIsLoader(false);
                toast.success(res.data.message, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            } else {
                setIsLoader(false);
                toast.error(res.data.message, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        } catch (error) {
            toast.error(error, {
                position: toast.POSITION.TOP_RIGHT,
            });
        }
    }

    useEffect(() => {
        AllSurvey();
    }, []);
    console.log(allsurvey)
    return (
        <>
            <div className='expert-scheduled-appoint'>
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className="parent-div">
                        <ExpertSidebar />
                        <div className="child-div">
                            <div className="container-table">

                                <table className="table table-bordered">
                                    <thead>
                                        <tr>

                                            <th scope="col">Name</th>
                                            <th scope="col">Age</th>
                                            <th scope="col"> Date</th>
                                            <th scope='col'> Appoint ID</th>
                                            <th scope='col'>Appoint Status</th>
                                            <th scope='col'>Payment Status</th>
                                            <th scope='col'>Call Status</th>
                                            <th scope='col'>Case Summary</th>
                                            <th scope='col'>Survey & Notes</th>
                                            <th scope='col'>History</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>

                                            <td>Ali Ahmad</td>
                                            <td>32</td>
                                            <td>25 May, 2023</td>
                                            <td>NFGETG</td>
                                            <td>Scheduled</td>
                                            <td>-</td>
                                            <td onClick={handleCall}><Link > Initiate Call</Link></td>
                                            {/* <td><a href='#' onClick={initialToggle}> Initiate Call</a></td> */}
                                            <td><a href='#' onClick={summaryToggle} > CPINS Notes </a></td>
                                            <td><a href='#' onClick={surveyToggle}> Survey</a></td>
                                            <td><a href='#'> View</a></td>
                                        </tr>
                                        <tr>
                                            <td>Shahnawaz</td>
                                            <td>32</td>
                                            <td>25 May, 2023</td>
                                            <td>NFGETG</td>
                                            <td>Scheduled</td>
                                            <td>Pending</td>
                                            <td><a href='#'> Initiate Call</a></td>
                                            <td><a href='#'> CPINS Notes </a></td>
                                            <td><a href='#' onClick={notesToggle}> Notes </a></td>
                                            <td><a href='#'> View</a></td>
                                        </tr>
                                        <tr>
                                            <td>Saqlain</td>
                                            <td>32</td>
                                            <td>25 May, 2023</td>
                                            <td>NFGETG</td>
                                            <td>Completed</td>
                                            <td>Paid</td>
                                            <td><a href='#'> Initiate Call</a></td>
                                            <td><a href='#'> CPINS Notes </a></td>
                                            <td><a href='#'> Survey</a></td>
                                            <td><a href='#'> View</a></td>
                                        </tr>
                                        <tr>
                                            <td>Usama</td>
                                            <td>32</td>
                                            <td>25 May, 2023</td>
                                            <td>NFGETG</td>
                                            <td>Scheduled</td>
                                            <td>-</td>
                                            <td><a href='#'> Initiate Call</a></td>
                                            <td><a href='#'> CPINS Notes </a></td>
                                            <td><a href='#'> Notes</a></td>
                                            <td><a href='#'> View</a></td>
                                        </tr>
                                        <tr>
                                            <td>Shoeb</td>
                                            <td>32</td>
                                            <td>25 May, 2023</td>
                                            <td>NFGETG</td>
                                            <td>Completed</td>
                                            <td>Pending</td>
                                            <td><a href='#'> Initiate Call</a></td>
                                            <td><a href='#'> CPINS Notes </a></td>
                                            <td><a href='#'> Survey</a></td>
                                            <td><a href='#'> View</a></td>
                                        </tr>
                                        <tr>
                                            <td>Akhtar</td>
                                            <td>32</td>
                                            <td>25 May, 2023</td>
                                            <td>NFGETG</td>
                                            <td>Scheduled</td>
                                            <td>Paid</td>
                                            <td><a href='#'> Initiate Call</a></td>
                                            <td><a href='#'> CPINS Notes </a></td>
                                            <td><a href='#'> Notes</a></td>
                                            <td><a href='#'> View</a></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <Footer />
            <div>
                {/* <Modal isOpen={open1} toggle={surveyToggle} className="custom-modal" centered>
                    <div className="modal-overlay">
                        <ModalHeader toggle={surveyToggle}> Fill Survey </ModalHeader>
                        <ModalBody>

                            <div className="text-start statusBx w-100">
                                <FormGroup>
                                    <div className="modal-para-1">
                                        <p> Lorem Ipsum has been the industry's standard?
                                            <span className="radio-container" style={{ justifyContent: "flex-end", marginLeft: "20px" }}>
                                                <label style={{ padding: "0px 20px" }}>
                                                    <input type="radio" name="option" value="yes" style={{ margin: "0px" }} /> Yes
                                                </label>
                                                <label>
                                                    <input type="radio" name="option" value="no" /> No
                                                </label>
                                            </span>
                                        </p>
                                    </div>
                                    <hr />
                                    <div className="modal-para-2">
                                        <p> Lorem Ipsum has been the industry's standard?
                                            <span className="radio-container" style={{ justifyContent: "flex-end", marginLeft: "20px" }}>
                                                <label style={{ padding: "0px 20px" }}>
                                                    <input type="radio" name="option" value="yes" style={{ margin: "0px" }} /> Yes
                                                </label>
                                                <label>
                                                    <input type="radio" name="option" value="no" /> No
                                                </label>
                                            </span>
                                        </p>
                                    </div>
                                    <hr />
                                    <div className="modal-para-3">
                                        <p> Lorem Ipsum has been the industry's standard?
                                            <span className="radio-container" style={{ justifyContent: "flex-end", marginLeft: "20px" }}>
                                                <label style={{ padding: "0px 20px" }}>
                                                    <input type="radio" name="option" value="yes" style={{ margin: "0px" }} /> Yes
                                                </label>
                                                <label>
                                                    <input type="radio" name="option" value="no" /> No
                                                </label>
                                            </span>
                                        </p>
                                    </div>
                                    <hr />
                                    <div className="modal-para-4">
                                        <p> Lorem Ipsum has been the industry's standard?
                                            <span className="radio-container" style={{ justifyContent: "flex-end", marginLeft: "20px" }}>
                                                <label style={{ padding: "0px 20px" }}>
                                                    <input type="radio" name="option" value="yes" style={{ margin: "0px" }} /> Yes
                                                </label>
                                                <label>
                                                    <input type="radio" name="option" value="no" /> No
                                                </label>
                                            </span>
                                        </p>
                                    </div>
                                    <hr />
                                    <div className="modal-para-5">
                                        <p> Lorem Ipsum has been the industry's standard?
                                            <span className="radio-container" style={{ justifyContent: "flex-end", marginLeft: "20px" }}>
                                                <label style={{ padding: "0px 20px" }}>
                                                    <input type="radio" name="option" value="yes" style={{ margin: "0px" }} /> Yes
                                                </label>
                                                <label>
                                                    <input type="radio" name="option" value="no" /> No
                                                </label>
                                            </span>
                                        </p>
                                    </div>

                                </FormGroup>
                            </div>

                            <Button style={{
                                background: "#3A63B5 0% 0% no-repeat padding-box",
                                width: "100%"
                            }} onClick={() => { surveyToggle() }}>Submit</Button>

                        </ModalBody>
                    </div>
                </Modal> */}
                {open1 && (
                    <Modal isOpen={open1} toggle={surveyToggle} className="custom-modal" centered>
                        <div className="modal-overlay">
                            <ModalHeader toggle={surveyToggle}> Fill Survey </ModalHeader>
                            <ModalBody>
                                <div className="text-start statusBx w-100">
                                    <form>
                                        {allsurvey && allsurvey?.length > 0 ? (
                                            allsurvey?.map((surveyItem, index) => (
                                                <>
                                                    <div className="modal-para-1 d-flex" key={index}>
                                                        <p className='Question-type' style={{ flex: 1 }}>
                                                            {surveyItem?.questionText}
                                                            <hr style={{ width: "100%", marginBottom: "0" }} />
                                                        </p>
                                                        <span className="radio-container">
                                                            {surveyItem?.options.map((option) => (
                                                                <Label key={option} style={{ marginRight: "10px" }}>
                                                                    <input type="radio" name={`option-${index}`} value={option} style={{ margin: "0px 10px" }} />
                                                                    {option}
                                                                    <hr style={{ width: "100%", marginBottom: "0" }} />
                                                                </Label>
                                                            ))}
                                                        </span>
                                                    </div>


                                                </>

                                            ))
                                        ) : (
                                            <p>No survey data available.</p>
                                        )}
                                    </form>
                                </div>
                                <Button
                                    style={{
                                        background: "#3A63B5 0% 0% no-repeat padding-box",
                                        width: "100%"
                                    }}
                                    onClick={() => { surveyToggle() }}
                                >
                                    Submit
                                </Button>
                            </ModalBody>
                        </div>
                    </Modal>
                )}

            </div>
            {/* CPINS Modal */}
            <div>
                <Modal isOpen={open2} toggle={summaryToggle} className="custom-modal" centered>
                    <div className="modal-overlay">
                        <ModalHeader toggle={summaryToggle}> Case Summary </ModalHeader>
                        <ModalBody>

                            <div className="text-start statusBx w-100">
                                <FormGroup>
                                    <div className="modal-para-1">
                                        <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
                                            industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and
                                            scrambled it to make a type specimen book.
                                        </p>
                                    </div>


                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's
                                        standard dummy text ever since the 1500s, when an unknown printer took a
                                        galley of type and scrambled it to make a type specimen book.
                                    </p>
                                </FormGroup>
                            </div>


                        </ModalBody>
                    </div>
                </Modal>
            </div>

            {/* Initial call */}
            <div>
                <Modal isOpen={open3} toggle={initialToggle} className="custom-modal" centered>
                    <div className="modal-overlay">
                        <ModalHeader toggle={initialToggle}> Initiate Call </ModalHeader>
                        <ModalBody>

                            <div className="text-start statusBx w-100">
                                <FormGroup>
                                    <div className="modal-para-3">
                                        <h3>Expert Consultant <span> Dr. Muhammad Ibn Abdullah</span></h3>
                                    </div>
                                    <hr />
                                    <div className="modal-para-4">
                                        <h3>Date of Appointment <span>12/09/2023</span></h3>
                                    </div>
                                    <hr />
                                    <div className="modal-para-4">
                                        <h3>Time of Appointment <span>11:00 AM (EST)</span></h3>
                                    </div>
                                </FormGroup>
                            </div>
                            <Link to={'/initiate-vedio-call'}>
                                <Button className='initialbutton' onClick={() => { initialToggle() }}>Initial Call</Button>

                            </Link>

                        </ModalBody>
                    </div>
                </Modal>
            </div>

            {/* Notes text Area Modal */}
            <div>
                <Modal isOpen={open4} toggle={notesToggle} className="custom-modal" centered>
                    <div className="modal-overlay">
                        <ModalHeader toggle={notesToggle} />
                        <ModalBody>
                            <div>
                                <h5>Note</h5>
                                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                                    <Input
                                        type='textarea'
                                        rows={5}
                                    ></Input>
                                </div>
                                <div >
                                    <Link to={'/initiate-call'}>
                                        <Button className='initialbutton'>Submit</Button>
                                    </Link>

                                </div>
                            </div>
                        </ModalBody>
                    </div>
                </Modal>
            </div>
        </>
    )
}

export default ExpertScheduledAppoint
