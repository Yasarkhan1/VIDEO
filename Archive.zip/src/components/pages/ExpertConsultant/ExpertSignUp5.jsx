import React, { useState, useEffect } from 'react'
import { FormGroup, Input, Progress, Label, Button, Form } from 'reactstrap';
import tick from "../../../assests/images/check-circle-svgrepo-com (2).svg";
import blueTick from "../../../assests/images/blue-tick.svg";
import cpnLogo from "../../../assests/images/CPNHealthFINAL_fontembed.svg";
import Footer from '../../common/Footer/Footer';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { useFormik } from "formik";
import * as Yup from "yup";
import { checkSpace, detectPlatform } from "../../../utils";
import { deviceToken } from "../../../getDeviceToken";
import authenticationExpertServices from "../../../services/expertServices";
import { toast } from "react-toastify";
import SpinnerLoader from '../../common/Spinner';

const ExpertSignUp5 = () => {
    const navigate = useNavigate()
    const location = useLocation()
    const profileImage = location?.state?.profileImage

    const WNine = location?.state?.WNine
    // console.log("useLocation_+_+_", location.state?.previousStepPayload);
    const previousStepPayload = location?.state?.previousStepPayload
    const [IsLoader, setIsLoader] = useState(false);
    const [acceptPrivacy, setAcceptPrivacy] = useState(false)
    const [acceptTnC, setAcceptTnC] = useState(false)

    const deviceType = detectPlatform()
    let devicetoken = "";
    deviceToken.subscribe((res) => {
        devicetoken = res;
    });

    useEffect(() => {
        const expertSignupData = localStorage.getItem("expertSignupData")
            ? JSON.parse(localStorage.getItem("expertSignupData"))
            : "";
        const { email, password } = expertSignupData
        if (!email || !password) {
            navigate('/signup-as-expert-7')
        }
    }, [])


    const formik = useFormik({
        initialValues: {
            signAggrement: "",
        },
        validationSchema: Yup.object({
            signAggrement: Yup.string()
                .required("*First name is required.")
                .min(3, "minimum three character are required."),
        }),

        onSubmit: async (values) => {
            const expertSignupData = localStorage.getItem("expertSignupData")
                ? JSON.parse(localStorage.getItem("expertSignupData"))
                : "";
            if (!acceptPrivacy) {
                toast.error("Please select Data privacy aggrement", {
                    position: toast.POSITION.TOP_RIGHT,
                });
                return
            }
            else if (!acceptTnC) {
                toast.error("Please select Terms & conditions", {
                    position: toast.POSITION.TOP_RIGHT,
                });
                return
            } else {
                const payload = {
                    ...expertSignupData,
                    signAggrement: values.signAggrement
                };
                try {
                    // console.log("Final expert signup payload=", payload);
                    const jsonData = payload
                    const formData = new FormData();
                    formData.append("email", jsonData.email);
                    formData.append("password", jsonData.password);
                    formData.append("personalDetails[name]", jsonData.name);
                    formData.append("personalDetails[address1]", jsonData.address1);
                    formData.append("personalDetails[address2]", jsonData.address2);
                    formData.append("personalDetails[city]", jsonData.city);
                    formData.append("personalDetails[state]", jsonData.state);
                    formData.append("personalDetails[country]", jsonData.country);
                    formData.append("personalDetails[zipCode]", jsonData.zip_code);
                    formData.append("image", profileImage);
                    formData.append("personalDetails[contactNumber]", jsonData.contactNumber);
                    formData.append("personalDetails[countryCode]", jsonData.countryCode);
                    formData.append("professionalDetails[specialty]", jsonData.speciality);
                    formData.append("professionalDetails[degree]", jsonData.degree);
                    formData.append("professionalDetails[institution][name]", jsonData.institution);
                    formData.append("professionalDetails[institution][from]", jsonData.institutionFrom);
                    formData.append("professionalDetails[institution][to]", jsonData.institutionTo);
                    formData.append("professionalDetails[residency][name]", jsonData.residency);
                    formData.append("professionalDetails[residency][from]", jsonData.residencyFrom);
                    formData.append("professionalDetails[residency][to]", jsonData.residencyTo);
                    formData.append("professionalDetails[fellowship][name]", jsonData.followship);
                    formData.append("professionalDetails[fellowship][from]", jsonData.followshipFrom);
                    formData.append("professionalDetails[fellowship][to]", jsonData.followshipTo);
                    formData.append("professionalDetails[currentCredentialing]", jsonData.currentCredentialing);
                    formData.append("professionalDetails[medicalLicenseNumber]", jsonData.medicalLicenseNumber);
                    formData.append("professionalDetails[years]", jsonData.years);
                    formData.append("employmentDetails[name]", jsonData.employerName);
                    formData.append("employmentDetails[address]", jsonData.employerAddress);
                    formData.append("employmentDetails[countryCode]", jsonData.empCountryCode);
                    formData.append("employmentDetails[contactNumber]", jsonData.employerContactNumber);
                    formData.append("employmentDetails[email]", jsonData.employerEmail);
                    formData.append("employmentDetails[currentRole]", jsonData.current_role);
                    formData.append("employmentDetails[areaOfExpertise]", jsonData.area_expertise);
                    formData.append("employmentDetails[professionalFee]", jsonData.professional_fees);
                    formData.append("hipaaAgreement[hipaaAgreement]", true);
                    formData.append("hipaaAgreement[cpnAgreement]", true);
                    formData.append("hipaaAgreement[signAgreement]", jsonData.signAggrement);
                    formData.append("status", "ACTIVE");
                    formData.append("paymentMethod", jsonData.paymentMethod);
                    formData.append("WNine", WNine);
                    formData.append("slots", JSON.stringify(jsonData.slots))
                    formData.append("deviceType", deviceType);
                    formData.append("deviceToken", devicetoken);
                    setIsLoader(true);
                    let res = await authenticationExpertServices.expertSignup(formData);
                    // console.log("signup result==", res);
                    if (res.data.status === 200) {
                        localStorage.clear()
                        toast.success(res.data.message, {
                            position: toast.POSITION.TOP_RIGHT,
                        });
                        navigate("/login-as-expert")
                    } else {
                        setIsLoader(false);
                        toast.error(res.data.message, {
                            position: toast.POSITION.TOP_RIGHT,
                        });
                    }
                } catch (error) {
                    toast.error(error, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                }
                // navigate("/login-as-expert")
            }
        }
    });



    return (

        <>
        <div className='Expert-Sign-Up-5'>
            {IsLoader && <SpinnerLoader />}
            <div className="container">
                <div className="logo-container">
                    <div className="logo-cpn">
                        <Link to="/">
                            <img src={cpnLogo} alt="Logo" />
                        </Link>
                    </div>
                    <div className="login-button">
                        <Link to="/login-as-expert">
                            <Button>
                                Login
                            </Button>
                        </Link>
                    </div>
                </div>
                <div className="otp-input">

                    <Progress multi>
                        <Progress
                            bar
                            value="33.33"
                            style={{
                                height: '5px'
                            }}
                        />
                        <Progress
                            bar
                            color="success"
                            value="33.33"

                        />
                        <Progress
                            bar
                            color="info"
                            value="33.33"

                        />
                    </Progress>
                </div>
                <div className="text-sign-up">
                    <h1>Sign Up as a Expert Consultants</h1>
                </div>

                <div className="text-sign-up-2">
                <img src={tick} alt="" />
                            <h1>Sign HIPAA/GDPR Agreement & CPN Agreement</h1>
                </div>
            </div>
            <div className="container">
                <div className="content-date">
                    <div className="login-detail mb-4">
                        <div className="login-detail-img">
                            <img src={tick} alt="" />
                            <h1>Login Details</h1>
                        </div>
                        <div className="login-detail-img2-data">
                            <img src={tick} alt="" />
                            <h1>Personal Details</h1>
                        </div>
                        <div className="login-detail-img2-data">
                            <img src={tick} alt="" />
                            <h1>Professional Details</h1>
                        </div>
                        <div className="login-detail-img2-data" >
                            <img src={tick} alt="" />
                            <h1>Employment Details</h1>
                        </div>
                        <div className="login-detail-img2-data">
                            <img src={tick} alt="" />
                            <h1>Availability & Payment Method</h1>
                        </div>
                        <div className="login-detail-img2-data">
                            <img src={tick} alt="" />
                            <h1>Upload W-9</h1>
                        </div>
                        <div className="login-detail-img3-data" style={{ opacity: '1' }}>
                            <img src={tick} alt="" />
                            <h1>Sign HIPAA/GDPR Agreement & CPN Agreement</h1>

                        </div>
                    </div>

                    <div className="form-data-container">

                        <Form onSubmit={formik.handleSubmit}>
                            <h6 className='sign-line'>Please read and sign agreement before proceeding</h6>
                            <FormGroup check>
                                <Input type="checkbox" onChange={(e) => setAcceptPrivacy(e.target.checked)} checked={acceptPrivacy} />
                                {' '}
                                <Label check>
                                    <Link to=""> Data Privacy Agreement</Link>
                                </Label>
                            </FormGroup>
                            <FormGroup check>
                                <Input type="checkbox" onChange={(e) => setAcceptTnC(e.target.checked)} checked={acceptTnC} />
                                {' '}
                                <Label check>
                                    <Link to=""> Terms & Conditions</Link>
                                </Label>
                            </FormGroup>
                            <FormGroup>
                                <div className="signagreement-c">
                                    <Label for="exampleAddress" className='exampleaddress'>
                                        Sign Agreement
                                    </Label>
                                    <Input
                                        id="exampleAddress"
                                        name="Sign Agreement"
                                        placeholder="Enter Full Name"
                                        type="text"
                                        {...formik.getFieldProps("signAggrement")}
                                        onKeyDown={checkSpace}
                                        className={formik.touched.signAggrement && formik.errors.signAggrement ? 'is-invalid' : ""}
                                    />
                                    {formik.touched.signAggrement && formik.errors.signAggrement ? <small className="validation_error">{formik.errors.signAggrement}</small> : null}

                                </div>
                            </FormGroup>



                            <Button className='btn-secondry mb-4' type='submit'>
                                Submit
                            </Button>
                        </Form>

                    </div>
                </div>
            </div>
           
        </div>

        <Footer />
        </>
        
    )
}

export default ExpertSignUp5