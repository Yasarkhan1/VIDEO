import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Row, Modal, ModalHeader, ModalBody, ModalFooter, Input, Button, Col } from 'reactstrap'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import Logoimage from '../../../assests/images/ys.png'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import ExpertSidebar from '../../common/ExpertSidebar/ExpertSidebar'
import 'font-awesome/css/font-awesome.min.css';

const ExpertMessageView = () => {
    return (
        <>

            <div className='expert-message-view'>
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className="parent-div">
                        <ExpertSidebar />
                        <div className="child-div">
                            <div className="all-content">
                                <Row className='text-detail-content'>

                                    <Col md={3}>

                                        <div className="text-patient-left">
                                            <h5>Patient</h5>
                                            <h6>(10/08/23, 11:30Am)</h6>
                                        </div>
                                    </Col>
                                    <Col md={6}>
                                        <div className="text-patient-right">
                                            <h6>I want to book appointment for cancer treatment asap.</h6>

                                        </div>
                                    </Col>

                                </Row>

                                <div className="reply-text-message text-center">
                                    <Col md={5} className="mx-auto">
                                        <Input
                                            type='text'
                                            placeholder='type here....' />
                                    </Col>

                                    <button className='submit'>Submit</button>


                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
            <Footer />
        </>
    )
}

export default ExpertMessageView
