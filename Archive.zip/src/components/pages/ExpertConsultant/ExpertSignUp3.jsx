import React, { useState, useEffect, useRef } from 'react'
import { FormGroup, Input, Label, Form, FormText, Button, Progress, Row, Col } from 'reactstrap';
import tick from "../../../assests/images/check-circle-svgrepo-com (2).svg";
import blueTick from "../../../assests/images/blue-tick.svg";
import cpnLogo from "../../../assests/images/CPNHealthFINAL_fontembed.svg";
import { ReactComponent as CrossIcon } from "../../../assests/images/close-circle-svgrepo-com.svg";
import calenderImg from "../../../assests/images/calender-svgrepo-com.svg";
import Footer from '../../common/Footer/Footer';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { useFormik } from "formik";
import * as Yup from "yup";
import { checkSpace } from "../../../utils";
import { toast } from "react-toastify";
import authenticationServices from "../../../services";
import SpinnerLoader from '../../common/Spinner';
function ExpertProfSignup3() {


    const navigate = useNavigate()
    const location = useLocation()
    // console.log("useLocation_+_+_", location.state?.image);
    const profileImage = location?.state?.image
    const [IsLoader, setIsLoader] = useState(false);
    const [dropDownData, setdropdownData] = useState([]);

    useEffect(() => {
        const step1Data = localStorage.getItem("expertSignupData")
            ? JSON.parse(localStorage.getItem("expertSignupData"))
            : "";
        const { email, password } = step1Data
        if (!email || !password) {
            // navigate('/signup-as-expert-1')
        } else {
            getPatchform();
        }
        getAlldropdownOptions();
    }, [])

    const getAlldropdownOptions = async () => {
        try {
            setIsLoader(true);
            let res = await authenticationServices.dropdownOptions();
            // console.log("getAlldropdownOptions>>>==", res);
            if (res.data.status === 200) {
                setIsLoader(false);
                const result = res.data.dropdownOptions
                setdropdownData(result)
                // dispatch(setAllDropDown(res.data.dropdownOptions))
                // dispatch(setUser(userData));
            }
        } catch (error) {
            setIsLoader(false);
            toast.error(error, {
                position: toast.POSITION.TOP_RIGHT,
            });
        }
    }

    // fill data in fields after back.
    const getPatchform = () => {
        const currentStepData = localStorage.getItem("expertSignupData")
            ? JSON.parse(localStorage.getItem("expertSignupData"))
            : "";
        // console.log("currentStepData++++", currentStepData);
        const { name } = currentStepData
        // console.log("Date: ", dateString);
        if (name) {
            formik.setValues({
                speciality: currentStepData?.speciality,
                degree: currentStepData?.degree,
                institution: currentStepData?.institution,
                institutionFrom: currentStepData?.institutionFrom,
                institutionTo: currentStepData?.institutionTo,
                residency: currentStepData?.residency,
                residencyFrom: currentStepData?.residencyFrom,
                residencyTo: currentStepData?.residencyTo,
                followship: currentStepData?.followship,
                followshipFrom: currentStepData?.followshipFrom,
                followshipTo: currentStepData?.followshipTo,
                currentCredentialing: currentStepData?.currentCredentialing,
                medicalLicenseNumber: currentStepData?.medicalLicenseNumber,
                years: currentStepData?.years,
            });
        }
    };

    const formik = useFormik({
        initialValues: {
            speciality: "",
            degree: "",
            institution: "",
            institutionFrom: "",
            institutionTo: "",
            residency: "",
            residencyFrom: "",
            residencyTo: "",
            followship: "",
            followshipFrom: "",
            followshipTo: "",
            currentCredentialing: "",
            medicalLicenseNumber: "",
            years: "",

        },
        validationSchema: Yup.object({
            speciality: Yup.string().required("Speciality is required"),
            degree: Yup.string().required("Degree is required"),
            institution: Yup.string().required("Institution is required"),
            institutionFrom: Yup.string().required("Please select"),
            institutionTo: Yup.string().required("Please select"),
            residency: Yup.string().required("Residency is required"),
            residencyFrom: Yup.string().required("Please select"),
            residencyTo: Yup.string().required("Please select"),
            followship: Yup.string().required("Followship is required"),
            followshipFrom: Yup.string().required("Please select"),
            followshipTo: Yup.string().required("Please select"),
            currentCredentialing: Yup.string().required("Current Credentialing is required"),
            medicalLicenseNumber: Yup.string()
                .required("Medical License Number is required")
                .matches(/^[1-9]{1}[0-9]{5}$/, "Enter 6 digit License Number"),
            // .matches(/^[A-Za-z]{1,2}\d{6}$/, "Enter valid License Number"),
            years: Yup.string().required("Year is required")
        }),

        onSubmit: async (values) => {
            const previousStepPayload = localStorage.getItem("expertSignupData")
                ? JSON.parse(localStorage.getItem("expertSignupData"))
                : "";
            const { email, password } = previousStepPayload
            const payload = {
                ...values,
                ...previousStepPayload
            };
            try {
                // console.log("patient details payload=", payload, JSON.stringify(payload));
                localStorage.setItem("expertSignupData", JSON.stringify(payload));
                navigate("/signup-as-expert-4", { state: { previousStepPayload: payload, profileImage: profileImage } })
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        }
    });

    // console.log(formik.errors, formik.touched);
    return (
        <>
        <div className='expert-professional-signup-3'>
            {IsLoader && <SpinnerLoader />}
            <div className="container">
                <div className="logo-container">
                    <div className="logo-cpn">
                        <img src={cpnLogo} alt="Logo" />
                    </div>
                    <div className="login-button">
                        <Link to="/login-as-expert">
                            <Button>
                                Login
                            </Button>
                        </Link>
                    </div>
                </div>
                <div className="otp-input">

                    <Progress multi>
                        <Progress
                            bar
                            value="33.33"
                            style={{
                                height: '5px'
                            }}
                        />
                        <Progress
                            bar
                            color="success"
                            value="33.33"

                        />
                        <Progress
                            bar
                            color="info"
                            value="33.33"

                        />
                    </Progress>
                </div>
                <div className="text-sign-up">
                    <h1>Sign Up as a Expert Consultants</h1>
                </div>
                {/* Mobile view Open */}
                <div className="text-sign-up-2">
                        <img src={tick} alt="" />
                        <h1>Professional Details</h1>
                    </div>
            </div>
            <div className="container">
                <div className="content-date">
                    <div className="login-detail">
                        <div className="login-detail-img">
                            <img src={tick} alt="" />
                            <h1>Login Details</h1>
                        </div>
                        <div className="login-detail-img2-data">
                            <img src={tick} alt="" />
                            <h1>Personal Details</h1>
                        </div>
                        <div className="login-detail-img2-data">
                            <img src={tick} alt="" />
                            <h1>Professional Details</h1>
                        </div>
                        <div className="login-detail-img2-data" style={{ opacity: '0.32' }}>
                            <img src={tick} alt="" />
                            <h1>Employment Details</h1>
                        </div>
                        <div className="login-detail-img2-data" style={{ opacity: '0.32' }}>
                            <img src={tick} alt="" />
                            <h1>Availability & Payment Method</h1>
                        </div>
                        <div className="login-detail-img2-data" style={{ opacity: '0.32' }}>
                            <img src={tick} alt="" />
                            <h1>Upload W-9</h1>
                        </div>
                        <div className="login-detail-img3-data">
                            <img src={tick} alt="" />
                            <h1>Sign HIPAA/GDPR Agreement & CPN Agreement</h1>

                        </div>
                    </div>
                    <div className="form-data-container">
                        <Form onSubmit={formik.handleSubmit}>
                            <FormGroup>
                                <Label for="exampleSelect">Speciality</Label>
                                <Input
                                    id="exampleSelect"
                                    name="speciality"
                                    type="select"
                                    {...formik.getFieldProps("speciality")}
                                    className={formik.touched.speciality && formik.errors.speciality ? 'is-invalid' : ""}
                                >
                                    <option value="">Select</option>
                                    {dropDownData?.specialtiesOption?.length ?
                                        dropDownData?.specialtiesOption?.map((item, ind) => (

                                            <option value={item.value} key={ind}>{item.label}</option>
                                        ))
                                        : ""
                                    }

                                </Input>
                                {formik.touched.speciality && formik.errors.speciality ? <small className="validation_error">{formik.errors.speciality}</small> : null}
                            </FormGroup>


                            <FormGroup>
                                <Label for="exampleSelect">Degree</Label>
                                <Input
                                    id="exampleSelect"
                                    name="degree"
                                    type="select"
                                    // {...formik.getFieldProps("degree")}
                                    // value={formik.values.degree}
                                    // onChange={(e) => { // Update the selected degree ID
                                    //     formik.handleChange(e); // Update Formik's state
                                    // }}
                                    // onBlur={formik.handleBlur}
                                    {...formik.getFieldProps("degree")}
                                    className={formik.touched.degree && formik.errors.degree ? 'is-invalid' : ""}

                                >
                                    <option value="">Select</option>
                                    {dropDownData?.medicalCourseOptions?.length ?
                                        dropDownData?.medicalCourseOptions?.map((item, ind) => (

                                            <option value={item.value} key={ind}>{item.label}</option>
                                        ))
                                        : ""
                                    }

                                </Input>
                                {formik.touched.degree && formik.errors.degree ? <small className="validation_error">{formik.errors.degree}</small> : null}
                            </FormGroup>
                            <FormGroup>
                                <Label>
                                    Name of Institution/ University
                                </Label>
                                <Input
                                    id='exampletext'
                                    type='text'
                                    name='institution'
                                    {...formik.getFieldProps("institution")}
                                    className={formik.touched.institution && formik.errors.institution ? 'is-invalid' : ""}
                                    placeholder='Enter Name of Institution/ University'
                                />
                                {formik.touched.institution && formik.errors.institution ? <small className="validation_error">{formik.errors.institution}</small> : null}
                            </FormGroup>


                            <Row>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label>Year</Label>
                                        <Input
                                            id="institutionFrom"
                                            name="institutionFrom"
                                            className={formik.touched.institutionFrom && formik.errors.institutionFrom ? 'is-invalid' : ""}
                                            type="select"
                                            {...formik.getFieldProps("institutionFrom")}
                                        >
                                            <option value="">Select From</option>
                                            {dropDownData?.year?.length ?
                                                dropDownData?.year?.map((item, ind) => (

                                                    <option value={item.value} key={ind}>{item.label}</option>
                                                ))
                                                : ""
                                            }
                                        </Input>
                                        {formik.touched.institutionFrom && formik.errors.institutionFrom ? <small className="validation_error">{formik.errors.institutionFrom}</small> : null}
                                    </FormGroup>
                                </Col>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label><br /></Label>
                                        <Input
                                            id="institutionTo"
                                            name="institutionTo"
                                            className={formik.touched.institutionTo && formik.errors.institutionTo ? 'is-invalid' : ""}
                                            type="select"
                                            {...formik.getFieldProps("institutionTo")}
                                        >

                                            <option value="">Select To</option>
                                            {dropDownData?.year?.length ?
                                                dropDownData?.year?.map((item, ind) => (

                                                    <option value={item.value} key={ind}>{item.label}</option>
                                                ))
                                                : ""
                                            }

                                        </Input>
                                        {formik.touched.institutionTo && formik.errors.institutionTo ? <small className="validation_error">{formik.errors.institutionTo}</small> : null}
                                    </FormGroup>
                                </Col>
                            </Row>
                            <FormGroup>
                                <Label for='exampleresidency'>
                                    Residency
                                </Label>
                                <Input
                                    id='exampleresidency'
                                    name='residency'
                                    placeholder='Enter Residency'
                                    {...formik.getFieldProps("residency")}
                                    onKeyDown={checkSpace}
                                    type='text'
                                    className={formik.touched.residency && formik.errors.residency ? 'is-invalid' : ""}
                                />
                                {formik.touched.residency && formik.errors.residency ? <small className="validation_error">{formik.errors.residency}</small> : null}
                            </FormGroup>
                            <Row>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label>Year</Label>
                                        <Input
                                            id="residencyFrom"
                                            name="Year"
                                            type="select"
                                            className={formik.touched.residencyFrom && formik.errors.residencyFrom ? 'is-invalid' : ""}
                                            {...formik.getFieldProps("residencyFrom")}
                                        >
                                            <option value="">Select From</option>
                                            {dropDownData?.year?.length ?
                                                dropDownData?.year?.map((item, ind) => (

                                                    <option value={item.value} key={ind}>{item.label}</option>
                                                ))
                                                : ""
                                            }
                                        </Input>
                                        {formik.touched.residencyFrom && formik.errors.residencyFrom ? <small className="validation_error">{formik.errors.residencyFrom}</small> : null}
                                    </FormGroup>
                                </Col>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label><br /></Label>
                                        <Input
                                            id="residencyTo"
                                            name="Year"
                                            type="select"
                                            className={formik.touched.residencyTo && formik.errors.residencyTo ? 'is-invalid' : ""}
                                            {...formik.getFieldProps("residencyTo")}
                                        >

                                            <option value="">Select To</option>
                                            {dropDownData?.year?.length ?
                                                dropDownData?.year?.map((item, ind) => (

                                                    <option value={item.value} key={ind}>{item.label}</option>
                                                ))
                                                : ""
                                            }

                                        </Input>
                                        {formik.touched.residencyTo && formik.errors.residencyTo ? <small className="validation_error">{formik.errors.residencyTo}</small> : null}
                                    </FormGroup>
                                </Col>
                            </Row>
                            <FormGroup>
                                <Label for='followship'>
                                    Followship
                                </Label>
                                <Input
                                    id='followship'
                                    name='followship'
                                    placeholder='Enter Followship'
                                    {...formik.getFieldProps("followship")}
                                    onKeyDown={checkSpace}
                                    type='text'
                                    className={formik.touched.followship && formik.errors.followship ? 'is-invalid' : ""}
                                />
                                {formik.touched.followship && formik.errors.followship ? <small className="validation_error">{formik.errors.followship}</small> : null}
                            </FormGroup>
                            <Row>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label>Year</Label>
                                        <Input
                                            id="exampleSelect"
                                            name="Year"
                                            type="select"
                                            {...formik.getFieldProps("followshipFrom")}
                                            className={formik.touched.followshipFrom && formik.errors.followshipFrom ? 'is-invalid' : ""}
                                        >
                                            <option value="">Select From</option>
                                            {dropDownData?.year?.length ?
                                                dropDownData?.year?.map((item, ind) => (

                                                    <option value={item.value} key={ind}>{item.label}</option>
                                                ))
                                                : ""
                                            }
                                        </Input>
                                        {formik.touched.followshipFrom && formik.errors.followshipFrom ? <small className="validation_error">{formik.errors.followshipFrom}</small> : null}
                                    </FormGroup>
                                </Col>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label><br /></Label>
                                        <Input
                                            id="exampleSelect"
                                            name="Year"
                                            {...formik.getFieldProps("followshipTo")}
                                            className={formik.touched.followshipTo && formik.errors.followshipTo ? 'is-invalid' : ""}
                                            type="select">

                                            <option value="">Select To</option>
                                            {dropDownData?.year?.length ?
                                                dropDownData?.year?.map((item, ind) => (

                                                    <option value={item.value} key={ind}>{item.label}</option>
                                                ))
                                                : ""
                                            }
                                        </Input>
                                        {formik.touched.followshipTo && formik.errors.followshipTo ? <small className="validation_error">{formik.errors.followshipTo}</small> : null}
                                    </FormGroup>
                                </Col>
                            </Row>
                            <FormGroup>
                                <Label for='currentCredentialing'>
                                    Current Credentialing
                                </Label>
                                <Input
                                    id='currentCredentialing'
                                    name='currentCredentialing'
                                    placeholder='Enter Current Credentialing'
                                    {...formik.getFieldProps("currentCredentialing")}
                                    onKeyDown={checkSpace}
                                    type='text'
                                    className={formik.touched.currentCredentialing && formik.errors.currentCredentialing ? 'is-invalid' : ""}
                                />
                                {formik.touched.currentCredentialing && formik.errors.currentCredentialing ? <small className="validation_error">{formik.errors.currentCredentialing}</small> : null}
                            </FormGroup>
                            <FormGroup>
                                <Label for='medicalLicenseNumber'>
                                    Medical License Number
                                </Label>
                                <Input
                                    id='medicalLicenseNumber'
                                    name='medicalLicenseNumber'
                                    placeholder='Enter Number'
                                    maxLength={8}
                                    {...formik.getFieldProps("medicalLicenseNumber")}
                                    onKeyDown={checkSpace}
                                    type='text'
                                    className={formik.touched.medicalLicenseNumber && formik.errors.medicalLicenseNumber ? 'is-invalid' : ""}
                                />
                                {formik.touched.medicalLicenseNumber && formik.errors.medicalLicenseNumber ? <small className="validation_error">{formik.errors.medicalLicenseNumber}</small> : null}
                            </FormGroup>

                            <FormGroup>
                                <Label>Year</Label>
                                <Input
                                    id='years'
                                    type='select'
                                    {...formik.getFieldProps("years")}
                                    className={formik.touched.years && formik.errors.years ? 'is-invalid' : ""}
                                    name='years'
                                >
                                    <option value="">Select</option>
                                    {dropDownData?.year?.length ?
                                        dropDownData?.year?.map((item, ind) => (

                                            <option value={item.value} key={ind}>{item.label}</option>
                                        ))
                                        : ""
                                    }

                                </Input>
                                {formik.touched.years && formik.errors.years ? <small className="validation_error">{formik.errors.years}</small> : null}
                            </FormGroup>
                            <Button className='btn-secondry mb-4' type='submit'>
                                Next
                            </Button>
                        </Form>
                    </div>
                </div>
            </div>
           
        </div>
        <Footer />
        </>
        

    )
}

export default ExpertProfSignup3
