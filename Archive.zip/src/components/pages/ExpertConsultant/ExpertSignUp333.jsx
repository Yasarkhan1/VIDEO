import React, { useState, useEffect, useRef } from 'react'
import { FormGroup, Input, Label, Form, FormText, Button, Progress, Row, Col } from 'reactstrap';
import tick from "../../../assests/images/check-circle-svgrepo-com (2).svg";
import blueTick from "../../../assests/images/blue-tick.svg";
import cpnLogo from "../../../assests/images/CPNHealthFINAL_fontembed.svg";
import { ReactComponent as CrossIcon } from "../../../assests/images/close-circle-svgrepo-com.svg";
import calenderImg from "../../../assests/images/calender-svgrepo-com.svg";
import Footer from '../../common/Footer/Footer';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { useFormik } from "formik";
import * as Yup from "yup";
import { toast } from "react-toastify";



const ExpertSignUp3 = () => {

    const fileInputRef = useRef(null);
    const navigate = useNavigate()
    const location = useLocation()
    console.log("useLocation_+_+_", location.state?.previousStepPayload);
    const previousStepPayload = location?.state?.previousStepPayload
    const [IsLoader, setIsLoader] = useState(false);

    useEffect(() => {
        const step1Data = localStorage.getItem("expertSignupData")
            ? JSON.parse(localStorage.getItem("expertSignupData"))
            : "";
        const { email, password } = step1Data
        if (!email || !password) {
            navigate('/signup-as-expert-1')
        } else {
            getPatchform();
        }
    }, [])

    // fill data in fields after back.
    const getPatchform = () => {
        const step2Data = localStorage.getItem("expertSignupData")
            ? JSON.parse(localStorage.getItem("expertSignupData"))
            : "";
        console.log("step2Data++++", step2Data);
        const { name, dateOfBirth, sex, address, contactNumber, selectedCountryId } = step2Data
        // console.log("Date: ", dateString);
        if (name) {
            formik.setValues({
                // name: name,
                // dateOfBirth: dateString,
                // gender: sex,
                // address: address,
                // mobileNumber: contactNumber,
                // country: selectedCountryId,
            });
        }
    };

    const formik = useFormik({
        initialValues: {
            speciality: "",
            degree: "",
            name_institution_university: "",
            year: "",
            residency: "",
            followship: "",
            current_credentialing: "",
            medical_license_number: "",

        },
        validationSchema: Yup.object({
            speciality: Yup.string()
                .required("Select speciality."),
            degree: Yup.string().required("Select Degree"),

            mobileNumber: Yup.string()
                .required("*Contact number is required."),
            // .matches(
            //     /^[6-9]{1}[0-9]{9}$/,
            //     "Enter valid contact number"
            // ),

        }),

        onSubmit: async (values) => {
            const step2Data = localStorage.getItem("expertSignupData")
                ? JSON.parse(localStorage.getItem("expertSignupData"))
                : "";
            const { email, password } = step2Data

            const payload = {
                ...previousStepPayload
            };

            try {
                // console.log("patient details payload=", payload, JSON.stringify(payload));
                localStorage.setItem("expertSignupData", JSON.stringify(payload));
                navigate("/signup-as-patient-4", { state: { previousStepPayload: payload } })
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        }
    });

    return (

        <>
           <div className='signup-as-expert-3'>
            <div className="container">
                <div className="logo-container">
                    <div className="logo-cpn">
                        <Link to="/">
                            <img src={cpnLogo} alt="Logo" />
                        </Link>
                    </div>
                    <div className="login-button">
                        <Link to="/login-as-expert">
                            <Button>
                                Login
                            </Button>
                        </Link>
                    </div>
                </div>
                <div className="otp-input">

                    <Progress multi>
                        <Progress
                            bar
                            value="33.33"
                            style={{
                                height: '5px'
                            }}
                        />
                        <Progress
                            bar
                            color="success"
                            value="33.33"

                        />
                        <Progress
                            bar
                            color="info"
                            value="33.33"

                        />
                    </Progress>
                </div>
                <div className="text-sign-up">
                    <h1>Sign Up as a Expert Consultants</h1>
                </div>
                <div className="text-sign-up-2">
                <img src={tick} alt="" />
                  <h1>Availability & Payment Method</h1>
                </div>
            </div>
            <div className="container">
                <div className="content-date">
                    <div className="login-detail">
                        <div className="login-detail-img">
                            <img src={tick} alt="" />
                            <h1>Login Details</h1>
                        </div>
                        <div className="login-detail-img2-data">
                            <img src={tick} alt="" />
                            <h1>Personal Details</h1>
                        </div>
                        <div className="login-detail-img2-data">
                            <img src={tick} alt="" />
                            <h1>Professional Details</h1>
                        </div>
                        <div className="login-detail-img2-data" >
                            <img src={tick} alt="" />
                            <h1>Employment Details</h1>
                        </div>
                        <div className="login-detail-img2-data">
                            <img src={tick} alt="" />
                            <h1>Availability & Payment Method</h1>
                        </div>
                        <div className="login-detail-img2-data" style={{ opacity: '0.32' }}>
                            <img src={tick} alt="" />
                            <h1>Upload W-9</h1>
                        </div>
                        <div className="login-detail-img3-data" style={{ opacity: '0.32' }}>
                            <img src={tick} alt="" />
                            <h1>Sign HIPAA/GDPR Agreement & CPN Agreement</h1>

                        </div>
                    </div>
                    <div className="form-data-container">

                        <Form onSubmit={formik.handleSubmit}>
                            <Row>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="exampleEmail">
                                            Time Slot
                                        </Label>
                                        {/* <TimePicker
                                            showSecond={false}
                                            defaultValue={now}
                                            className="xxx"
                                            onChange={onChange}
                                            format={format}
                                            use12Hours
                                            inputReadOnly
                                        /> */}
                                        <hr />
                                    </FormGroup>
                                </Col>

                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="examplePassword">
                                            <br />
                                        </Label>
                                        {/* <TimePicker
                                            showSecond={false}
                                            defaultValue={now}
                                            className="xxx"
                                            onChange={onChange}
                                            format={format}
                                            use12Hours
                                            inputReadOnly
                                        /> */}
                                    </FormGroup>
                                </Col>
                            </Row>
                            <FormGroup>
                                <div className='gender-radiotype' >
                                    <span>Interwall Slot</span>

                                    <FormGroup check>
                                        <Input
                                            name="gander"
                                            type="radio"
                                            value="male"
                                        />
                                        {' '}
                                        <Label check>
                                            10 min
                                        </Label>
                                    </FormGroup>
                                    <FormGroup check>
                                        <Input
                                            name="gander"
                                            type="radio"
                                            value="female"
                                        />
                                        {' '}
                                        <Label check>
                                            25 min
                                        </Label>
                                    </FormGroup>
                                    <FormGroup check>
                                        <Input
                                            name="gander"
                                            type="radio"
                                            value="ntos"

                                        />
                                        {' '}
                                        <Label check>
                                            50 min
                                        </Label>
                                    </FormGroup>
                                    <FormGroup check>
                                        <Input
                                            name="gander"
                                            type="radio"
                                            value="ntos"

                                        />
                                        {' '}
                                        <Label check>
                                            1 hr
                                        </Label>
                                    </FormGroup>
                                </div>
                            </FormGroup>

                            <h6>Select day</h6>


                            <div className="selectorday">

                            </div>
                            <br />
                            <Row>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="exampleEmail">
                                            Holiday Slot
                                        </Label>
                                        <Input
                                            id="exampleEmail"
                                            name="email"
                                            placeholder="AM"
                                            type="date"
                                        />
                                    </FormGroup>
                                </Col>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="examplePassword">
                                            <br />
                                        </Label>
                                        <Input
                                            id="examplePassword"
                                            name="password"
                                            placeholder="Pm"
                                            type="date"
                                        />
                                    </FormGroup>
                                </Col>
                            </Row>
                            <Col md={12}>
                                <FormGroup>
                                    <Label>
                                        Preferred Payment Method
                                    </Label>
                                    <Input type='select'
                                        placeholder='Select one'>
                                        <option value="">Select an option</option>
                                        <option value="option1">Option 1</option>
                                        <option value="option2">Option 2</option>
                                        <option value="option3">Option 3</option>
                                    </Input>
                                </FormGroup>
                            </Col>


                            <Button className='btn-secondry' type='submit'>
                                Next
                            </Button>
                        </Form>

                    </div>
                </div>
            </div>
           
        </div>
        <Footer />
        </>
     
    )
}

export default ExpertSignUp3