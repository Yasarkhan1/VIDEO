import React, { useState, useEffect } from 'react'
import { FormGroup, Input, Label, Form, FormText, Button, Progress } from 'reactstrap';
import tick from "../../../assests/images/check-circle-svgrepo-com (2).svg";
import cpnLogo from "../../../assests/images/CPNHealthFINAL_fontembed.svg";
import eyeClose from "../../../assests/images/eye-closed-svgrepo-com.png";
import Footer from '../../common/Footer/Footer';
import { useNavigate, Link } from 'react-router-dom';
import { ReactComponent as HideIcon } from "../../../assests/images/hide.svg";
import { ReactComponent as ShowIcon } from "../../../assests/images/view.svg";
import { useFormik } from "formik";
import * as Yup from "yup";
import { checkSpace } from "../../../utils";
import { toast } from "react-toastify";


const ExpertLoginSignUp1 = () => {

    const navigate = useNavigate()
    const [IsLoader, setIsLoader] = useState(false);
    const [toggleIcon, setToggleIcon] = useState(false)
    const [acceptTnC, setAcceptTnC] = useState(false)

    const togglePassword = () => {
        setToggleIcon(!toggleIcon)
    }

    const formik = useFormik({
        initialValues: {
            email: "",
            password: "",
            confirmPassword: "",
        },
        validationSchema: Yup.object({
            email: Yup.string().email("Invalid email address").required("*Email is required."),
            password: Yup.string()
                .required("*Password is required")
                .matches(
                    /^(?=.*?[A-Z])(?=(.*[a-z]){1,})(?=(.*[\d]){1,})(?=(.*[\W]){1,})(?!.*\s).{8,}$/,
                    "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character"
                ),
            confirmPassword: Yup.string()
                .required("*Confirm password is required")
                .matches(
                    /^(?=.*?[A-Z])(?=(.*[a-z]){1,})(?=(.*[\d]){1,})(?=(.*[\W]){1,})(?!.*\s).{8,}$/,
                    "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character"
                ).oneOf([Yup.ref('password'), null], 'Password and Confirm password should be same')
        }),

        onSubmit: async (values) => {
            if (!acceptTnC) {
                toast.error("Please Accept Terms & Conditions and Privacy Policy", {
                    position: toast.POSITION.TOP_RIGHT,
                });
                return
            } else {

                const patientSignupData = localStorage.getItem("expertSignupData")
                    ? JSON.parse(localStorage.getItem("expertSignupData"))
                    : "";
                const payload = {
                    ...patientSignupData,
                    email: values.email,
                    password: values.password,
                };

                try {
                    localStorage.setItem("expertSignupData", JSON.stringify(payload));
                    console.log("patient details payload=", payload);
                    navigate("/signup-as-expert-2")
                } catch (error) {
                    toast.error(error, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                }
            }
        }
    });


    useEffect(() => {
        getPatchform();
    }, []);

    const getPatchform = () => {
        const step1Data = localStorage.getItem("expertSignupData")
            ? JSON.parse(localStorage.getItem("expertSignupData"))
            : "";
        console.log("step1Data", step1Data);

        if (step1Data) {
            formik.setValues({

                email: step1Data.email,
                password: step1Data.password,
                confirmPassword: step1Data.password,
            });
        }
    };

    return (
        <div className='expert-signup-details'>
            <div className="container">
                <div className="logo-container">
                    <div className="logo-cpn">
                        <img src={cpnLogo} alt="Logo" />
                    </div>
                    <div className="login-button">
                        <Button>
                            Login
                        </Button>
                    </div>
                </div>
                <div className="otp-input">
                    <Progress multi>
                        <Progress
                            bar
                            value="33.33"
                            style={{
                                height: '3px'
                            }}
                        />
                        <Progress
                            bar
                            color="success"
                            value="33.33"
                            style={{ height: '3px' }}

                        />
                        <Progress
                            bar
                            color="info"
                            value="33.33"
                            style={{ height: '3px' }}
                        />


                    </Progress>
                </div>
                <div className="text-sign-up">
                    <h1>Sign Up as a Expert Consultants</h1>
                </div>
            </div>
            <div className="container">
                <div className="content-date">
                    <div className="login-detail">
                        <div className="login-detail-img">
                            <img src={tick} alt="" />
                            <h1>Login Details</h1>
                        </div>
                        <div className="login-detail-img2-data" style={{ opacity: '0.32' }}>
                            <img src={tick} alt="" />
                            <h1>Personal Details</h1>
                        </div>
                        <div className="login-detail-img2-data" style={{ opacity: '0.32' }}>
                            <img src={tick} alt="" />
                            <h1>Professional Details</h1>
                        </div>
                        <div className="login-detail-img2-data" style={{ opacity: '0.32' }}>
                            <img src={tick} alt="" />
                            <h1>Employment Details</h1>
                        </div>
                        <div className="login-detail-img2-data" style={{ opacity: '0.32' }}>
                            <img src={tick} alt="" />
                            <h1>Availability & Payment Method</h1>
                        </div>
                        <div className="login-detail-img2-data" style={{ opacity: '0.32' }}>
                            <img src={tick} alt="" />
                            <h1>Upload W-9</h1>
                        </div>
                        <div className="login-detail-img3-data">
                            <img src={tick} alt="" />
                            <h1>Sign HIPAA/GDPR Agreement & CPN Agreement</h1>
                           
                        </div>
                    </div>

                    <div className="form-data-container">

                        <Form onSubmit={formik.handleSubmit}>
                            <FormGroup>
                                <Label for="exampleEmail">
                                    Email Address
                                </Label>
                                <Input
                                    id="exampleEmail"
                                    name="email"
                                    placeholder="Enter Email Address"
                                    type="email"
                                    {...formik.getFieldProps("email")}
                                    onKeyDown={checkSpace}
                                    className={formik.touched.email && formik.errors.email ? "is-invalid" : ""}
                                // invalid={formik.touched.email && formik.errors.email ? true : false}
                                />
                                {formik.touched.email && formik.errors.email ? <small className="validation_error">{formik.errors.email}</small> : null}
                            </FormGroup>
                            <FormGroup>
                                <div className="pasword">
                                    {/* <img src={eyeClose} alt="" className='eyeclosed' /> */}
                                    <Label for="examplePassword">
                                        Password
                                    </Label>
                                    <Input

                                        name="password"
                                        placeholder="Enter Password"
                                        onKeyDown={checkSpace}
                                        {...formik.getFieldProps("password")}
                                        type={!toggleIcon ? "password" : "text"}
                                        className={formik.touched.password && formik.errors.password ? "is-invalid" : ""}
                                    // invalid={formik.touched.password && formik.errors.password ? true : false}
                                    />
                                    <span className='pwdToggle'>
                                        {toggleIcon ? (
                                            <span onClick={togglePassword}>
                                                <ShowIcon />
                                            </span>
                                        ) : (
                                            <span onClick={togglePassword}>
                                                <HideIcon />
                                            </span>
                                        )}
                                    </span>
                                    {formik.touched.password && formik.errors.password ? (
                                        <span className="validation_error">{formik.errors.password}</span>
                                    ) : null}
                                </div>
                            </FormGroup>

                            <FormGroup>
                                <div className="confrimpasword">
                                    {/* <img src={eyeClose} alt="" className='eyeclosed' /> */}
                                    <Label for='examplePassword'> Confirm Password</Label>

                                    <Input
                                        name="confirmPassword"
                                        placeholder="Enter Password"
                                        type={!toggleIcon ? "password" : "text"}
                                        onKeyDown={checkSpace}
                                        {...formik.getFieldProps("confirmPassword")}
                                        invalid={formik.touched.confirmPassword && formik.errors.confirmPassword ? true : false}
                                    />
                                    <span className='pwdToggle'>
                                        {toggleIcon ? (
                                            <span onClick={togglePassword}>
                                                <ShowIcon />
                                            </span>
                                        ) : (
                                            <span onClick={togglePassword}>
                                                <HideIcon />
                                            </span>
                                        )}
                                    </span>
                                    {formik.touched.confirmPassword && formik.errors.confirmPassword ? (
                                        <small className="validation_error">{formik.errors.confirmPassword}</small>
                                    ) : null}
                                </div>

                            </FormGroup>

                            <FormGroup check className='tnc-policy'>
                                <Input type="checkbox" onChange={(e) => setAcceptTnC(e.target.checked)} checked={acceptTnC} />
                                {' '}
                                <Label check>
                                    Accept <Link to='/'>Terms & Conditions</Link> and <Link to='/'>Privacy Policy</Link>
                                </Label>
                            </FormGroup>
                            <Button className='btn-secondry' type='submit'>
                                Next
                            </Button>
                        </Form>
                    </div>
                </div>
            </div>
            <Footer />
        </div>

    )
}

export default ExpertLoginSignUp1