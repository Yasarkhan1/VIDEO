import React from 'react'
import { Input, Table } from 'reactstrap'
import { Link, useNavigate } from 'react-router-dom'
import {Form, FormGroup, Button, Label } from 'reactstrap'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
// import Logoimage from '../../../assests/images/ys.png
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import { useFormik } from 'formik'
import * as Yup from "yup";
import { checkSpace } from "../../../utils";
import ExpertSidebar from '../../common/ExpertSidebar/ExpertSidebar'


function ExpertChangePass() {
    const navigate = useNavigate();

    const validationSchema = Yup.object().shape({
        old_password:Yup.string().required("Please old password"),
        new_password:Yup.string().required("Password is required")
            .matches(
                /^(?=.*?[A-Z])(?=(.*[a-z]){1,})(?=(.*[\d]){1,})(?=(.*[\W]){1,})(?!.*\s).{8,}$/,
                "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character"
            ),
        confirm_Password: Yup.string()
            .required("Confirm password is required")
            .matches(
                /^(?=.*?[A-Z])(?=(.*[a-z]){1,})(?=(.*[\d]){1,})(?=(.*[\W]){1,})(?!.*\s).{8,}$/,
                "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character"
            ).oneOf([Yup.ref('password'), null], 'Password and Confirm password should be same')

    });

    const formik = useFormik({
        initialValues: {
            old_password:"",
            new_password: "",
            confirm_Password: "",
        },    
        validationSchema: validationSchema,
        onSubmit: async (values) => {
            navigate("/expert-my-profile")
        }
    });
    const handleSubmit = (values) => {
        // Handle form submission
        console.log(values);
    }
    console.log("formik", formik.errors)


return (
    <>
        <div className='expert-change-password'>
            <LoginNavbar />
            <div className="container mb-5">
                <div className="parent-div">
                    <ExpertSidebar/>
                    <div className="child-div">
                        <h6>Change Password</h6>
                        <Form onSubmit={formik.handleSubmit}>

                            <FormGroup>
                                <Label for="examplePassword">
                                    Old Password
                                </Label>
                                <Input
                                autoComplete='off'
                                    name="old_password"
                                    placeholder="Enter Old Password"
                                    type="password"
                                  {...formik.getFieldProps("old_password")}
                                  className={formik.touched.old_password && formik.errors.old_password?'is-invalid':""}

                                />
                                {formik.touched.old_password && formik.errors.old_password? <small className='validation_error'>{formik.errors.old_password}</small>: null}
                            </FormGroup>
                            <FormGroup>
                                <Label for="examplePassword">
                                    New Password
                                </Label>
                                <Input
                                autoComplete='off'
                                    name="new_password"
                                    placeholder="Enter New Password"
                                    type="password"
                                    onKeyDown={checkSpace}
                                    {...formik.getFieldProps("new_password")}
                                   className={formik.touched.new_password && formik.errors.new_password? 'is-invalid':""}
                                />
                                {formik.touched.new_password && formik.errors.new_password? <small className="validation_error">{formik.errors.new_password}</small>: null}
                            </FormGroup>
                            <FormGroup>
                                <Label for="examplePassword">
                                    Confirm Password
                                </Label>
                                <Input
                                autoComplete='off'
                                    name="confirm_password"
                                    placeholder="Enter Confirm Password"
                                    type="password"
                                    {...formik.getFieldProps("confirm_password")}
                                    className={formik.touched.confirm_Password && formik.errors.confirm_Password? 'is-invalid':''}

                                />
                                {formik.touched.confirm_Password && formik.errors.confirm_Password? <small className='validation_error'>{formik.errors.confirm_Password}</small>: null}
                                <Button className='btn-secondry' type='submit'>Update</Button>
                            </FormGroup>
                        </Form>
                    </div>
                </div>
            </div>
        </div>

        <Footer />


    </>
)
}

export default ExpertChangePass
