import React, { useState, useEffect } from 'react'
import { FormGroup, Input, Progress, Label, Button, Form, Row, Col } from 'reactstrap';
import tick from "../../../assests/images/check-circle-svgrepo-com (2).svg";
import blueTick from "../../../assests/images/blue-tick.svg";
import cpnLogo from "../../../assests/images/CPNHealthFINAL_fontembed.svg";
import Footer from '../../common/Footer/Footer';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { useFormik } from "formik";
import * as Yup from "yup";
import { checkSpace } from "../../../utils";
import authenticationServices from "../../../services";
import { toast } from "react-toastify";
import { useDropzone } from 'react-dropzone'
import Badal from '../../../assests/images/upload-cloud-svgrepo-com.svg';
import { ReactComponent as Delete } from '../../../assests/images/delete-2-svgrepo-com (2).svg';


const ExpertSignUp4 = (props) => {
    const navigate = useNavigate()
    const location = useLocation()
    // console.log("useLocation_+_+_", location.state?.profileImage);
    const profileImage = location?.state?.profileImage
    const [IsLoader, setIsLoader] = useState(false);
    const [acceptedFiles, setAcceptedFiles] = useState([]);
    const [rejectedFiles, setRejectedFiles] = useState([]);

    const onDrop = (accepted, rejected) => {
        // const fileWin = [...accepted, ...acceptedFiles]

        setAcceptedFiles(accepted);
        setRejectedFiles(rejected);
    };
    const { getRootProps, getInputProps } = useDropzone({
        // accept: ['image/jpeg', 'image/png', 'image/gif', 'application/pdf', 'image/jpg'],
        accept: {
            'image/*': ['.jpeg', '.jpg', '.png', '.gif'],
        },
        maxSize: 1 * 1024 * 1024,
        multiple: false,
        onDrop,
    });


    useEffect(() => {
        const expertSignupData = localStorage.getItem("expertSignupData")
            ? JSON.parse(localStorage.getItem("expertSignupData"))
            : "";

        const { email, password } = expertSignupData
        if (!email || !password) {
            // navigate('/signup-as-expert-3')
        }
    }, [])

    // const formik = useFormik({
    //     initialValues: {
    //         fullName: "",
    //     },
    //     validationSchema: Yup.object({

    //     }),

    //     onSubmit: async (values) => {
    //         const expertSignupData = localStorage.getItem("expertSignupData")
    //             ? JSON.parse(localStorage.getItem("expertSignupData"))
    //             : "";
    //         if (acceptedFiles.length) {
    //             navigate('/signup-as-expert-7')

    //         } else {
    //             toast.error("Please upload File", {
    //                 position: toast.POSITION.TOP_RIGHT,
    //             });
    //         }

    //     }
    // });

    // console.log("acceptedFiles==", acceptedFiles[0]);

    const clearUpload = (index) => {
        const updatedFile = [...acceptedFiles];
        updatedFile.splice(index, 1);
        setAcceptedFiles(updatedFile)
    }
    console.log("acceptedFiles[0]", acceptedFiles[0]);

    const handleSubmit = () => {
        const previousStepPayload = localStorage.getItem("expertSignupData")
            ? JSON.parse(localStorage.getItem("expertSignupData"))
            : "";
        const payload = {
            ...previousStepPayload,
            WNine: acceptedFiles[0]
        }
        try {
            // console.log("patient details payload=", payload, JSON.stringify(payload));
            localStorage.setItem("expertSignupData", JSON.stringify(payload));
            navigate("/signup-as-expert-7", { state: { previousStepPayload: payload, profileImage: profileImage, WNine: acceptedFiles[0] } })
        } catch (error) {
            toast.error(error, {
                position: toast.POSITION.TOP_RIGHT,
            });
        }
    }


    return (
        <>
        
        <div className='Expert-Sign-Up4'>
            <div className="container">
                <div className="logo-container">
                    <div className="logo-cpn">
                        <Link to="/">
                            <img src={cpnLogo} alt="Logo" />
                        </Link>
                    </div>
                    <div className="login-button">
                        <Link to="/login-as-expert">
                            <Button>
                                Login
                            </Button>
                        </Link>
                    </div>
                </div>
                <div className="otp-input">

                    <Progress multi>
                        <Progress
                            bar
                            value="33.33"
                            style={{
                                height: '5px'
                            }}
                        />
                        <Progress
                            bar
                            color="success"
                            value="33.33"

                        />
                        <Progress
                            bar
                            color="info"
                            value="33.33"

                        />
                    </Progress>
                </div>
                <div className="text-sign-up">
                    <h1>Sign Up as a Expert Consultants</h1>
                </div>
                  <div className="text-sign-up-2">
                  <img src={tick} alt="" />
                  <h1>Upload W-9</h1>
                  </div>
            </div>
            <div className="container mb-5">
                <div className="content-date">
                    <div className="login-detail">
                        <div className="login-detail-img">
                            <img src={tick} alt="" />
                            <h1>Login Details</h1>
                        </div>
                        <div className="login-detail-img2-data">
                            <img src={tick} alt="" />
                            <h1>Personal Details</h1>
                        </div>
                        <div className="login-detail-img2-data">
                            <img src={tick} alt="" />
                            <h1>Professional Details</h1>
                        </div>
                        <div className="login-detail-img2-data" >
                            <img src={tick} alt="" />
                            <h1>Employment Details</h1>
                        </div>
                        <div className="login-detail-img2-data">
                            <img src={tick} alt="" />
                            <h1>Availability & Payment Method</h1>
                        </div>
                        <div className="login-detail-img2-data">
                            <img src={tick} alt="" />
                            <h1>Upload W-9</h1>
                        </div>
                        <div className="login-detail-img3-data" style={{ opacity: '0.32' }}>
                            <img src={tick} alt="" />
                            <h1>Sign HIPAA/GDPR Agreement & CPN Agreement</h1>

                        </div>
                    </div>
                    <div className="form-data-container">

                        <Form >
                            <FormGroup>
                                <Label for="">
                                    Upload W-9
                                </Label>
                                <div {...getRootProps({ className: 'dropzone' })}>
                                    <input {...getInputProps()} />
                                    <img src={Badal} />
                                    <h6>Browse FIle</h6>
                                    <p>(PDF, PNG, JPG and Gif files are allowed)</p>
                                    <p>Maximum file size is 20MB</p>
                                </div>
                                {/* <aside>
                                    <ul>{files}</ul>
                                </aside> */}
                            </FormGroup>

                            <FormGroup>

                                {acceptedFiles?.length > 0 ? acceptedFiles?.map((item, ind) => (

                                    <div className="file-name mb-2" key={ind}>
                                        {item.name}
                                        <Delete className="delete-upload" onClick={() => clearUpload(ind)} />
                                    </div>

                                )) : ""}
                                {rejectedFiles?.length > 0 && (
                                    <small className="validation_error">
                                        File size exceeds the limit of 20MB.
                                    </small>

                                )}


                            </FormGroup>

                            <Button className='btn-secondry' onClick={handleSubmit} >
                                Next
                            </Button>
                        </Form>


                    </div>
                </div>
            </div>
            
        </div>
        <Footer />
        </>
       
    )
}

export default ExpertSignUp4