import React, { useState, useEffect } from 'react'
import { Table } from 'reactstrap'
import { Link, useNavigate } from 'react-router-dom'
import { Progress, Form, FormGroup, Button, Row, Label, Input, Col } from 'reactstrap'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import Logoimage from '../../../assests/images/ys.png'
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import { useFormik } from 'formik'
import { checkSpace } from "../../../utils";
import * as Yup from "yup";
import { useSelector, useDispatch } from 'react-redux';
import authenticationServices from "../../../services";
import { toast } from "react-toastify";
import { setUser } from '../../../stateManagement/userSlice';
import dayjs from "dayjs";
import Sidebar from '../../common/Sidebar/Sidebar'
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import ExpertSidebar from '../../common/ExpertSidebar/ExpertSidebar';


function ExpertProfileEdit() {

    const navigate = useNavigate();
    const [dob, setDob] = useState("")
    const [IsLoader, setIsLoader] = useState(false);
    const userData = useSelector((state) => state.user.data);

    useEffect(() => {
        getPatchform()
    }, [userData])

    const getPatchform = () => {
        console.log("userData", userData);
        formik.setFieldValue("name", userData?.name,)
        formik.setFieldValue("dateOfBirth", dayjs(userData?.dateofbirth).format('DD/MM/YYYY'),)
        formik.setFieldValue("gender", userData?.gender,)
        formik.setFieldValue("height", userData?.height,)
        formik.setFieldValue("weight", userData?.weight,)
        formik.setFieldValue("institution", userData?.institution,)
        formik.setFieldValue("address", userData?.address,)
        formik.setFieldValue("mobileNumber", userData?.mobileNumber,)
        formik.setFieldValue("country", userData?.country,)
        formik.setFieldValue("email", userData?.email,)
        formik.setValues({
            name: userData?.name,
            dateOfBirth: dayjs(userData?.dateofbirth).format('DD/MM/YYYY'),
            gender: userData?.gender,
            // height: userData?.height,
            // weight: userData?.weight,
            institution: userData?.institution,
            address: userData?.address,
            mobileNumber: userData?.mobilenumber,
            country: userData?.country,
            email: userData?.email,
        });
        // console.log("dateOfBirth==", new Date(dateOfBirth).toString());
        // setDob(dateOfBirth)
        // setGender(gender)

    };



    const validationSchema = Yup.object().shape({
        name: Yup.string().required('Name is required'),
        email: Yup.string().email('Invalid email').required('Email is required'),
        dateOfBirth: Yup.string().required("*Date Of birth is required."),
        gender: Yup.string().required('Please select your gender'),
        // height: Yup.string().required("*Height is required."),
        // weight: Yup.string().required("Weight is  required."),
        institution:Yup.string().required('Enter University Name'),
        mobileNumber: Yup.string().required("*Contact number is required."),

        // .matches(
        //     /^[6-9]{1}[0-9]{9}$/,
        //     "Enter valid contact number"
        // ),
        country: Yup.string().required("*Country is required."),
        address: Yup.string()
            .required("*Address is required.")
            .min(5, "minimum five character are required."),
        // Add more fields and validation rules as needed
    });
    const [selectedDate, setSelectedDate] = useState(null);

    const handleDateChange = (date) => {
        setSelectedDate(date);
    };
    const formik = useFormik({
        initialValues: {
            name: '',
            email: '',
            dateOfBirth: "",
            gender: "",
            institution:'',
            // height: "",
            // weight: "",
            address: "",
            mobileNumber: "",
            country: "",
            
            // Add more fields as needed
        },
        validationSchema: validationSchema,
        onSubmit: (values) => {
            // Handle form submission
            console.log(values);
            navigate("/expert-setting")
        },
    });

    console.log(formik.errors)
    return (
        <>
            <div className='expert-profile-edit'>
                <LoginNavbar />
                <div className="container mb-5">
                    <div className="parent-div">
                        <ExpertSidebar/>

                        <div className="child-div">
                            <div className="middle-content">

                                <Form onSubmit={formik.handleSubmit}>
                                    <h1>Edit Profile</h1>
                                    <Row>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleText">
                                                    Full Name
                                                </Label>
                                                <Input
                                                    id="name"
                                                    name="name"
                                                    // placeholder="Abdullah Zaheer"
                                                    type="text"
                                                    {...formik.getFieldProps("name")}
                                                    className={formik.touched.name && formik.errors.name ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.name && formik.errors.name ? <small className="validation_error">{formik.errors.name}</small> : null}

                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                {/* <Label for="exampleDate">
                                                    Date of Birth
                                                </Label>
                                                <Input
                                                    id="exampleDate"
                                                    name="date"
                                                    placeholder="12/03/2023"
                                                    type="date"
                                                /> */}
                                                <Label>Date of Birth</Label>
                                                <DatePicker
                                                    selected={dob}
                                                    placeholderText="Enter Dob"
                                                    dateFormat="dd/MM/yyyy"
                                                    showIcon={true}
                                                    // required
                                                    name="startDate"
                                                    minDate={new Date()}
                                                    showYearDropdown={true}
                                                    isClearable={dob}
                                                    // onChange={handleDateChange}
                                                    {...formik.getFieldProps("dateOfBirth")}

                                                    onChange={(date) => { setDob(date); formik.setFieldValue("dateOfBirth", date) }} //only when value has changed


                                                    // Customize date format as needed
                                                    className={formik.touched.dateOfBirth && formik.errors.dateOfBirth ? 'is-invalid form-control' : "form-control"}
                                                />
                                                {formik.touched.dateOfBirth && formik.errors.dateOfBirth ? <small className="validation_error">{formik.errors.dateOfBirth}</small> : null}


                                            </FormGroup>
                                        </Col>
                                    </Row>

                                    <Row>
                                        <Col md={6} >
                                            <FormGroup>
                                                <Label for="exampleSelect">
                                                    Gender
                                                </Label>
                                                <Input
                                                    id='exampleSelect'
                                                    name="gender"
                                                    type="select"
                                                    {...formik.getFieldProps("gender")}
                                                    className={formik.touched.gender && formik.errors.gender ? 'is-invalid' : ""}
                                                >
                                                    <option>Select Gender</option>
                                                    <option value="male">Male</option>
                                                    <option value="female">Female</option>

                                                </Input>
                                                {formik.touched.gender && formik.errors.gender ? <small className="validation_error">{formik.errors.gender}</small> : null}

                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleEmail">
                                                    Email Address
                                                </Label>
                                                <Input
                                                    id="exampleEmail"
                                                    name="email"
                                                    placeholder="abdullahzaheer@yahoo.com"
                                                    type="email"
                                                    {...formik.getFieldProps("email")}
                                                    onKeyDown={checkSpace}
                                                    className={formik.touched.email && formik.errors.email ? "is-invalid" : ""}
                                                />
                                                {formik.touched.email && formik.errors.email ? <small className="validation_error">{formik.errors.email}</small> : null}
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <Row>
                                        {/* <Col md={3}>
                                            <FormGroup>
                                                <Label for="exampleText">
                                                    Height
                                                </Label>
                                                <Input
                                                    id="exampleNumber"
                                                    name="number"
                                                    placeholder="Enter Height"
                                                    type="number"
                                                    min="0"
                                                    {...formik.getFieldProps("height")}
                                                    onKeyDown={checkSpace}
                                                    onInput={(e) => (e.target.value = e.target.value.slice(0, 3))}
                                                    onWheel={(e) => e.target.blur()}
                                                    className={formik.touched.height && formik.errors.height ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.height && formik.errors.height ? <small className="validation_error">{formik.errors.height}</small> : null}

                                            </FormGroup>
                                        </Col> */}
                                        {/* <Col md={3}>
                                            <FormGroup>
                                                <Label for="exampleText">
                                                    Weight
                                                </Label>

                                                <Input
                                                    id="exampleNumber"
                                                    name="weight"
                                                    placeholder="Enter Height"
                                                    type="number"
                                                    min="0"
                                                    {...formik.getFieldProps("weight")}
                                                    onKeyDown={checkSpace}
                                                    onInput={(e) => (e.target.value = e.target.value.slice(0, 3))}
                                                    onWheel={(e) => e.target.blur()}
                                                    className={formik.touched.weight && formik.errors.weight ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.weight && formik.errors.weight ? <small className="validation_error">{formik.errors.weight}</small> : null}

                                            </FormGroup>
                                        </Col> */}
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label>Institution/ University</Label>
                                                <Input
                                                name='institution'
                                                type='text'
                                                placeholder='XYZ University'
                                                {...formik.getFieldProps("institution")}
                                                className={formik.touched.institution && formik.errors.institution ? "is-invalid" : ""}
                                                />
                                                {formik.touched.institution && formik.errors.institution ? <small className="validation_error">{formik.errors.institution}</small> : null}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleNumber">
                                                    Contact Number
                                                </Label>
                                                {/* <Input
                                                    id=''
                                                    name='mobileNumber'
                                                    placeholder='Enter Contact Number'
                                                    type='number'
                                                    {...formik.getFieldProps("mobileNumber")}
                                                    onKeyDown={checkSpace}
                                                    min="0"
                                                    onInput={(e) => (e.target.value = e.target.value.slice(0, 10))}
                                                    onWheel={(e) => e.target.blur()}
                                                    className={formik.touched.mobileNumber && formik.errors.mobileNumber ? 'is-invalid' : ""}
                                                /> */}
                                                <PhoneInput
                                                    country="us"
                                                    preferredCountries={["us"]}
                                                    placeholder="Type your contact number here"
                                                    value={formik.values.mobileNumber}
                                                    // onChange={(value) => handleMobile(value)}
                                                    onBlur={formik.handleBlur}
                                                    onChange={(value) => formik.setFieldValue("mobileNumber", value)}
                                                    enableSearch={true}
                                                    // {...formik.getFieldProps("mobileNumber")}
                                                    inputStyle={{ width: "100%" }}
                                                    inputClass={formik.touched.mobileNumber && formik.errors.mobileNumber ? " is-invalid" : ""}
                                                    inputProps={{ name: "mobileNumber" }}
                                                />
                                                {formik.touched.mobileNumber && formik.errors.mobileNumber ? <small className="validation_error">{formik.errors.mobileNumber}</small> : null}
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                   
                                    <Row>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleAddress">
                                                    Address
                                                </Label>

                                                <Input

                                                    id='exampleAddress'
                                                    name='Address'
                                                    placeholder='Enter Your Address'
                                                    {...formik.getFieldProps("address")}
                                                    onKeyDown={checkSpace}
                                                    type='text'
                                                    className={formik.touched.address && formik.errors.address ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.address && formik.errors.address ? <small className="validation_error">{formik.errors.address}</small> : null}

                                            </FormGroup>
                                        </Col>
                                        <Col md={6} >
                                            <FormGroup>
                                                <Label for="exampleSelect">
                                                    Country
                                                </Label>
                                                <Input
                                                    id="exampleSelect"
                                                    name="country"
                                                    type="select"
                                                    {...formik.getFieldProps("country")}
                                                    className={formik.touched.country && formik.errors.country ? 'is-invalid' : ""}
                                                >
                                                    <option>Select Country</option>
                                                    <option value="india">INDIA</option>
                                                    <option>USA</option>
                                                    <option>UAE</option>
                                                    <option>US</option>

                                                </Input>
                                                {formik.touched.country && formik.errors.country ? <small className="validation_error">{formik.errors.country}</small> : null}
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <Col md={6}>
                                        <Button className='btn-secondry' type="submit">Update</Button>
                                    </Col>
                                </Form>
                            </div>


                        </div>
                    </div>
                </div>
            </div>

            <Footer />


        </>
    )
}

export default ExpertProfileEdit
