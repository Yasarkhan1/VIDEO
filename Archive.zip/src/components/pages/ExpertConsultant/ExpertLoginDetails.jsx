import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Form, FormGroup, Button, Input, Col, Label } from 'reactstrap'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar';
import { useSelector } from 'react-redux';
import ExpertSidebar from '../../common/ExpertSidebar/ExpertSidebar'
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { checkSpace } from "../../../utils";
import eyeClose from '../../../assests/images/eye-closed-svgrepo-com.png';
import { ReactComponent as HideIcon } from '../../../assests/images/hide.svg';
import { ReactComponent as ShowIcon } from '../../../assests/images/view.svg';



import { toast } from 'react-toastify';
function ExpertLoginDetails() {
    const [IsLoader, setIsLoader] = useState(false);
    const [editMode, setEditMode] = useState(false); // State to control edit mode
    const [newPasswordVisible, setNewPasswordVisible] = useState(false); // State to control visibility of New Password field
    const [confirmPasswordVisible, setConfirmPasswordVisible] = useState(false); // State to control visibility of Confirm Password field
    const [newPassword, setNewPassword] = useState(''); // State to store new password
    const [confirmPassword, setConfirmPassword] = useState('');
    const navigate = useNavigate();
    const [toggleIcon1, setToggleIcon1] = useState(false);
    const [toggleIcon2, setToggleIcon2] = useState(false);
    const [toggleIcon3, setToggleIcon3] = useState(false);
    const expertData = useSelector((state) => state?.user.expertUser)


    const togglePassword1 = () => {
        setToggleIcon1(!toggleIcon1);
    };
    const togglePassword2 = () => {
        setToggleIcon2(!toggleIcon2);
    };
    const togglePassword3 = () => {
        setToggleIcon3(!toggleIcon3);
    };


    const validationSchema = Yup.object().shape({
        new_password: Yup.string().required("Password is required")
            .matches(
                /^(?=.*?[A-Z])(?=(.*[a-z]){1,})(?=(.*[\d]){1,})(?=(.*[\W]){1,})(?!.*\s).{8,}$/,
                "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and Special Character"
            ),
        confirm_Password: Yup.string()
            .required("Confirm password is required")
            .matches(
                /^(?=.*?[A-Z])(?=(.*[a-z]){1,})(?=(.*[\d]){1,})(?=(.*[\W]){1,})(?!.*\s).{8,}$/,
                "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character"
            ).oneOf([Yup.ref('new_password'), null], 'Password and Confirm password should be same')

    });

    const formik = useFormik({
        initialValues: {
            new_password: "",
            confirm_Password: "",
        },
        validationSchema: validationSchema,
        onSubmit: async (values) => {
            navigate("/")
        }
    });


    const handleEditClick = () => {
        setEditMode(true);
        setNewPasswordVisible(true);
        setConfirmPasswordVisible(true);
    };
    console.log("expertData===", expertData);

    return (

        <>
            <div className="expert-Login-Details">
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className="parent-div ">
                        <ExpertSidebar />

                        <div className="child-div">
                            <div className="box-form" style={{ marginTop: "6%" }}>
                                <Form onSubmit={formik.handleSubmit}>
                                    <Col md={12}>
                                        <FormGroup>
                                            <Label>Email Address</Label>
                                            <Input
                                                type="email"
                                                name="Email"
                                                value={expertData?.employmentDetails?.email}
                                                placeholder="Enter your Email"
                                                disabled={!editMode} // Disable email input if not in edit mode

                                            />

                                        </FormGroup>
                                    </Col>
                                    <Col md={12}>
                                        <FormGroup className="pasword">
                                            <Label>Password</Label>
                                            <div className='input-container'>
                                                <Input
                                                    type={!toggleIcon1 ? 'password' : 'text'}
                                                    name="password"
                                                    value={expertData?.pass}
                                                    placeholder="XXXXXXXXXXXXX"
                                                    disabled={!editMode} // Disable password input if not in edit mode
                                                />

                                                <span className={formik.touched.password && formik.errors.password ? 'pwdToggleError' : 'pwdToggle'}>
                                                    {toggleIcon1 ? (
                                                        <span onClick={togglePassword1}>
                                                            <ShowIcon />
                                                        </span>
                                                    ) : (
                                                        <span onClick={togglePassword1}>
                                                            <HideIcon />
                                                        </span>
                                                    )}
                                                </span>
                                            </div>
                                        </FormGroup>
                                    </Col>

                                    {newPasswordVisible && (
                                        <Col md={12}>
                                            <FormGroup className="pasword">
                                                <Label>New Password</Label>

                                                <Input
                                                    placeholder='Enter new password'
                                                    type={!toggleIcon2 ? 'password' : 'text'}
                                                    name="new_password"
                                                    disabled={!editMode}
                                                    onKeyDown={checkSpace}
                                                    value={newPassword}
                                                    onChange={(e) => setNewPassword(e.target.value)}
                                                    {...formik.getFieldProps('new_password')}
                                                    invalid={formik.touched.new_password && formik.errors.new_password ? true : false}
                                                />
                                                <span className={formik.touched.new_password && formik.errors.new_password ? 'pwdToggleError' : 'pwdToggle'}>
                                                    {toggleIcon2 ? (
                                                        <span onClick={togglePassword2}>
                                                            <ShowIcon />
                                                        </span>
                                                    ) : (
                                                        <span onClick={togglePassword2}>
                                                            <HideIcon />
                                                        </span>
                                                    )}
                                                </span>

                                                {formik.touched.new_password && formik.errors.new_password ? <small className="validation_error" >{formik.errors.new_password}</small> : null}

                                            </FormGroup>
                                        </Col>
                                    )}

                                    {confirmPasswordVisible && (
                                        <Col md={12}>
                                            <FormGroup className="pasword">
                                                <Label>Confirm Password</Label>
                                                {/* <Input
                                                    type="password"
                                                    name="confirm_Password"
                                                    placeholder="Enter confirm password"
                                                    disabled={!editMode}
                                                    value={confirmPassword}
                                                    onChange={(e) => setConfirmPassword(e.target.value)}
                                                    {...formik.getFieldProps("confirm_password")}
                                                    className={formik.touched.confirm_Password && formik.errors.confirm_Password ? 'is-invalid' : ''}
                                                /> */}

                                                <Input
                                                    placeholder='Enter Password'
                                                    name="confirm_Password"
                                                    type={!toggleIcon3 ? 'password' : 'text'}
                                                    disabled={!editMode}
                                                    value={confirmPassword}
                                                    onChange={(e) => setConfirmPassword(e.target.value)}
                                                    onKeyDown={checkSpace}
                                                    {...formik.getFieldProps('confirm_Password')}
                                                    invalid={formik.touched.confirm_Password && formik.errors.confirm_Password ? true : false}
                                                />
                                                <span className={formik.touched.confirm_Password && formik.errors.confirm_Password ? 'pwdToggleError' : 'pwdToggle'}>
                                                    {toggleIcon3 ? (
                                                        <span onClick={togglePassword3}>
                                                            <ShowIcon />
                                                        </span>
                                                    ) : (
                                                        <span onClick={togglePassword3}>
                                                            <HideIcon />
                                                        </span>
                                                    )}
                                                </span>

                                                {formik.touched.confirm_Password && formik.errors.confirm_Password ? <small className='validation_error'>{formik.errors.confirm_Password}</small> : null}

                                            </FormGroup>
                                        </Col>
                                    )}

                                    <div style={{ display: 'flex', justifyContent: 'center' }}>
                                        {editMode ? (
                                            <Button className="next-button" type='submit'>
                                                Update
                                            </Button>
                                        ) : (
                                            <Button className="next-button" onClick={handleEditClick}>
                                                Edit
                                            </Button>
                                        )}
                                    </div>
                                </Form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Footer />
        </>
    )
}

export default ExpertLoginDetails
