import React, { useState, useEffect, useRef } from 'react'
import { FormGroup, Input, Label, Form, FormText, Button, Progress, Row, Col } from 'reactstrap';
import tick from "../../../assests/images/check-circle-svgrepo-com (2).svg";
import cpnLogo from "../../../assests/images/CPNHealthFINAL_fontembed.svg";
import Footer from '../../common/Footer/Footer';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import "react-phone-input-2/lib/style.css";
import TimePicker from "rc-time-picker";
import "rc-time-picker/assets/index.css"
import moment from "moment";
import { ReactComponent as CrossIcon } from "../../../assests/images/close-circle-svgrepo-com.svg";
import { toast } from "react-toastify";

const ExpertAvailabilitySignUp5 = () => {
    const location = useLocation()
    // console.log("useLocation_+_+_", location.state?.previousStepPayload);
    const profileImage = location?.state?.profileImage
    const navigate = useNavigate()
    const format = 'h:mm a';
    const [IsLoader, setIsLoader] = useState(false);
    // const [StartTime, startTimeChange] = useState(null);
    // const [endTime, endTimeChange] = useState(null);
    const [open, setPickerOpen] = useState(false);
    const [openEnd, setPickerOpenEnd] = useState(false);
    const now = moment().hour(0).minute(0);

    const [timeInterval, setTimeInterval] = useState('');
    const [selectedDays, setSelectedDays] = useState([]);
    const [startTime, setStartTime] = useState('');
    const [endTime, setEndTime] = useState('');
    const [paymentMethod, setPaymentMethod] = useState('');
    const [generatedSlots, setGeneratedSlots] = useState([]);
    const [sameForAllDays, setSameForAllDays] = useState(false);
    const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    function onChange(value) {
        console.log(value && value.format(format));
    }

    // const handleStartTime = (value) => {
    //     startTimeChange(
    //         value ? new moment(value, ["HH.mm"]).utc().format("hh:mm A") : null
    //     );
    // };

    // const handleEndTime = (value) => {
    //     endTimeChange(
    //         value ? new moment(value, ["HH.mm"]).utc().format("hh:mm A") : null
    //     );
    // };

    const isEndTimeDiabale = () => {
        if (startTime)
            return false;
        return true;
    };


    const handleTimeIntervalChange = (e) => {
        setTimeInterval(e.target.value);
    };

    const handleDayChange = (e) => {
        const day = e.target.value;
        const isChecked = e.target.checked;

        setSelectedDays((prevSelectedDays) => {
            let updatedSelectedDays;

            if (isChecked) {
                updatedSelectedDays = [...prevSelectedDays, day];
            } else {
                updatedSelectedDays = prevSelectedDays.filter((d) => d !== day);
            }

            // Check if all individual day checkboxes are selected
            const isAllDaysSelected = updatedSelectedDays.length === 7;

            // Update "Same for all days" checkbox accordingly
            setSameForAllDays(isAllDaysSelected);

            return updatedSelectedDays;
        });
    };

    const handleStartTimeChange = (value) => {
        // console.log("value", value);
        // setStartTime(e.target.value);
        // setStartTime(value);
        setStartTime(value ? new moment(value, ["HH.mm"]).format("hh:mm A") : null);
        // setStartTime(value ? new moment(value, ["HH.mm"]).utc().format("hh:mm A") : null);
    };

    const handleEndTimeChange = (value) => {
        // setEndTime(e.target.value);
        setEndTime(value ? new moment(value, ["HH.mm"]).format("hh:mm A") : null);
        // setEndTime(value ? new moment(value, ["HH.mm"]).utc().format("hh:mm A") : null);
    };

    useEffect(() => {
        generateSlots();
    }, [endTime, startTime, timeInterval, selectedDays]);

    // generate slots using UTC format
    const generateSlotsUTC = () => {
        const slots = selectedDays.map((day) => {
            const startTimeMoment = moment(startTime, ['HH:mm']).utc();
            const endTimeMoment = moment(endTime, ['HH:mm']).utc();
            const interval = parseInt(timeInterval, 10);

            const timeSlots = [];
            let currentTimeMoment = startTimeMoment.clone();

            while (currentTimeMoment.isBefore(endTimeMoment)) {
                const slotStartTime = currentTimeMoment.format('hh:mm A');
                currentTimeMoment.add(interval, 'minutes');
                const slotEndTime = currentTimeMoment.format('hh:mm A');

                timeSlots.push({
                    enabled: true,
                    slotId: timeSlots.length + 1,
                    label: `${slotStartTime} - ${slotEndTime} `,
                    start_time: `${slotStartTime} `,
                    end_time: `${slotEndTime} `,
                });
            }

            return {
                enabled: true,
                day,
                startTime: startTimeMoment.format('hh:mm A'),
                endTime: endTimeMoment.format('hh:mm A'),
                interval,
                time: timeSlots,
            };
        });

        setGeneratedSlots(slots);
    };

    const generateSlots = () => {
        const slots = selectedDays.map((day) => {
            const startTimeMoment = moment(startTime, ['hh:mm A']);
            const endTimeMoment = moment(endTime, ['hh:mm A']);
            const interval = parseInt(timeInterval, 10);

            const timeSlots = [];
            let currentTimeMoment = startTimeMoment.clone();

            while (currentTimeMoment.isBefore(endTimeMoment) || currentTimeMoment.isSame(endTimeMoment)) {
                const slotStartTime = currentTimeMoment.format('hh:mm A');
                currentTimeMoment.add(interval, 'minutes');
                const slotEndTime = currentTimeMoment.format('hh:mm A');

                if (currentTimeMoment.isBefore(endTimeMoment) || currentTimeMoment.isSame(endTimeMoment)) {
                    timeSlots.push({
                        enabled: true,
                        slotId: timeSlots.length + 1,
                        label: `${slotStartTime} - ${slotEndTime}`,
                        start_time: slotStartTime,
                        end_time: slotEndTime,
                    });
                }
            }

            return {
                enabled: true,
                day,
                startTime: startTimeMoment.format('hh:mm A'),
                endTime: endTimeMoment.format('hh:mm A'),
                interval,
                time: timeSlots,
            };
        });

        setGeneratedSlots(slots);
    };


    // const generateSlots = () => {
    //     const slots = selectedDays.map((day) => {
    //         const startTimeMoment = moment(startTime, ['HH:mm']);
    //         const endTimeMoment = moment(endTime, ['HH:mm']);
    //         const interval = parseInt(timeInterval, 10);

    //         const timeSlots = [];
    //         let currentTimeMoment = startTimeMoment.clone();

    //         while (currentTimeMoment.isBefore(endTimeMoment)) {
    //             const slotStartHours = currentTimeMoment.hours();
    //             const slotStartMinutes = currentTimeMoment.minutes();

    //             currentTimeMoment.add(interval, 'minutes');

    //             const slotEndHours = currentTimeMoment.hours();
    //             const slotEndMinutes = currentTimeMoment.minutes();

    //             timeSlots.push({
    //                 enabled: true,
    //                 slotId: timeSlots.length + 1,
    //                 label: `${slotStartHours}:${slotStartMinutes} - ${slotEndHours}:${slotEndMinutes}`,
    //                 start_time: {
    //                     hours: slotStartHours,
    //                     minutes: slotStartMinutes,
    //                 },
    //                 end_time: {
    //                     hours: slotEndHours,
    //                     minutes: slotEndMinutes,
    //                 },
    //             });
    //         }

    //         return {
    //             enabled: true,
    //             day,
    //             startTime: {
    //                 hours: startTimeMoment.hours(),
    //                 minutes: startTimeMoment.minutes(),
    //             },
    //             endTime: {
    //                 hours: endTimeMoment.hours(),
    //                 minutes: endTimeMoment.minutes(),
    //             },
    //             interval,
    //             time: timeSlots,
    //         };
    //     });

    //     setGeneratedSlots(slots);
    // };



    const handleSameForAllDaysChange = (e) => {
        const isChecked = e.target.checked;
        setSameForAllDays(isChecked);

        if (isChecked) {
            // Check all day checkboxes
            const allDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            setSelectedDays(allDays);
        } else {
            // Uncheck all day checkboxes
            setSelectedDays([]);
        }
    };

    const handleRemoveTimeSlot = (dayToRemove, slotToRemove) => {
        // Find the day's slot to remove
        const updatedGeneratedSlots = generatedSlots.map((slot) => {
            if (slot.day === dayToRemove) {
                // Filter out the canceled time slot
                slot.time = slot.time.filter((timeSlot) => timeSlot.slotId !== slotToRemove);
            }
            return slot;
        });

        setGeneratedSlots(updatedGeneratedSlots);
    };

    const handleSubmit = () => {
        const previousStepPayload = localStorage.getItem("expertSignupData")
            ? JSON.parse(localStorage.getItem("expertSignupData"))
            : "";
        const payload = {
            ...previousStepPayload,
            slots: generatedSlots,
            paymentMethod: paymentMethod
        }
        try {
            // console.log("patient details payload=", payload, JSON.stringify(payload));
            localStorage.setItem("expertSignupData", JSON.stringify(payload));
            navigate("/signup-as-expert-6", { state: { previousStepPayload: payload, profileImage: profileImage } })
        } catch (error) {
            toast.error(error, {
                position: toast.POSITION.TOP_RIGHT,
            });
        }
    }
    return (
        <>

            <div className='signup-as-expert-3'>
                <div className="container">
                    <div className="logo-container">
                        <div className="logo-cpn">
                            <img src={cpnLogo} alt="Logo" />
                        </div>
                        <div className="login-button">
                            <Link to="/login-as-expert">
                                <Button>
                                    Login
                                </Button>
                            </Link>
                        </div>
                    </div>
                    <div className="otp-input">

                        <Progress multi>
                            <Progress
                                bar
                                value="33.33"
                                style={{
                                    height: '5px'
                                }}
                            />
                            <Progress
                                bar
                                color="success"
                                value="33.33"

                            />
                            <Progress
                                bar
                                color="info"
                                value="33.33"

                            />
                        </Progress>
                    </div>
                    <div className="text-sign-up">
                        <h1>Sign Up as a Expert Consultants</h1>
                    </div>

                    <div className="text-sign-up-2">
                        <img src={tick} alt="" />
                        <h1>Availability & Payment Method</h1>
                    </div>
                </div>
                <div className="container">
                    <div className="content-date">
                        <div className="login-detail">
                            <div className="login-detail-img">
                                <img src={tick} alt="" />
                                <h1>Login Details</h1>
                            </div>
                            <div className="login-detail-img2-data">
                                <img src={tick} alt="" />
                                <h1>Personal Details</h1>
                            </div>
                            <div className="login-detail-img2-data">
                                <img src={tick} alt="" />
                                <h1>Professional Details</h1>
                            </div>
                            <div className="login-detail-img2-data" >
                                <img src={tick} alt="" />
                                <h1>Employment Details</h1>
                            </div>
                            <div className="login-detail-img2-data">
                                <img src={tick} alt="" />
                                <h1>Availability & Payment Method</h1>
                            </div>
                            <div className="login-detail-img2-data" style={{ opacity: '0.32' }}>
                                <img src={tick} alt="" />
                                <h1>Upload W-9</h1>
                            </div>
                            <div className="login-detail-img3-data" style={{ opacity: '0.32' }}>
                                <img src={tick} alt="" />
                                <h1>Sign HIPAA/GDPR Agreement & CPN Agreement</h1>

                            </div>
                        </div>
                        <div className="form-data-container">

                            <Form >
                                <Col md={6}>
                                    <div className="form-group mb-1">
                                        <label>Time Slot</label>
                                    </div>
                                    <Input
                                        type='select'
                                        id='exampleSlect'
                                        onChange={handleTimeIntervalChange}
                                        value={timeInterval}
                                    >
                                        <option value="">Select Time</option>
                                        <option value="15">15 min</option>
                                        <option value="30">30 min</option>
                                        <option value="45">45 min</option>
                                        <option value="60">60 min</option>
                                    </Input>

                                </Col>
                                <h6 className='mt-2'>Select day</h6>
                                <div className='gender-radiotype'>
                                    {daysOfWeek.map((day) => (
                                        <FormGroup check key={day}>
                                            <Input
                                                name={day}
                                                type="checkbox"
                                                value={day}
                                                onChange={handleDayChange}
                                                checked={selectedDays.includes(day)}
                                            />
                                            <Label check>{day}</Label>
                                        </FormGroup>
                                    ))}
                                </div>
                            </Form>

                            {/* {/ Time slot start /} */}
                            <div className="time-slot mt-3 d-flex">
                                <div className="form-group ">
                                    <label>Start Time</label>
                                    <TimePicker
                                        showSecond={false}
                                        // defaultValue={now}
                                        className="timePickerClass "
                                        // onChange={handleStartTime}
                                        onOpen={() => setPickerOpen(true)}
                                        onAmPmChange={() => setPickerOpen(!open)}
                                        format={format}
                                        use12Hours
                                        open={open}
                                        allowEmpty
                                        disabled={selectedDays.length === 0 || !timeInterval}
                                        placeholder="--:-- --"
                                        value={
                                            startTime ? new moment(startTime, "HH:mm A").local() : null
                                        }
                                        // startTime ? new moment.utc(startTime, "HH:mm A").local() : null
                                        onChange={handleStartTimeChange}
                                    // value={startTime}
                                    // inputReadOnly
                                    />
                                </div>


                                <div className="form-group mx-4">
                                    <label>End Time</label>
                                    {/* <Input
                                    type="time"
                                    placeholder="--:-- --"
                                    onChange={handleEndTimeChange}
                                    value={endTime}
                                    disabled={selectedDays.length === 0 || isEndTimeDiabale() || !timeInterval}
                                /> */}
                                    <TimePicker
                                        showSecond={false}
                                        // defaultValue={now}
                                        disabled={isEndTimeDiabale()}
                                        className=" timePickerClass "
                                        onAmPmChange={() => setPickerOpenEnd(!openEnd)}
                                        onOpen={() => setPickerOpenEnd(true)}
                                        format={format}
                                        use12Hours
                                        open={openEnd}
                                        allowEmpty
                                        placeholder="--:-- --"
                                        // onChange={handleEndTime}
                                        value={
                                            endTime
                                                ? new moment(endTime, "HH:mm A").local() : null
                                        }
                                        // ? new moment.utc(endTime, "HH:mm A").local() : null
                                        onChange={handleEndTimeChange}
                                    // value={endTime}
                                    // inputReadOnly
                                    />
                                </div>
                                <FormGroup check>
                                    <Input name="gender" type="checkbox" onChange={handleSameForAllDaysChange}
                                        checked={sameForAllDays} value="ntos" id="radioSaturday" />
                                    <Label check htmlFor="radioSaturday" className='same-label'>
                                        Same for all days
                                    </Label>
                                </FormGroup>
                            </div>

                            {/* {/ Time slot container area /} */}
                            <div className="slot-time-area mt-2">
                                <div className="for-all-days">
                                    <Label>Time Slots (For all days)</Label>
                                </div>
                                <div className="box-time-slot">
                                    {generatedSlots?.map((slot, index) => (
                                        <div className="form-group box mt-4 d-flex" key={index}>
                                            <Row>
                                                <div className="slot-contnet mb-2">
                                                    {/* <h5>{slot.day}</h5> */}
                                                    <h5>Time Slots {slot.day}</h5>
                                                </div>
                                                {slot?.time?.map((timeSlot) => (
                                                    <Col key={timeSlot.slotId} className='slot-col mx-3 mb-3'>
                                                        <label>{timeSlot.label}</label>
                                                        <span className="remove-icon" onClick={() => handleRemoveTimeSlot(slot.day, timeSlot.slotId)}>
                                                            <CrossIcon />

                                                        </span>
                                                        {/* <Input placeholder={timeSlot.label} disabled /> */}
                                                        {/* <button onClick={() => handleRemoveTimeSlot(slot.day, timeSlot.slotId)}>Cancel</button> */}
                                                    </Col>
                                                ))}
                                            </Row>
                                        </div>
                                    ))}
                                </div>

                            </div>

                            {/* {/ last container /} */}
                            <div className="last-content mt-3">
                                <Col md={8}>
                                    <FormGroup>
                                        <Label>
                                            Preferred Payment Method
                                        </Label>
                                        <Input type='select'
                                            placeholder='Select one'
                                            onChange={(e) => setPaymentMethod(e.target.value)}
                                        >
                                            <option value="">Select an option</option>
                                            <option value="option1">Option 1</option>
                                            <option value="option2">Option 2</option>
                                            <option value="option3">Option 3</option>
                                        </Input>
                                    </FormGroup>
                                </Col>

                                <Col md={8} className='mb-5'>
                                    <Button className='btn-secondry' onClick={handleSubmit}>
                                        Next
                                    </Button>
                                </Col>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
            <Footer />
        </>


    )
}

export default ExpertAvailabilitySignUp5