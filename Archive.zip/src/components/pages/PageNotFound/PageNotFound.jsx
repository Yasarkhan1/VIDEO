import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const PageNotFound = () => {
    const [isLogin, setIsLogin] = useState(false)
    const token = sessionStorage.getItem("token")
    const userType = sessionStorage.getItem("userType") ? sessionStorage.getItem("userType") : ""

    useEffect(() => {
        if (token) {
            setIsLogin(true)
        } else {
            setIsLogin(false)
        }
    }, [token])
    return (
        <div className="container text-center">
            <div className="row justify-content-center">
                <div className="col-md-6">
                    <h1 className="mt-5">404</h1>
                    <h3 className="mb-4">Page Not Found</h3>
                    <p className="mb-4">The requested page could not be found.</p>
                    {
                        userType == "1"
                            ?
                            <Link to={token ? "/patient-dashboard " : "/login-as"} className="btn btn-primary">Go Home</Link>
                            :
                            userType == "2"
                                ?
                                <Link to={token ? "/expert-dashboard " : "/login-as"} className="btn btn-primary">Go Home</Link>
                                : userType == "3"
                                    ? <Link to={token ? "/cpn-dashboard " : "/login-as"} className="btn btn-primary">Go Home</Link>
                                    : <Link to={"/login-as"} className="btn btn-primary">Go Home</Link>
                    }
                </div>
            </div>
        </div>
    );
};

export default PageNotFound;