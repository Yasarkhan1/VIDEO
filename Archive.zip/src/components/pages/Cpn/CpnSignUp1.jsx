import React, { useState, useEffect } from 'react'
import { FormGroup, Input, Label, Form, FormText, Button, Progress } from 'reactstrap';
import tick from "../../../assests/images/check-circle-svgrepo-com (2).svg";
import cpnLogo from "../../../assests/images/CPNHealthFINAL_fontembed.svg";
import eyeClose from "../../../assests/images/eye-closed-svgrepo-com.png";
import Footer from '../../common/Footer/Footer';
import { useNavigate, Link, useParams } from 'react-router-dom';
import { ReactComponent as HideIcon } from "../../../assests/images/hide.svg";
import { ReactComponent as ShowIcon } from "../../../assests/images/view.svg";
import { useFormik } from "formik";
import * as Yup from "yup";
import { checkSpace } from "../../../utils";
import { toast } from "react-toastify";

const CpnSignUp1 = () => {
    const params = useParams()
    const { email } = params
    console.log("params", email)
    useEffect(() => {
        if (email) {

        }
    }, [email])
    const navigate = useNavigate()
    const [IsLoader, setIsLoader] = useState(false);
    const [toggleIcon1, setToggleIcon1] = useState(false)
    const [toggleIcon2, setToggleIcon2] = useState(false)
    const [acceptTnC, setAcceptTnC] = useState(false)
    const [isDisable, setisDisable] = useState(false);
    const [toggleIcon, setToggleIcon] = useState(false)

    const togglePassword = () => {
        setToggleIcon(!toggleIcon)
    }
    const togglePassword1 = () => {
        setToggleIcon1(!toggleIcon1)
    }
    useEffect(() => {
        getPatchform();
    }, []);

    const getPatchform = () => {
        const step1Data = localStorage.getItem("cpnSignupData")
            ? JSON.parse(localStorage.getItem("cpnSignupData"))
            : "";
        console.log("step1Data", step1Data);

        if (step1Data) {
            formik.setValues({

                email: step1Data.email,
                password: step1Data.password,
                confirmPassword: step1Data.password,
            });
        }
    };


    const formik = useFormik({
        initialValues: {
            email: email ? email : "",
            password: "",
            confirmPassword: "",
        },
        validationSchema: Yup.object({
            email: Yup.string().email("Invalid email address").required("*Email is required."),
            password: Yup.string()
                .required("*Password is required")
                .matches(
                    /^(?=.*?[A-Z])(?=(.*[a-z]){1,})(?=(.*[\d]){1,})(?=(.*[\W]){1,})(?!.*\s).{8,}$/,
                    "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character"
                ),
            confirmPassword: Yup.string()
                .required("*Confirm password is required")
                .matches(
                    /^(?=.*?[A-Z])(?=(.*[a-z]){1,})(?=(.*[\d]){1,})(?=(.*[\W]){1,})(?!.*\s).{8,}$/,
                    "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character"
                ).oneOf([Yup.ref('password'), null], 'Password and Confirm password should be same')
        }),

        onSubmit: async (values) => {
            if (!acceptTnC) {
                toast.error("Please Accept Terms & Conditions and Privacy Policy", {
                    position: toast.POSITION.TOP_RIGHT,
                });
                return
            } else {

                const patientSignupData = localStorage.getItem("cpnSignupData")
                    ? JSON.parse(localStorage.getItem("cpnSignupData"))
                    : "";
                const payload = {
                    ...patientSignupData,
                    email: values.email,
                    password: values.password,
                };

                try {
                    localStorage.setItem("cpnSignupData", JSON.stringify(payload));
                    console.log("patient details payload=", payload);
                    navigate("/signup-as-cpn-2")
                } catch (error) {
                    toast.error(error, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                }
            }
        }
    });
    return (
        <>
            <div className='cpn-sinup1-detail'>
                <div className="container">
                    <div className="logo-container">
                        <div className="logo-cpn">
                            <img src={cpnLogo} alt="Logo" />
                        </div>
                        <div className="login-button">
                            <Link to={"/login-as-cpn"}><Button> Login </Button></Link>
                        </div>
                    </div>
                    <div className="otp-input">
                        <Progress multi>
                            <Progress
                                bar
                                value="33.33"
                                style={{
                                    height: '3px'
                                }}
                            />
                            <Progress
                                bar
                                color="success"
                                value="33.33"
                                style={{ height: '3px' }}

                            />
                            <Progress
                                bar
                                color="info"
                                value="33.33"
                                style={{ height: '3px' }}
                            />


                        </Progress>
                    </div>
                    <div className="text-sign-up">
                        <h1>Sign Up as a CPN</h1>
                    </div>
                    <div className="text-sign-up-2">
                        <img src={tick} alt="" />
                        <h1>Login Details</h1>
                    </div>
                </div>
                <div className="container">
                    <div className="content-date">
                        <div className="login-detail">
                            <div className="login-detail-img">
                                <img src={tick} alt="" />
                                <h1>Login Details</h1>
                            </div>
                            <div className="login-detail-img2-data" style={{ opacity: '0.32' }}>
                                <img src={tick} alt="" />
                                <h1>Personal Details</h1>
                            </div>
                            <div className="login-detail-img2-data" style={{ opacity: '0.32' }}>
                                <img src={tick} alt="" />
                                <h1>Sign legal document with information on HIPAA, Patient permission taken</h1>
                            </div>

                        </div>

                        <div className="form-data-container">

                            <Form onSubmit={formik.handleSubmit}>
                                <FormGroup>
                                    <Label for="exampleEmail">
                                        Email Address
                                    </Label>
                                    <Input
                                        id="exampleEmail"
                                        name="email"
                                        placeholder="Enter Email Address"
                                        type="email"
                                        disabled
                                        {...formik.getFieldProps("email")}
                                        onKeyDown={checkSpace}
                                        className={formik.touched.email && formik.errors.email ? "is-invalid" : ""}
                                    // invalid={formik.touched.email && formik.errors.email ? true : false}
                                    />
                                    {formik.touched.email && formik.errors.email ? <small className="validation_error">{formik.errors.email}</small> : null}
                                </FormGroup>
                                <FormGroup>
                                    <div className="pasword">
                                        {/* <img src={eyeClose} alt="" className='eyeclosed' /> */}
                                        <Label for="examplePassword">
                                            Password
                                        </Label>
                                        <Input

                                            name="password"
                                            placeholder="Enter Password"
                                            onKeyDown={checkSpace}
                                            {...formik.getFieldProps("password")}
                                            type={!toggleIcon1 ? "password" : "text"}
                                            className={formik.touched.password && formik.errors.password ? "is-invalid" : ""}
                                        // invalid={formik.touched.password && formik.errors.password ? true : false}
                                        />
                                        <span className={formik.touched.password && formik.errors.password ? 'pwdToggleError' : 'pwdToggle'}>
                                            {toggleIcon ? (
                                                <span onClick={togglePassword}>
                                                    <ShowIcon />
                                                </span>
                                            ) : (
                                                <span onClick={togglePassword}>
                                                    <HideIcon />
                                                </span>
                                            )}
                                        </span>
                                        {formik.touched.password && formik.errors.password ? (
                                            <span className="validation_error">{formik.errors.password}</span>
                                        ) : null}
                                    </div>
                                </FormGroup>

                                <FormGroup>
                                    <div className="confrimpasword">
                                        {/* <img src={eyeClose} alt="" className='eyeclosed' /> */}
                                        <Label for='examplePassword'> Confirm Password</Label>

                                        <Input
                                            name="confirmPassword"
                                            placeholder="Enter Password"
                                            type={!toggleIcon2 ? "password" : "text"}
                                            onKeyDown={checkSpace}
                                            {...formik.getFieldProps("confirmPassword")}
                                            invalid={formik.touched.confirmPassword && formik.errors.confirmPassword ? true : false}
                                        />
                                        <span className={formik.touched.password && formik.errors.password ? 'pwdToggleError' : 'pwdToggle'}>
                                            {toggleIcon ? (
                                                <span onClick={togglePassword}>
                                                    <ShowIcon />
                                                </span>
                                            ) : (
                                                <span onClick={togglePassword}>
                                                    <HideIcon />
                                                </span>
                                            )}
                                        </span>
                                        {formik.touched.confirmPassword && formik.errors.confirmPassword ? (
                                            <small className="validation_error">{formik.errors.confirmPassword}</small>
                                        ) : null}
                                    </div>

                                </FormGroup>

                                <FormGroup check className='tnc-policy'>
                                    <Input type="checkbox" onChange={(e) => setAcceptTnC(e.target.checked)} checked={acceptTnC} />
                                    {' '}
                                    <Label check>
                                        Accept <Link to='/'>Terms & Conditions</Link> and <Link to='/'>Privacy Policy</Link>
                                    </Label>
                                </FormGroup>
                                <Button className='btn-secondry mb-4' type='submit'>
                                    Next
                                </Button>
                            </Form>
                        </div>
                    </div>
                </div>

            </div>
            <Footer />
        </>
    )
}

export default CpnSignUp1
