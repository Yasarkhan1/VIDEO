import React, { useState, useEffect } from 'react'
import { Link, useNavigate, useParams, useLocation } from 'react-router-dom'
import { Row, Modal, ModalHeader, ModalBody, ModalFooter, Input, Button, Col } from 'reactstrap'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import 'font-awesome/css/font-awesome.min.css';
import CpnSidebar from '../../common/CpnSidebar/CpnSidebar'
import authenticationCpnIsServices from "../../../services/cpnIsServices";
import { toast } from "react-toastify";
import SpinnerLoader from '../../common/Spinner'

const CpnMessageView = () => {
    const navigate = useNavigate()
    const location = useLocation()
    const [IsLoader, setIsLoader] = useState(false);
    const [error, setError] = useState(false);
    const [message, setmessage] = useState('');
    const { state: { msgData, patientId, cpnId } = {} } = location
    console.log("location", location, msgData, patientId, cpnId)

    const onSubmit = async () => {
        if (message === '') {
            setError(true)
        } else {

            setError(false)
            const payload = {
                "message": message,
                "patientId": patientId,
                "cpnId": cpnId
            }
            try {
                setIsLoader(true);
                let res = await authenticationCpnIsServices.sendMessageWithPatient(payload)
                if (res.data.status === 200) {
                    setIsLoader(false);
                    toast.success("Message send successfully", {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                    navigate("/cpn-patient-message")
                } else {
                    setIsLoader(false);
                    toast.error(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                }
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        }
    }

    useEffect(() => {
        if (message) {
            setError(false)
        }
    }, [message])

    return (
        <>
            {IsLoader && <SpinnerLoader />}
            <div className='cpn-message-view'>
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className="parent-div">
                        <CpnSidebar />
                        <div className="child-div">
                            <div className="all-content">
                                <Row className='text-detail-content'>

                                    <Col md={3}>

                                        <div className="text-patient-left">
                                            <h5>Patient</h5>
                                            <h6>(10/08/23, 11:30Am)</h6>
                                        </div>
                                    </Col>
                                    <Col md={6}>
                                        <div className="text-patient-right">
                                            <h6>{msgData}</h6>

                                        </div>
                                    </Col>

                                </Row>

                                <div className="reply-text-message text-center">
                                    <Col md={8} className="mx-auto">
                                        <Input
                                            type='textarea'
                                            placeholder='type here....'
                                            onChange={(e) => setmessage(e.target.value)}
                                            rows={6} />
                                        {error ? <small className="validation_error">Message is required</small> : null}
                                    </Col>


                                    <button className='submit' onClick={onSubmit}>Submit</button>


                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
            <Footer />
        </>
    )
}

export default CpnMessageView
