import React, { useState } from 'react'
import { Table } from 'reactstrap'
import { Link } from 'react-router-dom'
import { Progress, Form, FormGroup, Button, Modal, ModalHeader, ModalBody, ModalFooter, Input, Row, Col } from 'reactstrap'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import Logoimage from '../../../assests/images/ys.png'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar';
import { useSelector, useDispatch } from 'react-redux';
import dayjs from "dayjs";
import CpnSidebar from '../../common/CpnSidebar/CpnSidebar'
import Creaditcard from '../../../assests/images/credit-card-pay-svgrepo-com.png';


const CpnEcList = () => {


    const [appointmentListData, setAppointmentListData] = useState([])

    const [open, setOpen] = useState(false);
    const notesToggle = () => { setOpen(!open) };
    const [slectedTab, setslectedTab] = useState('tab1')
    const [currentPage, setCurrentPage] = useState(0);
    const appointmentsPerPage = 5;

    const handlePageClick = ({ selected }) => {
        setCurrentPage(selected);
    };

    const offset = currentPage * appointmentsPerPage;
    const currentAppointments = appointmentListData.slice(offset, offset + appointmentsPerPage);

    const [IsLoader, setIsLoader] = useState(false);
    const userData = useSelector((state) => state.user.cpnIsUser);




    const tabChange = (value) => {
        setslectedTab(value)
    }
    return (
        <>
            <div className='cpn-ec-list'>
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className="parent-div">
                        <CpnSidebar />

                        <div className="child-div">

                            <div className="container-table">

                                <table className="table table-bordered">
                                    <thead>
                                        <tr>

                                            <th scope="col">Patient Name</th>
                                            <th scope="col">Age</th>
                                            <th scope="col"> Sex</th>
                                            <th scope='col'>Speciality</th>
                                            <th scope='col'>Daily Availability</th>
                                            <th scope='col'> Time Slot</th>
                                            <th scope='col'>Service</th>
                                            <th scope='col'>Slot</th>
                                            <th scope='col'>Charges</th>
                                            <th scope='col'>EC Details</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>

                                            <td>Ali Ahmad</td>
                                            <td>32</td>
                                            <td>M</td>
                                            <td>Gastro</td>
                                            <td>M, T, W, T, F, S</td>
                                            <td>30 min</td>
                                            <td> Consultation</td>
                                            <td>1 Week</td>
                                            <td>$100</td>
                                            <td onClick={notesToggle}><a href='#'> View</a></td>
                                        </tr>
                                        <tr>
                                            <td>Shahnawaz</td>
                                            <td>32</td>
                                            <td>M</td>
                                            <td>Physician</td>
                                            <td>M, T, W, T, F, S</td>
                                            <td>30 min</td>
                                            <td> Consultation</td>
                                            <td>11 Aug 23, 11:00AM</td>
                                            <td>$100</td>
                                            <td><a href='#'> View</a></td>
                                        </tr>
                                        <tr>
                                            <td>Saqlain</td>
                                            <td>32</td>
                                            <td>M</td>
                                            <td>Gastro</td>
                                            <td>M, T, W, T, F, S</td>
                                            <td>30 min</td>
                                            <td> Consultation</td>
                                            <td>11 Aug 23, 11:00AM</td>
                                            <td>$100</td>
                                            <td><a href='#'> View</a></td>
                                        </tr>
                                        <tr>
                                            <td>Usama</td>
                                            <td>32</td>
                                            <td>F</td>
                                            <td>Gastro</td>
                                            <td>M, T, W, T, F, S</td>
                                            <td>30 min</td>
                                            <td> Consultation</td>
                                            <td>11 Aug 23, 11:00AM</td>
                                            <td>$100</td>
                                            <td><a href='#'> View</a></td>
                                        </tr>
                                        <tr>
                                            <td>Shoeb</td>
                                            <td>32</td>
                                            <td>M</td>
                                            <td>Physician</td>
                                            <td>M, T, W, T, F, S</td>
                                            <td>30 min</td>
                                            <td> Consultation</td>
                                            <td>11 Aug 23, 11:00AM</td>
                                            <td>$100</td>
                                            <td><a href='#'> View</a></td>
                                        </tr>
                                        <tr>
                                            <td>Akhtar</td>
                                            <td>32</td>
                                            <td>F</td>
                                            <td>Physician</td>
                                            <td>M, T, W, T, F, S</td>
                                            <td>30 min</td>
                                            <td> Consultation</td>
                                            <td>11 Aug 23, 11:00AM</td>
                                            <td>$100</td>
                                            <td><a href='#'> View</a></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <Footer />

            {/* Modal */}
            <div className='cpn-modal-one'>
                <Modal isOpen={open} toggle={notesToggle} className="custom-modal" centered>
                    <div className="modal-overlay">
                        <ModalHeader toggle={notesToggle} />
                        <ModalBody>
                            <div>
                                <Row>
                                    <Col md={3}>
                                        <button className={`Ec_Name_button ${slectedTab === 'tab1' ? '' : 'disable-color'}`} onClick={() => tabChange("tab1")}>Personal Details</button>

                                    </Col>
                                    <Col md={3}>
                                        <button className={`professional_button ${slectedTab === 'tab2' ? '' : 'disable-color'}`} onClick={() => tabChange("tab2")}>Professional Details</button>
                                    </Col>
                                    <Col md={3}>
                                        <button className={`call_charges_button ${slectedTab === 'tab3' ? '' : 'disable-color'}`} onClick={() => tabChange("tab3")}>Availability</button>
                                    </Col>
                                    <Col md={3}>
                                        <button className={`call_charges_button ${slectedTab === 'tab4' ? '' : 'disable-color'}`} onClick={() => tabChange("tab4")}>Fees</button>
                                    </Col>
                                </Row>
                                {/* First Button Profile-Ec */}
                                {slectedTab === 'tab1' && <div className="profile-ec mt-4">
                                    <div className="middle-contnet">
                                        <div className="row g-0 py-2  border-bottom">
                                            <div className="col-sm-6 col-md-6">
                                                <h3 className='heading-profile'>Doctor Name</h3>

                                            </div>
                                            <div className="col-sm-2 col-md-6">
                                                <h4 className='heading-profile1'></h4>
                                            </div>
                                            <div className="line"></div>
                                        </div>


                                        {/* Country */}
                                        <div className="row g-0  py-2 border-bottom">
                                            <div className="col-sm-6 col-md-6">
                                                <h3 className='heading-profile'>Email Address</h3>

                                            </div>
                                            <div className="col-sm-2 col-md-6">
                                                <h4 className='heading-profile1'></h4>
                                            </div>
                                            <div className="line"></div>
                                        </div>
                                        {/* time-zone */}
                                        <div className="row g-0  py-2 border-bottom">
                                            <div className="col-sm-6 col-md-6">
                                                <h3 className='heading-profile'>Country</h3>

                                            </div>
                                            <div className="col-sm-2 col-md-6">
                                                <h4 className='heading-profile1'></h4>
                                            </div>
                                            <div className="line"></div>
                                        </div>
                                        {/* Contact */}
                                        <div className="row g-0  py-2 border-bottom">
                                            <div className="col-sm-6 col-md-6">
                                                <h3 className='heading-profile'>Contact</h3>

                                            </div>
                                            <div className="col-sm-2 col-md-6">
                                                <h4 className='heading-profile1'></h4>
                                            </div>
                                            <div className="line"></div>
                                        </div>

                                        {/* Country */}

                                    </div>
                                    <div className="left-side-image-edit">
                                        <div className="profile-image-left">
                                            <img src={Logoimage} alt="" />
                                        </div>

                                    </div>
                                </div>}
                                {/* Second Button Professional */}
                                {slectedTab === 'tab2' && <div className="professional mt-4">
                                    <div className="professional-contnet">
                                        <div className="row g-0 py-2  border-bottom">
                                            <div className="col-sm-6 col-md-4">
                                                <h3 className='heading-profile'>Specialty</h3>
                                            </div>
                                            <div className="col-sm-2 col-md-6">
                                                <h5 className='heading-profile1'>Alim</h5>
                                            </div>
                                            <div className="line"></div>
                                        </div>


                                        {/* Country */}
                                        <div className="row g-0  py-2 border-bottom">
                                            <div className="col-sm-6 col-md-4">
                                                <h3 className='heading-profile'>Degree</h3>

                                            </div>
                                            <div className="col-sm-2 col-md-6">
                                                <h4 className='heading-profile1'></h4>
                                            </div>
                                            <div className="line"></div>
                                        </div>
                                        {/* time-zone */}
                                        <div className="row g-0  py-2 border-bottom">
                                            <div className="col-sm-6 col-md-4">
                                                <h3 className='heading-profile'>Medical School</h3>

                                            </div>
                                            <div className="col-sm-2 col-md-6">
                                                <h4 className='heading-profile1'></h4>
                                            </div>
                                            <div className="line"></div>
                                        </div>


                                        {/* Residency */}
                                        <div className="row g-0  py-2 border-bottom">
                                            <div className="col-sm-6 col-md-4">
                                                <h3 className='heading-profile'>Residency</h3>

                                            </div>
                                            <div className="col-sm-2 col-md-6">
                                                <h4 className='heading-profile1'></h4>
                                            </div>
                                            <div className="line"></div>
                                        </div>
                                        {/* Fellowship */}
                                        <div className="row g-0  py-2 border-bottom">
                                            <div className="col-sm-6 col-md-4">
                                                <h3 className='heading-profile'>Fellowship</h3>

                                            </div>
                                            <div className="col-sm-2 col-md-6">
                                                <h4 className='heading-profile1'></h4>
                                            </div>
                                            <div className="line"></div>
                                        </div>

                                        {/* Area of Expertise */}
                                        <div className="row g-0  py-2 border-bottom">
                                            <div className="col-sm-6 col-md-4">
                                                <h3 className='heading-profile'>Area of Expertise</h3>

                                            </div>
                                            <div className="col-sm-2 col-md-6">
                                                <h4 className='heading-profile1'></h4>
                                            </div>
                                            <div className="line"></div>
                                        </div>
                                        {/* Role */}
                                        <div className="row g-0  py-2 border-bottom">
                                            <div className="col-sm-6 col-md-4">
                                                <h3 className='heading-profile'>Role</h3>

                                            </div>
                                            <div className="col-sm-2 col-md-6">
                                                <h4 className='heading-profile1'></h4>
                                            </div>
                                            <div className="line"></div>
                                        </div>
                                        {/*  Current Employer */}
                                        <div className="row g-0  py-2 border-bottom">
                                            <div className="col-sm-6 col-md-4">
                                                <h3 className='heading-profile'> Current Employer</h3>

                                            </div>
                                            <div className="col-sm-2 col-md-6">
                                                <h4 className='heading-profile1'></h4>
                                            </div>
                                            <div className="line"></div>
                                        </div>
                                        {/*     Web Profile */}
                                        <div className="row g-0  py-2 border-bottom">
                                            <div className="col-sm-6 col-md-4">
                                                <h3 className='heading-profile'>    Web Profile</h3>

                                            </div>
                                            <div className="col-sm-2 col-md-6">
                                                <h4 className='heading-profile1'></h4>
                                            </div>
                                            {/* <div className="line"></div> */}
                                        </div>
                                    </div>

                                </div>}
                                {/* Third Button Call Charges */}
                                {slectedTab === 'tab3' && <div className="profile-ec mt-4">
                                    <div className="CallCharges-content">
                                        <div className="row g-0 py-2">
                                            <div className=" col-md-12">
                                                <img src={Creaditcard} alt="" />
                                                <h3>Fees $56</h3>
                                            </div>

                                        </div>

                                    </div>

                                </div>}
                            </div>
                        </ModalBody>
                    </div>
                </Modal>
            </div>
        </>
    )
}

export default CpnEcList
