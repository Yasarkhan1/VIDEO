import React, { useState } from 'react'
import { Table } from 'reactstrap'
import { Link } from 'react-router-dom'
import { Progress, Form, FormGroup, Button } from 'reactstrap'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import Logoimage from '../../../assests/images/ys.png'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar';
import { useSelector, useDispatch } from 'react-redux';
import dayjs from "dayjs";
import CpnSidebar from '../../common/CpnSidebar/CpnSidebar'


const CpnMyProfile = () => {

    const [IsLoader, setIsLoader] = useState(false);
    const userData = useSelector((state) => state.user?.cpnIsUser);
    const { name, contactNumber, dateofbirth } = userData || {}
    return (
        <>
            <div className='cpn-my-profile'>
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className="parent-div">
                        <CpnSidebar />

                        <div className="child-div">
                            <div className="middle-contnet">
                                <div className="row g-0 py-2  border-bottom">
                                    <div className="col-sm-6 col-md-4">
                                        <h3 className='heading-profile'>Name</h3>

                                    </div>
                                    <div className="col-sm-2 col-md-6">
                                        <h4 className='heading-profile1'>{name}</h4>
                                    </div>
                                    <div className="line"></div>
                                </div>
                                {/* Date of Birth */}
                                <div className="row g-0  py-2 border-bottom ">
                                    <div className="col-sm-6 col-md-4">
                                        <h3 className='heading-profile'>Date of Birth</h3>

                                    </div>
                                    <div className="col-sm-2 col-md-6">
                                        <h4 className='heading-profile1'>{dayjs(dateofbirth).format('DD/MM/YYYY')}</h4>
                                        {/* <h4 className='heading-profile1'>12/01/2003</h4> */}
                                    </div>
                                    <div className="line"></div>
                                </div>
                                {/* Gender */}
                                <div className="row g-0  py-2 border-bottom ">
                                    <div className="col-sm-6 col-md-4">
                                        <h3 className='heading-profile'>Gender</h3>

                                    </div>
                                    <div className="col-sm-2 col-md-6">
                                        <h4 className='heading-profile1'>{userData?.gender}</h4>
                                    </div>
                                    <div className="line"></div>
                                </div>
                                {/* Email Address */}
                                <div className="row g-0  py-2 border-bottom">
                                    <div className="col-sm-6 col-md-4">
                                        <h3 className='heading-profile'>Email Address</h3>

                                    </div>
                                    <div className="col-sm-2 col-md-6">
                                        <h4 className='heading-profile1'>{userData?.email}</h4>
                                    </div>
                                    <div className="line"></div>
                                </div>
                                {/* Country */}
                                <div className="row g-0  py-2 border-bottom">
                                    <div className="col-sm-6 col-md-4">
                                        <h3 className='heading-profile'>Country</h3>

                                    </div>
                                    <div className="col-sm-2 col-md-6">
                                        <h4 className='heading-profile1'>{userData?.country}</h4>
                                    </div>
                                    <div className="line"></div>
                                </div>
                                {/* Contact Number */}
                                <div className="row g-0  py-2  ">
                                    <div className="col-sm-6 col-md-4">
                                        <h3 className='heading-profile'>Contact Number</h3>

                                    </div>
                                    <div className="col-sm-2 col-md-6">
                                        <h4 className='heading-profile1'>{contactNumber}</h4>
                                    </div>

                                </div>
                                {/* Country */}

                            </div>


                        </div>
                    </div>
                </div>
            </div>

            <Footer />


        </>
    )
}

export default CpnMyProfile
