import React, { useState, useEffect, useRef } from 'react'
import { FormGroup, Input, Label, Form, FormText, Button, Progress, Row, Col } from 'reactstrap';
import tick from "../../../assests/images/check-circle-svgrepo-com (2).svg";
import cpnLogo from "../../../assests/images/CPNHealthFINAL_fontembed.svg";
import Footer from '../../common/Footer/Footer';
import "react-datepicker/dist/react-datepicker.css";
import { useNavigate, Link } from 'react-router-dom';
import { useFormik } from "formik";
import * as Yup from "yup";
import { checkSpace } from "../../../utils";
import { toast } from "react-toastify";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";

const CpnSignUp2 = () => {

    const navigate = useNavigate()
    const [IsLoader, setIsLoader] = useState(false);
    const [countryCode, setCountryCode] = useState('');
    const [contactNumber, setcontactNumber] = useState('');



    const handleMobileChange = (value, data) => {
        setCountryCode("+" + data.dialCode)
        let contactNumbernew = value.slice(data.dialCode.length)
        setcontactNumber(contactNumbernew)
        formik.setFieldValue("mobileNumber", value)


    }


    useEffect(() => {
        const step1Data = localStorage.getItem("cpnSignupData")
            ? JSON.parse(localStorage.getItem("cpnSignupData"))
            : "";
        const { email, password } = step1Data
        if (!email || !password) {
            navigate('/signup-as-cpn-1')
        } else {
            getPatchform();
        }
    }, [])

    // fill data in fields after back.
    const getPatchform = () => {
        const step2Data = localStorage.getItem("cpnSignupData")
            ? JSON.parse(localStorage.getItem("cpnSignupData"))
            : "";
        console.log("step2Data++++", step2Data);
        const { name, address, contactNumber, qualification, countryCode } = step2Data
        // console.log("Date: ", dateString);
        if (name) {
            formik.setValues({
                name: name,
                qualification: qualification,
                address: address,
                mobileNumber: countryCode + contactNumber,
                // country: selectedCountryId,
            });
            setCountryCode(countryCode)
            setcontactNumber(contactNumber)
        }
    };

    const formik = useFormik({
        initialValues: {
            name: "",
            qualification: "",
            address: "",
            mobileNumber: "",
        },
        validationSchema: Yup.object({
            name: Yup.string()
                .required("*Name is required.")
                .min(3, "minimum three character are required."),
            qualification: Yup.string()
                .required("*Qualification  is required."),
            address: Yup.string()
                .required("*Address is required.")
                .min(5, "minimum five character are required."),
            mobileNumber: Yup.string()
                .required("*Contact number is required."),
            // .matches(
            //     /^[6-9]{1}[0-9]{9}$/,
            //     "Enter valid contact number"
            // ),
        }),

        onSubmit: async (values) => {
            const step1Data = localStorage.getItem("cpnSignupData")
                ? JSON.parse(localStorage.getItem("cpnSignupData"))
                : "";
            const { email, password } = step1Data
            const payload = {
                email: email,
                password: password,
                name: values.name,
                address: values.address,
                contactNumber: contactNumber,
                countryCode: countryCode,
                qualification: values.qualification
            };

            try {
                console.log("patient details payload=", payload, JSON.stringify(payload));
                localStorage.setItem("cpnSignupData", JSON.stringify(payload));
                navigate("/signup-as-cpn-3", { state: { step2Payload: payload } })
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        }
    });
    return (
        <>

            <div className='cpn-signup-details-2'>
                <div className="container">
                    <div className="logo-container">
                        <div className="logo-cpn">
                            <img src={cpnLogo} alt="Logo" />
                        </div>
                        <div className="login-button">
                            <Link to="/login-as-cpn">
                                <Button>
                                    Login
                                </Button>
                            </Link>
                        </div>
                    </div>
                    <div className="otp-input">

                        <Progress multi>
                            <Progress
                                bar
                                value="33.33"
                                style={{
                                    height: '5px'
                                }}
                            />
                            <Progress
                                bar
                                color="success"
                                value="33.33"

                            />
                            <Progress
                                bar
                                color="info"
                                value="33.33"

                            />
                        </Progress>
                    </div>
                    <div className="text-sign-up">
                        <h1>Sign Up as a CPN</h1>
                    </div>
                    {/* Mobile View Open */}
                    <div className="text-sign-up-2">
                        <img src={tick} alt="" />
                        <h1>Personal Details</h1>
                    </div>
                </div>
                <div className="container">
                    <div className="content-date">
                        <div className="login-detail">
                            <div className="login-detail-img">
                                <img src={tick} alt="" />
                                <h1>Login Details</h1>
                            </div>
                            <div className="login-detail-img2-data">
                                <img src={tick} alt="" />
                                <h1>Personal Details</h1>
                            </div>
                            <div className="login-detail-img2-data" style={{ opacity: '0.32' }}>
                                <img src={tick} alt="" />
                                <h1>Sign legal document with information on HIPAA, Patient permission taken</h1>
                            </div>

                        </div>
                        <div className="form-data-container">
                            <Form onSubmit={formik.handleSubmit}>
                                <FormGroup>
                                    <Label for="exampleFullname">
                                        Name
                                    </Label>
                                    <Input
                                        name="name"
                                        placeholder="Enter Name"
                                        type="text"
                                        {...formik.getFieldProps("name")}
                                        onKeyDown={checkSpace}
                                        className={formik.touched.name && formik.errors.name ? 'is-invalid' : ""}
                                    />
                                    {formik.touched.name && formik.errors.name ? <small className="validation_error">{formik.errors.name}</small> : null}
                                </FormGroup>


                                <FormGroup>
                                    <Label>
                                        Address
                                    </Label>
                                    <Input
                                        id='exampleText'
                                        name='address'
                                        placeholder='Enter Address'
                                        type='text'
                                        {...formik.getFieldProps("address")}
                                        onKeyDown={checkSpace}
                                        className={formik.touched.address && formik.errors.address ? 'is-invalid' : ""}
                                    />
                                    {formik.touched.address && formik.errors.address ? <small className="validation_error">{formik.errors.address}</small> : null}

                                </FormGroup>

                                <FormGroup>
                                    <Label for="exampleSelect">Qualification</Label>
                                    <Input
                                        id="exampleSelect"
                                        name="qualification"
                                        type="select"
                                        // {...formik.getFieldProps("qualification")}
                                        value={formik.values.qualification}
                                        onChange={(e) => {
                                            formik.handleChange(e); // Update Formik's state
                                        }}
                                        onBlur={formik.handleBlur}

                                        className={formik.touched.qualification && formik.errors.qualification ? 'is-invalid' : ""}

                                    >
                                        <option value="">Select Qualification</option>
                                        <option value="diploma">Diploma</option>
                                        <option value="Bachelor">Bachelor</option>


                                        {/* <option value="india">INDIA</option>
                                    <option>USA</option>
                                    <option>UAE</option>
                                    <option>US</option> */}

                                    </Input>
                                    {formik.touched.country && formik.errors.country ? <small className="validation_error">{formik.errors.country}</small> : null}
                                </FormGroup>





                                <FormGroup>
                                    <Label for=''>
                                        Contact Number
                                    </Label>
                                    <PhoneInput
                                        country="us"
                                        preferredCountries={["us"]}
                                        placeholder="Type your contact number here"
                                        value={formik.values.mobileNumber}
                                        onBlur={formik.handleBlur}
                                        // onChange={(value) => formik.setFieldValue("mobileNumber", value)}
                                        onChange={handleMobileChange}
                                        enableSearch={true}
                                        // {...formik.getFieldProps("mobileNumber")}
                                        inputStyle={{ width: "100%" }}
                                        inputClass={formik.touched.mobileNumber && formik.errors.mobileNumber ? " is-invalid" : ""}
                                        inputProps={{ name: "mobileNumber" }}
                                    />
                                    {formik.touched.mobileNumber && formik.errors.mobileNumber ? <small className="validation_error">{formik.errors.mobileNumber}</small> : null}
                                </FormGroup>


                                <Button className='btn-secondry mb-4' type='submit'>
                                    Next
                                </Button>
                            </Form>


                        </div>
                    </div>
                </div>
                <Footer />
            </div>

        </>
    )
}

export default CpnSignUp2
