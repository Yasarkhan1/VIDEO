import React, { useEffect, useState } from 'react'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import CpnSidebar from '../../common/CpnSidebar/CpnSidebar'
import MessageModal from '../../common/MessageModal/MessageModal'
import { Link, useNavigate } from 'react-router-dom'
import { Row, Modal, ModalHeader, ModalBody, ModalFooter, Input, Button, Col } from 'reactstrap'
import { useSelector } from 'react-redux';
import { toast } from "react-toastify";
import SpinnerLoader from '../../common/Spinner';
import authenticationCpnIsServices from "../../../services/cpnIsServices";


const CpnECMessage = () => {
    const [open, setOpen] = useState(false);
    const toggle = () => { setOpen(!open) };
    const userData = useSelector((state) => state.user.data);
    console.log("userData====+++", userData);


    const [IsLoader, setIsLoader] = useState(false);
    const [slectedTab, setslectedTab] = useState('tab1')
    const [msgData, setMsgData] = useState([]);
    const [currentPage, setCurrentPage] = useState(0);





    const MessageWithCPN = async () => {
        try {
            setIsLoader(true);
            let res = await authenticationCpnIsServices.getExpertWithCPN();
            console.log("getMessageWithCPN ===>>", res);
            if (res.data.status === 200) {
                const result = res.data.results;
                setMsgData(result);
                setIsLoader(false);
                toast.success(res.data.message, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            } else {
                setIsLoader(false);
                toast.error(res.data.message, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        } catch (error) {
            toast.error(error, {
                position: toast.POSITION.TOP_RIGHT,
            });
        }
    }

    useEffect(() => {
        MessageWithCPN();
    }, []);
    return (
        <>
            {IsLoader && <SpinnerLoader />}
            <div className='cpn-expert-consultant'>
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className="parent-div">
                        <CpnSidebar />
                        <div className="child-div">
                            {/* <div className="Initiate-message-button ">
                                <button className='btn-initiate' onClick={toggle}>Initiate Message</button>
                            </div> */}
                            <div className="all-message">
                                {msgData && msgData?.length > 0 ? (
                                    msgData?.map((item, index) => (
                                        <Row className='text-detail-content' key={index}>
                                            <Col md={3}>
                                                <div className="text-patient-left">
                                                    <h5>Abdullah Zaqir (CPN IS)</h5>
                                                    <h6>(10/08/23, 11:30Am)</h6>
                                                </div>
                                            </Col>
                                            <Col md={6}>
                                                <div className="text-patient-right">
                                                    <h6>{item.message}</h6>
                                                </div>
                                            </Col>
                                            <Col md={3}>
                                                <div className="text-view-message">
                                                    <Link to={`/cpn-expert-message-view/${item._id}`} state={{ msgData: item.message, expertConsulatant: item.expertConsulatant, cpnId: item.cpnId }}>
                                                        <i className="fa fa-edit fa-lg" onClick={toggle}></i>
                                                    </Link>
                                                </div>
                                            </Col>
                                        </Row>
                                    ))
                                ) : (
                                    <Row className='text-detail-content' >
                                        <Col md={3}>
                                        </Col>
                                        <Col md={6}>
                                            <div className="text-center mt-5">
                                                <h6>No message found</h6>
                                            </div>
                                        </Col>
                                        <Col md={3}>

                                        </Col>
                                    </Row>
                                )}
                            </div>


                        </div>
                    </div>
                </div>
            </div>
            <Footer />
            {open && < MessageModal open={open} setOpen={setOpen} toggle={toggle} cmp="EC-MSG" senderId={userData?._id} />}
        </>
    )
}

export default CpnECMessage
