import React, { useState } from 'react'
import { Table } from 'reactstrap'
import { Link } from 'react-router-dom'
import { Progress, Form, FormGroup, Button } from 'reactstrap'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import Logoimage from '../../../assests/images/ys.png'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar';
import { useSelector, useDispatch } from 'react-redux';
import dayjs from "dayjs";
import CpnSidebar from '../../common/CpnSidebar/CpnSidebar'

const CpnProfessional = () => {
  const [IsLoader, setIsLoader] = useState(false);
  const userData = useSelector((state) => state.user.cpnIsUser);
  return (
    <>
      <div className='cpn-professional-details'>
        <LoginNavbar />
        <div className="container-fluid custom-container-fluid mb-5">
          <div className="parent-div">
            <CpnSidebar />

            <div className="child-div">



            </div>
          </div>
        </div>
      </div>

      <Footer />


    </>
  )
}

export default CpnProfessional
