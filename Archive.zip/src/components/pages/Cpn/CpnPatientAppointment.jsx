import React, { useState, useEffect } from 'react'
import { Table } from 'reactstrap'
import { Link } from 'react-router-dom'
import { Progress, Form, FormGroup, Button } from 'reactstrap'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import Logoimage from '../../../assests/images/ys.png'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar';
import { useSelector, useDispatch } from 'react-redux';
import dayjs from "dayjs";
import CpnSidebar from '../../common/CpnSidebar/CpnSidebar'
import authenticationCpnIsServices from "../../../services/cpnIsServices";
import { toast } from "react-toastify";
import ReactPaginate from 'react-paginate'
import SpinnerLoader from '../../common/Spinner'

const CpnPatientAppointment = () => {
    const [IsLoader, setIsLoader] = useState(false);
    const userData = useSelector((state) => state.user.cpnIsUser);
    const [appointmentListData, setAppointmentListData] = useState([])
    const [currentPage, setCurrentPage] = useState(1);
    const appointmentsPerPage = 10;
    const [paginationData, setPaginationData] = useState({
        totalPages: 0,
        currentPage: 1,
        totalItems: 0,
    });
    const getAllScheduleAppointment = async (currentPage, appointmentsPerPage) => {
        try {
            setIsLoader(true);
            let res = await authenticationCpnIsServices.getAllScheduledAppointment(currentPage, appointmentsPerPage);
            console.log("getAllScheduleAppointment ===>>", res);
            if (res.data.status === 200) {
                const result = res.data.data
                setAppointmentListData(result)
                // Update pagination data from the API response
                setPaginationData({
                    totalPages: res.data.totalPages,
                    currentPage: res.data.currentPage,
                    totalItems: res.data.totalItems,
                });
                setIsLoader(false);
                toast.success(res.data.message, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            } else {
                setIsLoader(false);
                toast.error(res.data.message, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        } catch (error) {
            toast.error(error, {
                position: toast.POSITION.TOP_RIGHT,
            });
        }
    }

    useEffect(() => {
        getAllScheduleAppointment(currentPage, appointmentsPerPage)
    }, [currentPage, appointmentsPerPage])

    // const handlePageClick = ({ selected }) => {
    //     setCurrentPage(selected);
    // };

    const handlePageClick = async ({ selected }) => {
        console.log("selected", selected);
        const newCurrentPage = selected + 1;
        setCurrentPage(newCurrentPage);

        // Update the API call with the new page and appointmentsPerPage values
        // await getAllScheduleAppointment(newCurrentPage, appointmentsPerPage);
    };

    return (
        <>
            {IsLoader && <SpinnerLoader />}
            <div className='cpn-patient-appointments'>
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className="parent-div">
                        <CpnSidebar />

                        <div className="child-div">

                            <div className="container-table">

                                <table className="table table-bordered">
                                    <thead>
                                        <tr>

                                            <th scope="col">Patient Name</th>
                                            <th scope="col">Age</th>
                                            <th scope="col"> Sex</th>
                                            <th scope='col'>Stage</th>
                                            <th scope='col'>Appoint Status</th>
                                            <th scope='col'> Appointment ID</th>
                                            <th scope='col'>Service</th>
                                            <th scope='col'>Slot</th>
                                            <th scope='col'>Charges</th>
                                            <th scope='col'>History</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {appointmentListData.length ? (
                                            appointmentListData.map((item, index) => {
                                                const { demographicInformation: { age } = {}, status, patientData: [{ personalDetails: { name, dateOfBirth, sex } = {} } = {}] } = item;


                                                return <>
                                                    <tr key={index + item._id}>
                                                        <td>{name}</td>
                                                        <td>{age}</td>
                                                        <td>{sex}</td>
                                                        <td>{item?.cancerHistory?.stage}</td>
                                                        <td>{status}</td>
                                                        <td>{item._id}</td>
                                                        <td> -</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td><Link to={``}>View</Link> <Link to=''><span>Edit</span></Link></td>
                                                    </tr>
                                                </>
                                            })
                                        ) : (
                                            <tr>
                                                <td colSpan={10}>Data Not Found</td>
                                            </tr>
                                        )}

                                    </tbody>
                                </table>
                                {appointmentListData?.length > 0 && (
                                    <ReactPaginate
                                        previousLabel={'Previous'}
                                        nextLabel={'Next'}
                                        breakLabel={'...'}
                                        breakClassName={'break-me'}
                                        pageCount={paginationData.totalPages}
                                        marginPagesDisplayed={2}
                                        pageRangeDisplayed={5}
                                        onPageChange={handlePageClick}
                                        containerClassName={'pagination'}
                                        subContainerClassName={'pages pagination'}
                                        activeClassName={'active'}
                                        previousClassName={paginationData.currentPage === 1 ? 'disabled' : ''}
                                        nextClassName={paginationData.currentPage === paginationData.totalPages ? 'disabled' : ''}

                                    />
                                )}
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <Footer />


        </>
    )
}

export default CpnPatientAppointment
