import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import Logoimage from '../../../assests/images/ys.png'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import Sidebar from '../../common/Sidebar/Sidebar'
import ExpertSidebar from '../../common/ExpertSidebar/ExpertSidebar'
import CpnSidebar from '../../common/CpnSidebar/CpnSidebar'

const MessageDetails = () => {
  return (
    <>
    <div className='cpn-dashboard'>
        <LoginNavbar />
        <div className="container-fluid custom-container-fluid mb-5">
            <div className="parent-div">
               <CpnSidebar/>

                <div className="child-div" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                    <div className="expert-dashboard-para">
                        <p>Checkpoint NOW Health. We value your expertise and time.
                        </p>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <Footer />


</>
  )
}

export default MessageDetails
