import React, { useState, useEffect } from 'react'
import { Table } from 'reactstrap'
import { Link, useParams } from 'react-router-dom'
import { Progress, Form, FormGroup, Button } from 'reactstrap'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import Logoimage from '../../../assests/images/ys.png'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar';
import { useSelector, useDispatch } from 'react-redux';
import dayjs from "dayjs";
import CpnSidebar from '../../common/CpnSidebar/CpnSidebar'
import authenticationCpnIsServices from "../../../services/cpnIsServices";
import { toast } from "react-toastify";
import SpinnerLoader from '../../common/Spinner'
const NewAppointmentPatientDetails = () => {
    const [IsLoader, setIsLoader] = useState(false);
    const userData = useSelector((state) => state.user.cpnIsUser);
    const [PatientData, setPatientData] = useState({})
    const params = useParams()
    const { appointmentId } = params

    const getAppointmentDetailsByID = async (appointmentId) => {
        try {
            setIsLoader(true);
            let res = await authenticationCpnIsServices.getAppointmentDetailsByID(appointmentId);
            console.log("getAppointmentDetailsByID ===>>", res);
            if (res.data.status === 200) {
                const result = res.data?.data[0]
                setPatientData(result)
                setIsLoader(false);
                toast.success(res.data.message, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            } else {
                setIsLoader(false);
                toast.error(res.data.message, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        } catch (error) {
            toast.error(error, {
                position: toast.POSITION.TOP_RIGHT,
            });
        }
    }
    useEffect(() => {
        getAppointmentDetailsByID(appointmentId)
    }, [])
    // console.log("PatientData", PatientData);
    // const { demographicInformation: { age, height, weight, locatoin } = {}, patientData: [{ personalDetails: { name, dateOfBirth } = {} } = {}] } = PatientData || {};
    const { demographicInformation, patientData } = PatientData || {}; // Default to an empty object if PatientData is undefined

    let name, age, height, weight, locatoin, dateOfBirth;

    if (demographicInformation && patientData && patientData.length > 0) {
        const { personalDetails } = patientData[0];
        age = demographicInformation?.age;
        height = demographicInformation?.height;
        weight = demographicInformation?.weight;
        locatoin = demographicInformation?.locatoin;
        name = personalDetails?.name;
        dateOfBirth = personalDetails?.dateOfBirth;
    }
    return (
        <>
            {IsLoader && <SpinnerLoader />}
            <div className='cpn-new-appointment-profile-details'>
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className="parent-div">
                        <CpnSidebar />

                        <div className="child-div">
                            <div className="middle-contnet">
                                {/* Name row start */}
                                <div className="row g-0 py-2  border-bottom">
                                    <div className="col-sm-6 col-md-4">
                                        <h3 className='heading-profile'>Name</h3>

                                    </div>
                                    <div className="col-sm-2 col-md-6">
                                        <h4 className='heading-profile1'>{name}</h4>
                                    </div>
                                    <div className="line"></div>
                                </div>

                                {/* Age setcion start */}

                                <div className="row g-0 py-2  border-bottom">
                                    <div className="col-sm-6 col-md-4">
                                        <h3 className='heading-profile'>Age</h3>

                                    </div>
                                    <div className="col-sm-2 col-md-6">
                                        <h4 className='heading-profile1'>{age}</h4>
                                    </div>
                                    <div className="line"></div>
                                </div>
                                {/* Date of Birth */}
                                <div className="row g-0  py-2 border-bottom ">
                                    <div className="col-sm-6 col-md-4">
                                        <h3 className='heading-profile'>Date of Birth</h3>

                                    </div>
                                    <div className="col-sm-2 col-md-6">
                                        <h4 className='heading-profile1'>{dayjs(dateOfBirth).format('DD/MM/YYYY')}</h4>
                                        {/* <h4 className='heading-profile1'>12/01/2003</h4> */}
                                    </div>
                                    <div className="line"></div>
                                </div>
                                {/* Gender */}
                                <div className="row g-0  py-2 border-bottom ">
                                    <div className="col-sm-6 col-md-4">
                                        <h3 className='heading-profile'>Height</h3>

                                    </div>
                                    <div className="col-sm-2 col-md-6">
                                        <h4 className='heading-profile1'>{height}</h4>
                                    </div>
                                    <div className="line"></div>
                                </div>
                                {/* Email Address */}
                                <div className="row g-0  py-2 border-bottom">
                                    <div className="col-sm-6 col-md-4">
                                        <h3 className='heading-profile'>Weight</h3>

                                    </div>
                                    <div className="col-sm-2 col-md-6">
                                        <h4 className='heading-profile1'>{weight}</h4>
                                    </div>
                                    <div className="line"></div>
                                </div>
                                {/* Country */}
                                <div className="row g-0  py-2">
                                    <div className="col-sm-6 col-md-4">
                                        <h3 className='heading-profile'>Location</h3>

                                    </div>
                                    <div className="col-sm-2 col-md-6">
                                        <h4 className='heading-profile1'>{locatoin}</h4>
                                    </div>
                                </div>
                                {/* Button Start */}

                                <Link to={`/cpn-new-appointment-schedule/${appointmentId}`}>
                                    <Button className='custtom-button' type='submit'>Schedule Appointment</Button>
                                </Link>

                            </div>



                        </div>
                    </div>
                </div>
            </div>

            <Footer />


        </>
    )
}

export default NewAppointmentPatientDetails
