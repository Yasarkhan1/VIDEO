import React, { useEffect, useState } from 'react'
import { Table } from 'reactstrap'
import { Link } from 'react-router-dom'
import { Progress, Form, FormGroup, Button, Modal, ModalHeader, ModalBody, ModalFooter, Input, Row, Col } from 'reactstrap'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import Checkicon from "../../../assests/images/check-read-svgrepo-com.png"
import Logoimage from '../../../assests/images/ys.png'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar';
import { useSelector, useDispatch } from 'react-redux';
import dayjs from "dayjs";
import CpnSidebar from '../../common/CpnSidebar/CpnSidebar'



const CpnSureveyNotesList = () => {


    const [modal, setModal] = useState(false);
    const [open1, setOpen1] = useState(false);
    const surveyToggle = () => { setOpen1(!open1) };
    const toggle = () => { setModal(!modal) };



    return (
        <>
            <div className='cpn-survey-notes-list'>
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className="parent-div">
                        <CpnSidebar />

                        <div className="child-div">

                            <div className="container-table">

                                <table className="table table-bordered">
                                    <thead>
                                        <tr>

                                            <th scope="col">Patient Name</th>
                                            <th scope="col">Age</th>
                                            <th scope="col"> Sex</th>
                                            <th scope='col'>User Type</th>
                                            <th scope='col'>Appointment Date</th>
                                            <th scope='col'> Appointment Status</th>
                                            <th scope='col'>Appointment ID</th>
                                            <th scope='col'>Survey Status</th>
                                            <th scope='col'>Notes Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>

                                            <td>Ali Ahmad</td>
                                            <td>32</td>
                                            <td>M</td>
                                            <td>Patient</td>
                                            <td>11 July 23, 11:00pm</td>
                                            <td>Done</td>
                                            <td>MDKHJFL</td>
                                            <td><a href="#" >Pending</a></td>

                                            <td>.</td>

                                        </tr>
                                        <tr>
                                            <td>Shahnawaz</td>
                                            <td>32</td>
                                            <td>M</td>
                                            <td>Patient</td>
                                            <td>11 July 23, 11:00pm</td>
                                            <td>Done</td>
                                            <td>MDKHJFL</td>

                                            <td><a href="#" onClick={toggle}>Done</a></td>


                                            <td><a href="#" onClick={surveyToggle}>Done</a></td>

                                        </tr>
                                        <tr>
                                            <td>Saqlain</td>
                                            <td>32</td>
                                            <td>M</td>
                                            <td>Ec</td>
                                            <td>11 July 23, 11:00pm</td>
                                            <td>Done</td>
                                            <td>MDKHJFL</td>
                                            <td> <a href="#">Done</a></td>
                                            <td><a href="#">Done</a></td>

                                        </tr>
                                        <tr>
                                            <td>Usama</td>
                                            <td>32</td>
                                            <td>F</td>
                                            <td>Patient</td>
                                            <td>11 July 23, 11:00pm</td>
                                            <td>Done</td>
                                            <td>MDKHJFL</td>
                                            <td>Pending</td>
                                            <td>Done</td>

                                        </tr>
                                        <tr>
                                            <td>Shoeb</td>
                                            <td>32</td>
                                            <td>M</td>
                                            <td>Ec</td>
                                            <td>11 July 23, 11:00pm</td>
                                            <td>Done</td>
                                            <td>MDKHJFL</td>
                                            <td>Done</td>
                                            <td><a href="#">Done</a></td>

                                        </tr>
                                        <tr>
                                            <td>Akhtar</td>
                                            <td>32</td>
                                            <td>F</td>
                                            <td>Patient</td>
                                            <td>11 July 23, 11:00pm</td>
                                            <td>Done</td>
                                            <td>MDKHJFL</td>
                                            <td><a href="#">Pending</a></td>
                                            <td>Done</td>

                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <Footer />


            <div>
                <Modal isOpen={modal} toggle={toggle} centered>
                    <div className="modal-overlay">
                        <ModalHeader toggle={toggle}> Patient Survey </ModalHeader>
                        <ModalBody>

                            <div className="text-start statusBx w-100">
                                <Row style={{ padding: "0px 13%" }}>
                                    <Col md={6}>
                                        <h6 className='postcall'>Post-Call Survey</h6>
                                    </Col>
                                    <Col md={6}>
                                        <h6 className='complete'>Completed
                                            <img src={Checkicon} />
                                        </h6>
                                    </Col>
                                </Row>
                            </div>



                        </ModalBody>
                    </div>
                </Modal>
            </div>

            {/* Second Modal */}
            <div>
                <Modal isOpen={open1} toggle={surveyToggle} centered>
                    <div className="modal-overlay">
                        <ModalHeader toggle={surveyToggle}> Expert Consultant Notes </ModalHeader>
                        <ModalBody>
                            <div className="text-start statusBx w-100">
                                <Row style={{ marginLeft: "15px" }} >
                                    <Col md={4}>
                                        <h6 className='postcall1'>Post-Call Notes</h6>
                                    </Col>
                                    <Col md={3}>
                                        <h6 className='pending'>Pending</h6>
                                    </Col>
                                    <Col md={3} style={{ marginTop: "12px" }}>
                                        <button className='sendreminder'>Send Reminder</button>
                                    </Col>
                                </Row>
                            </div>

                            <div>
                                <Row>
                                    <h5 className='expertconsultant'>Expert Consultant Survey</h5>
                                    <hr />
                                </Row>


                            </div>
                            <div>
                                <Row style={{ padding: "0px 13%" }}>
                                    <Col md={6}>
                                        <h6 className='postcall2'>Post-Call Survey</h6>
                                    </Col>
                                    <Col md={6}>
                                        <h6 className='completed'>Completed
                                            <img src={Checkicon} />
                                        </h6>
                                    </Col>
                                </Row>
                            </div>



                        </ModalBody>
                    </div>
                </Modal>
            </div>

        </>
    )
}

export default CpnSureveyNotesList
