import React, { useState, useEffect } from 'react'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import CpnSidebar from '../../common/CpnSidebar/CpnSidebar'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import { Row, Modal, ModalHeader, ModalBody, ModalFooter, Input, Button, Col } from 'reactstrap'
import authenticationCpnIsServices from "../../../services/cpnIsServices";
import { toast } from "react-toastify";
import SpinnerLoader from '../../common/Spinner'

const CpnEcMessageView = () => {
    const navigate = useNavigate()
    const location = useLocation()
    const [IsLoader, setIsLoader] = useState(false);
    const [error, setError] = useState(false);
    const [message, setmessage] = useState('');
    const { state: { msgData, expertConsulatant, cpnId } = {} } = location
    console.log("location", location, msgData, expertConsulatant, cpnId)

    const onSubmit = async () => {
        if (message === '') {
            setError(true)
        } else {


            const payload = {
                "message": message,
                "expertConsulatant": expertConsulatant,
                "cpnId": cpnId
            }
            try {
                setIsLoader(true);
                let res = await authenticationCpnIsServices.sendMessageWithExpert(payload)
                if (res.data.status === 200) {
                    setIsLoader(false);
                    toast.success("Message send successfully", {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                    navigate("/cpn-ec-message")
                } else {
                    setIsLoader(false);
                    toast.error(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                }
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        }
    }

    useEffect(() => {
        if (message) {
            setError(false)
        }
    }, [message])
    return (
        <>
            {IsLoader && <SpinnerLoader />}
            <div className='cpn-message-view'>
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className="parent-div">
                        <CpnSidebar />
                        <div className="child-div">
                            <div className="all-content">
                                <Row className='text-detail-content'>

                                    <Col md={3}>

                                        <div className="text-patient-left">
                                            <h5>Expert</h5>
                                            <h6>(10/08/23, 11:30Am)</h6>
                                        </div>
                                    </Col>
                                    <Col md={6}>
                                        <div className="text-patient-right">
                                            <h6>I want to book appointment for cancer treatment asap.</h6>

                                        </div>
                                    </Col>

                                </Row>

                                <div className="reply-text-message text-center">
                                    <Col md={8} className="mx-auto">
                                        <Input
                                            type='textarea'
                                            placeholder='type here....'
                                            onChange={(e) => setmessage(e.target.value)}
                                            rows={6} />
                                        {error ? <small className="validation_error">Message is required</small> : null}
                                    </Col>


                                    <button className='submit' onClick={onSubmit}>Submit</button>


                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
            <Footer />
        </>
    )
}

export default CpnEcMessageView
