import React, { useState, useEffect } from 'react'
import { FormGroup, Input, Progress, Label, Button, Form } from 'reactstrap';
import tick from "../../../assests/images/check-circle-svgrepo-com (2).svg";
import blueTick from "../../../assests/images/blue-tick.svg";
import cpnLogo from "../../../assests/images/CPNHealthFINAL_fontembed.svg";
import Footer from '../../common/Footer/Footer';
import { useNavigate, Link } from 'react-router-dom';
import { useFormik } from "formik";
import * as Yup from "yup";
import { checkSpace, detectPlatform } from "../../../utils";
import authenticationCpnIsServices from "../../../services/cpnIsServices";
import { toast } from "react-toastify";
import { deviceToken } from "../../../getDeviceToken";
import SpinnerLoader from '../../common/Spinner';
const CpnSignUp3 = () => {

    const navigate = useNavigate()
    const [IsLoader, setIsLoader] = useState(false);
    const [acceptOther, setAcceptOther] = useState(false)
    const [acceptTnC, setAcceptTnC] = useState(false)
    const [acceptHippa, setAcceptHippa] = useState(false)

    const deviceType = detectPlatform()
    let devicetoken = "";
    deviceToken.subscribe((res) => {
        devicetoken = res;
    });

    const formik = useFormik({
        initialValues: {
            signAgreement: "",
        },
        validationSchema: Yup.object({
            signAgreement: Yup.string()
                .required("*sign agreement is required.")
                .min(3, "minimum three character are required."),
        }),

        onSubmit: async (values) => {
            const cpnIsSignupData = localStorage.getItem("cpnSignupData")
                ? JSON.parse(localStorage.getItem("cpnSignupData"))
                : "";
            if (!acceptHippa) {
                toast.error("Please accept HIPAA agreement", {
                    position: toast.POSITION.TOP_RIGHT,
                });
                return
            }
            else if (!acceptTnC) {
                toast.error("Please accept CPN agreement", {
                    position: toast.POSITION.TOP_RIGHT,
                });
                return
            }
            else if (!acceptOther) {
                toast.error("Please accept Other permission", {
                    position: toast.POSITION.TOP_RIGHT,
                });
                return
            } else {
                const payload = {
                    ...cpnIsSignupData,
                    signAgreement: values.signAgreement
                };

                try {
                    console.log("Final cpn signup payload=", payload);
                    const jsonData = payload
                    const formData = new FormData();
                    formData.append("email", jsonData.email);
                    formData.append("password", jsonData.password);
                    formData.append("name", jsonData.name);
                    formData.append("address", jsonData.address);
                    formData.append("contactNumber", jsonData.contactNumber);
                    formData.append("countryCode", jsonData.countryCode);
                    formData.append("signAgreement", jsonData.signAgreement);
                    formData.append("deviceType", deviceType);
                    formData.append("deviceToken", devicetoken);
                    formData.append("userDeviceToken", "dsafsafdsaasfdsfdsafdsafdsahjhasdkfjhdsakj");
                    setIsLoader(true);
                    let res = await authenticationCpnIsServices.cpnSignup(formData);
                    console.log("cpn login result==", res);
                    if (res.data.status === 200) {
                        localStorage.clear()
                        toast.success(res.data.message, {
                            position: toast.POSITION.TOP_RIGHT,
                        });
                        navigate("/login-as-cpn")
                    } else {
                        setIsLoader(false);
                        toast.error(res.data.message, {
                            position: toast.POSITION.TOP_RIGHT,
                        });
                    }
                } catch (error) {
                    toast.error(error, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                }
            }
        }
    });

    return (
        <>
            {IsLoader && <SpinnerLoader />}
            <div className='cpn-Sign-Up-3'>
                <div className="container">
                    <div className="logo-container">
                        <div className="logo-cpn">
                            <img src={cpnLogo} alt="Logo" />
                        </div>
                        <div className="login-button">
                            <Link to="/login-as-cpn">
                                <Button>
                                    Login
                                </Button>
                            </Link>
                        </div>
                    </div>
                    <div className="otp-input">

                        <Progress multi>
                            <Progress
                                bar
                                value="33.33"
                                style={{
                                    height: '5px'
                                }}
                            />
                            <Progress
                                bar
                                color="success"
                                value="33.33"

                            />
                            <Progress
                                bar
                                color="info"
                                value="33.33"

                            />
                        </Progress>
                    </div>
                    <div className="text-sign-up">
                        <h1>Sign Up as a CPN</h1>
                    </div>
                    <div className="text-sign-up-2">
                        <img src={tick} alt="" />
                        <h1> Sign legal document with information on HIPAA, Patient permission taken</h1>
                    </div>
                </div>
                <div className="container">
                    <div className="content-date">
                        <div className="login-detail mb-4">
                            <div className="login-detail-img">
                                <img src={tick} alt="" />
                                <h1> Login Details</h1>
                            </div>
                            <div className="login-detail-img2-data">
                                <img src={tick} alt="" />
                                <h1> Personal Details</h1>
                            </div>

                            <div className="login-detail-img2-data" style={{ opacity: '1' }}>
                                <img src={tick} alt="" />
                                <h1> Sign legal document with information on HIPAA, Patient permission taken</h1>

                            </div>
                        </div>

                        <div className="form-data-container">

                            <Form onSubmit={formik.handleSubmit}>
                                <h6 className='sign-line'>Please read and sign agreement before proceeding</h6>
                                <FormGroup check>
                                    <Input type="checkbox" onChange={(e) => setAcceptHippa(e.target.checked)} checked={acceptHippa} />
                                    {' '}
                                    <Label check>
                                        <Link to=""> HIPAA Agreement</Link>
                                    </Label>
                                </FormGroup>
                                <FormGroup check>
                                    <Input type="checkbox" onChange={(e) => setAcceptTnC(e.target.checked)} checked={acceptTnC} />
                                    {' '}
                                    <Label check>
                                        <Link to=""> CPN Agreement</Link>
                                    </Label>
                                </FormGroup>
                                <FormGroup check>
                                    <Input type="checkbox" onChange={(e) => setAcceptOther(e.target.checked)} checked={acceptOther} />
                                    {' '}
                                    <Label check>
                                        <Link to=""> Other Permission</Link>
                                    </Label>
                                </FormGroup>
                                <FormGroup>
                                    <div className="signagreement-c">
                                        <Label for="exampleAddress" className='exampleaddress'>
                                            Sign Agreement
                                        </Label>
                                        <Input
                                            id="exampleAddress"
                                            name="signAgreement"
                                            placeholder="Enter Full Name"
                                            type="text"
                                            {...formik.getFieldProps("signAgreement")}
                                            onKeyDown={checkSpace}
                                            className={formik.touched.signAgreement && formik.errors.signAgreement ? 'is-invalid' : ""}
                                        />
                                        {formik.touched.signAgreement && formik.errors.signAgreement ? <small className="validation_error">{formik.errors.signAgreement}</small> : null}

                                    </div>
                                </FormGroup>



                                <Button className='btn-secondry mb-4' type='submit'>
                                    Submit
                                </Button>
                            </Form>

                        </div>
                    </div>
                </div>

            </div>
            <Footer />
        </>
    )
}

export default CpnSignUp3
