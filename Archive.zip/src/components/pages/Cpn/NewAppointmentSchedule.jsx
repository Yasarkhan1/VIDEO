import React, { useState, useEffect, useRef } from 'react'
import { Input, Table } from 'reactstrap'
import { Link, useParams, useNavigate } from 'react-router-dom'
import { Progress, Form, FormGroup, Button, Label, Col, Row } from 'reactstrap'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import Logoimage from '../../../assests/images/ys.png'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar';
import { useSelector, useDispatch } from 'react-redux';
import dayjs from "dayjs";
import CpnSidebar from '../../common/CpnSidebar/CpnSidebar'
import { useFormik } from "formik";
import * as Yup from "yup";
import authenticationCpnIsServices from "../../../services/cpnIsServices";
import { toast } from "react-toastify";
import { ReactComponent as CrossIcon } from "../../../assests/images/close-circle-svgrepo-com.svg";
import SpinnerLoader from '../../common/Spinner'
const validationSchema = Yup.object().shape({
    // patientName: Yup.string().required("Patient Name is required"),
    // chiefConcern: Yup.string().required("Chief Concern is required"),
    // consultNeeded: Yup.string().required("Consultation Needed is required"),
    ConsultantId: Yup.string().required("Speciality Request is required"),
    // additionalInfo: Yup.string().required("Additional Information Request is required"),
    // attachment: Yup.mixed().required("Please attached document"),
    // scheduleAppointment: Yup.string().required("Schedule Appointment is required"),
});

const NewAppointmentSchedule = () => {
    const [IsLoader, setIsLoader] = useState(false);
    const userData = useSelector((state) => state.user.cpnIsUser);
    const navigate = useNavigate()
    const params = useParams()
    const [appointmentListData, setAppointmentListData] = useState([])
    const [AllExpert, setAllExpert] = useState([])
    const [ConsultantId, setConsultantId] = useState()
    const { appointmentId } = params
    const [profileImage, setProfileImage] = useState(null);
    const fileInputRef = useRef(null);
    console.log(appointmentId);

    const getAppointmentDetailsByID = async (appointmentId) => {
        try {
            setIsLoader(true);
            let res = await authenticationCpnIsServices.getAppointmentDetailsByID(appointmentId);
            console.log("getAppointmentDetailsByID ===>>", res);
            if (res.data.status === 200) {
                const result = res.data.data
                setAppointmentListData(result)
                setIsLoader(false);
                toast.success(res.data.message, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            } else {
                setIsLoader(false);
                toast.error(res.data.message, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        } catch (error) {
            toast.error(error, {
                position: toast.POSITION.TOP_RIGHT,
            });
        }
    }

    const getAllExpert = async () => {
        try {
            setIsLoader(true);
            let res = await authenticationCpnIsServices.getAllExpert();
            console.log("getAllExpert ===>>", res);
            if (res.data.status === 200) {
                const result = res.data.data.expertConsultant
                setAllExpert(result)
                setIsLoader(false);
                toast.success(res.data.message, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            } else {
                setIsLoader(false);
                toast.error(res.data.message, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        } catch (error) {
            toast.error(error, {
                position: toast.POSITION.TOP_RIGHT,
            });
        }
    }

    const getSlotById = async (EcId, date) => {
        try {
            setIsLoader(true);
            let res = await authenticationCpnIsServices.getSlotById(EcId, date);

            console.log("getSlotById ===>>", res);
            if (res.data.status === 200) {
                const result = res.data.data

                setIsLoader(false);
                toast.success(res.data.message, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            } else {
                setIsLoader(false);
                toast.error(res.data.message, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        } catch (error) {
            toast.error(error, {
                position: toast.POSITION.TOP_RIGHT,
            });
        }
    }

    useEffect(() => {
        getAllExpert()
        getAppointmentDetailsByID(appointmentId)
    }, [appointmentId])

    const formik = useFormik({
        initialValues: {
            patientName: "",
            chiefConcern: "",
            consultNeeded: "",
            ConsultantId: "",
            additionalInfo: "",
            attachment: null,
            scheduleAppointment: "",
        },
        validationSchema: validationSchema,
        onSubmit: async (values) => {
            // Handle form submission here
            try {
                console.log("values.ConsultantId", values.ConsultantId);
                const formData = new FormData();
                formData.append("expertConsulatant", "64ff01f763166250211da038");
                // formData.append("expertConsulatant", values.ConsultantId);
                // formData.append("expertConsulatant", ConsultantId);
                formData.append("addAdditionInformation", values.additionalInfo);
                formData.append("appointmentTime", "07:21 AM - 08:21 AM");
                formData.append("appointmentDate", "2023-08-28");
                formData.append("slotId", "1");
                formData.append("appointmentID", appointmentId);
                // formData.append("uploadDoc", "");
                setIsLoader(true);
                let res = await authenticationCpnIsServices.cpnSeheduleAppointment(formData);
                console.log(" schedule appointment result==", res);
                if (res.data.status === 200) {
                    navigate("/cpn-patient-appointment")
                    toast.success(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                } else {
                    setIsLoader(false);
                    toast.error(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                }
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        },
    });


    const handleImageChange = (e) => {
        const file = e.target.files[0];
        // console.log("image file==", file);
        setProfileImage(file);
    }

    const handleRemoveImage = () => {
        setProfileImage(null); // Remove the uploaded image by setting the state to null
        // Reset the file input value to clear the selected image
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
        }
    };
    console.log(formik.values.specialityRequest);

    return (
        <>
            {IsLoader && <SpinnerLoader />}
            <div className='cpn-new-appointment-schedule'>
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className="parent-div">
                        <CpnSidebar />

                        <div className="child-div">
                            <div className="form-groupes">
                                <Form onSubmit={formik.handleSubmit}>
                                    <Row>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label>Patient Name</Label>
                                                <Input
                                                    id='exampleText'
                                                    type='text'
                                                    // placeholder='Mohammad Zubair'
                                                    {...formik.getFieldProps("patientName")}
                                                />
                                                {formik.touched.patientName && formik.errors.patientName ? (
                                                    <div className="validation_error">{formik.errors.patientName}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label>Chief Concern</Label>
                                                <Input
                                                    id='exampleText'
                                                    type='text'
                                                    // placeholder='Stomach ache with server skin infection'
                                                    {...formik.getFieldProps("chiefConcern")}
                                                />
                                                {formik.touched.chiefConcern && formik.errors.chiefConcern ? (
                                                    <div className="validation_error">{formik.errors.chiefConcern}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>
                                    </Row>

                                    <Row>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label>How soon consult/video call needed</Label>
                                                <Input
                                                    id='exampleText'
                                                    type='text'
                                                    // placeholder='1 week'
                                                    {...formik.getFieldProps("consultNeeded")}
                                                />
                                                {formik.touched.consultNeeded && formik.errors.consultNeeded ? (
                                                    <div className="validation_error">{formik.errors.consultNeeded}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label>Speciality Request</Label>
                                                <Input
                                                    id='exampleSelect'
                                                    type='select'
                                                    // onChange={(e) => setConsultantId(e.target.value)}
                                                    {...formik.getFieldProps("ConsultantId")}
                                                >
                                                    <option value="">Select</option>
                                                    {AllExpert?.length ?
                                                        AllExpert?.map((item, ind) => (

                                                            <option value={item._id} key={item._id}>{item.employmentDetails.name} - {item.professionalDetails?.specialty} </option>
                                                        ))
                                                        : ""
                                                    }
                                                </Input>
                                                {formik.touched.ConsultantId && formik.errors.ConsultantId ? (
                                                    <div className="validation_error">{formik.errors.ConsultantId}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label>Additional Information</Label>
                                                <Input
                                                    id='exampletext'
                                                    type='text'
                                                    // placeholder='Type here....'
                                                    {...formik.getFieldProps("additionalInfo")}
                                                />
                                                {formik.touched.additionalInfo && formik.errors.additionalInfo ? (
                                                    <div className="validation_error">{formik.errors.additionalInfo}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label>Attache Document</Label>
                                                <input
                                                    type="file"
                                                    className="form-control"
                                                    id="imageUpload"
                                                    accept="image/*"
                                                    onChange={handleImageChange}
                                                    ref={fileInputRef}
                                                    style={{ height: '32px' }}
                                                />
                                                {profileImage && (
                                                    <div className="image-preview">
                                                        <img
                                                            src={URL.createObjectURL(profileImage)}
                                                            alt="Uploaded"
                                                            className="mt-3"
                                                        />
                                                        <span className="remove-icon" onClick={handleRemoveImage}>
                                                            <CrossIcon />
                                                        </span>
                                                    </div>

                                                )}
                                                {/* <Input
                                                    id='exampleFile'
                                                    type='file'
                                                    placeholder='upload'
                                                    onChange={handleImageChange}
                                                    ref={fileInputRef}
                                                    {...formik.getFieldProps("attachment")}
                                                />
                                                {formik.touched.attachment && formik.errors.attachment ? (
                                                    <div className="validation_error">{formik.errors.attachment}</div>
                                                ) : null} */}
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label>Schedule Appointment</Label>
                                                <Input
                                                    id='exampleSelect'
                                                    type='select'
                                                    {...formik.getFieldProps("scheduleAppointment")}
                                                >
                                                    <option value="">Select Time</option>
                                                    <option value="3">3</option>
                                                    <option value="2">2</option>
                                                    <option value="1">1</option>
                                                </Input>
                                                {formik.touched.scheduleAppointment && formik.errors.scheduleAppointment ? (
                                                    <div className="validation_error">{formik.errors.scheduleAppointment}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col md={6}>
                                            <Button className='submit-button' type='submit'>Submit</Button>
                                            {/* <Button className='submit-button' onClick={handleSubmit}>Submit</Button> */}
                                        </Col>
                                    </Row>
                                </Form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <Footer />
        </>
    )
}

export default NewAppointmentSchedule
