import React, { useState } from 'react'
import { Table } from 'reactstrap'
import { Link } from 'react-router-dom'
import { Progress, Form, FormGroup, Button, Modal, ModalHeader, ModalBody, ModalFooter, Input } from 'reactstrap'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import Logoimage from '../../../assests/images/ys.png'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import Sidebar from '../../common/Sidebar/Sidebar'

function PaymentInformation() {
    const [modal, setModal] = useState(false);
    const toggle = () => { setModal(!modal) };
    return (
        <>
            <div className='payment-information'>
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className="parent-div">
                        <Sidebar />
                        <div className="child-div">

                            <div class="body-content">
                                <div class="child-navabar">
                                    <h6>Payment Information</h6>
                                   <Link to={"/payment-method"}>
                                    <h6 style={{color:"#3A63B5"}}>Payment Method</h6> </Link>
                                </div>
                                
                            </div>
                            <div class="dot-line"></div>
                            <div className="container-table">
                                <table className="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">S.No.</th>
                                            <th scope="col">Date & Time</th>
                                            <th scope="col">Service</th>
                                            <th scope='col'>Charge</th>
                                            <th scope='col'>EC Name</th>
                                            <th scope='col'>Patient Name</th>
                                            <th scope='col'>Status</th>
                                            <th scope='col'>Payment</th>
                                            <th scope='col'>Action</th>
                                            <th scope='col'>Invoice</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row">1</th>
                                            <td>23 May 2023, 10:00AM</td>
                                            <td>Consultation</td>
                                            <td>$100</td>
                                            <td>Dr. Abdul Kareem</td>
                                            <td>Safiuddin</td>
                                            <td>Confirmed</td>
                                            <td>Pending </td>
                                            <td><a href='#' onClick={toggle} >Notes</a></td>
                                            <td>Download</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">2</th>
                                            <td>23 May 2023, 10:00AM</td>
                                            <td>Consultation</td>
                                            <td>$100</td>
                                            <td>Dr. Raziuddin Ahmad</td>
                                            <td>Furqan</td>
                                            <td>Completed</td>
                                            <td> Paid </td>
                                            <td><a href='#' onClick={toggle} >Notes</a></td>
                                            <td>Download</td>

                                        </tr>
                                        <tr>
                                            <th scope="row">3</th>
                                            <td>23 May 2023, 10:00AM</td>
                                            <td>Consultation</td>
                                            <td>$100</td>
                                            <td>Dr. Adbullah Nawaz</td>
                                            <td>Adbullah</td>
                                            <td>Canceled</td>
                                            <td> NA</td>
                                            <td><a href='#'>Notes</a></td>
                                            <td>Download</td>

                                        </tr>
                                        <tr>
                                            <th scope="row">4</th>
                                            <td>23 May 2023, 10:00AM</td>
                                            <td>Consultation</td>
                                            <td>$100</td>
                                            <td>Dr. Abdul Kareem</td>
                                            <td>Bilal</td>
                                            <td>Completed</td>
                                            <td> Pending</td>
                                            <td><a href='#'>Notes</a></td>
                                            <td>Download</td>

                                        </tr>
                                        <tr>
                                            <th scope="row">5</th>
                                            <td>23 May 2023, 10:00AM</td>
                                            <td>Consultation</td>
                                            <td>$100</td>
                                            <td>Dr. Raziuddin Ahmad</td>
                                            <td>Hamza</td>
                                            <td>Completed</td>
                                            <td> NA</td>
                                            <td><a href='#'>Notes</a></td>
                                            <td>Download</td>

                                        </tr>
                                        <tr>
                                            <th scope="row">6</th>
                                            <td>23 May 2023, 10:00AM</td>
                                            <td>Consultation</td>
                                            <td>$100</td>
                                            <td>Dr. Adbullah Nawaz</td>
                                            <td>Anwar</td>
                                            <td>Confirmed</td>
                                            <td> Paid</td>
                                            <td><a href='#'>Notes</a></td>
                                            <td>Download</td>

                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <Footer />
            {/* <div>
                <Modal isOpen={modal} toggle={toggle} className="filterModal" centered  >
                    <ModalHeader toggle={toggle}> Notes </ModalHeader>
                    <ModalBody>

                        <div className="text-start statusBx w-100" >
                            <FormGroup>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting
                                    industry. Lorem Ipsum has been the industry's standard dummy text
                                    ever since the 1500s, when an unknown printer took a galley of type
                                    and scrambled it to make a type specimen book.</p>

                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting
                                    industry. Lorem Ipsum has been the industry's standard dummy text
                                    ever since the 1500s, when an unknown printer took a galley of type
                                    and scrambled it to make a type specimen book.
                                </p>
                            </FormGroup>
                        </div>

                        <Button style={{
                    background: "#3A63B5 0% 0% no-repeat padding-box",
                    width: "100%"
                }} onClick={() => { toggle() }}>Submit</Button>

                    </ModalBody>
                </Modal>
            </div> */}

        </>
    )
}

export default PaymentInformation
