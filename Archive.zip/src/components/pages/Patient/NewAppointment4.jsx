import React, { useState, useEffect } from 'react';
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import Sidebar from '../../common/Sidebar/Sidebar'
import { FormGroup, Form, Button, Input, Label, Col, Row } from 'reactstrap'
import { Formik, useFormik } from 'formik'
import AppointNavbar from '../../common/AppointmentNavbar/AppointNavbar'
import Footer from '../../common/Footer/Footer'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import dayjs from "dayjs";
import authenticationServices from "../../../services";
import { useSelector } from 'react-redux';
import * as Yup from 'yup';
import { toast } from "react-toastify";
import SpinnerLoader from '../../common/Spinner'
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";

const usaFaxNumberRegex = /^(?:(?:\+1)|(?:1))?[ -]?\(?(\d{3})\)?[ -]?(\d{3})[ -]?(\d{4})$/;

const validationSchema = Yup.object().shape({
  // cancerTreatment: Yup.string().required('Cancer Treatment is required'),
  // treatmentDate: Yup.string().required('Treatment Date is required'),
  // providerName: Yup.string().required('Name of Provider is required'),
  // officeName: Yup.string().required('Office Name is required'),
  // phoneNumber: Yup.string().required('Phone Number is required'),
  // faxNumber: Yup.string().required('Fax Number is required'),
  // medicalHistoryDisease: Yup.string().required('Name of Disease is required'),
  // yearOfDiagnosis: Yup.string().required('Year of Diagnosis is required'),
  // currentStatus: Yup.string().required('Current Status is required'),
  // surgicalHistoryName: Yup.string().required('Name (Year of Diagnosis) is required'),
  // currentYesNo: Yup.string().required('Current (Yes/No) is required'),
});
function NewAppointment4() {
  const location = useLocation()
  const dropDownData = useSelector((state) => state.allDropDown.data);
  // console.log("dropDownData====+++", dropDownData);
  const navigate = useNavigate()
  const [IsLoader, setIsLoader] = useState(false);
  const [countryCode, setCountryCode] = useState('');
  const appointmentId = location?.state?.appointmentId
  const [contactNumber, setcontactNumber] = useState('');
  const [cancerFormData, setCancerFormData] = useState([
    // Initial form data, you can have as many objects as needed.
    {
      cancerTreatment: '',
      treatmentDate: '',
    },
  ]);


  const handleAddMore = () => {
    // setCancerFormData([...cancerFormData, { cancerTreatment: '', treatmentDate: '' }]);
    if (canAddMoreFields(cancerFormData)) {
      setCancerFormData([...cancerFormData, { cancerTreatment: '', treatmentDate: '' }]);
    } else {
      // Display an error message or alert to inform the user
      toast.warn("Please fill in both 'Cancer Treatment' and 'Treatment Date' before adding more fields.", {
        position: toast.POSITION.TOP_RIGHT,
      });
    }
  };

  const handleFieldChange = (index, field, value) => {
    const updatedcancerFormData = [...cancerFormData];
    updatedcancerFormData[index][field] = value;
    setCancerFormData(updatedcancerFormData);
  };

  const handleRemove = (index) => {
    const updatedcancerFormData = [...cancerFormData];
    updatedcancerFormData.splice(index, 1);
    setCancerFormData(updatedcancerFormData);
  };

  const canAddMoreFields = (data) => {
    return data.every((entry) => entry.cancerTreatment !== '' && entry.treatmentDate !== '');
  };
  // useEffect to redirect step 1 if previous form not submitted
  // useEffect(() => {
  //     if (appointmentId === '' || appointmentId === undefined) {
  //         navigate("/new-appointment-1")
  //     }
  // }, [appointmentId])

  const formik = useFormik({
    initialValues: {
      cancerTreatment: '',
      treatmentDate: '',
      providerName: '',
      officeName: '',
      phoneNumber: '',
      faxNumber: '',
      medicalHistoryDisease: '',
      yearOfDiagnosis: '',
      currentStatus: '',
      surgicalHistoryName: '',
      currentYesNo: '',
      clinicalTrialName: '',
    },
    validationSchema: validationSchema,
    onSubmit: async (values) => {
      // Handle form submission
      console.log(values);
      // navigate('/new-appointment-5')
      // const isValid = cancerFormData.every(
      //   (entry) => entry.cancerTreatment.trim() !== '' && entry.treatmentDate.trim() !== ''
      // );

      // if (!isValid) {
      //   alert('Please fill in both "Cancer Treatment" and "Treatment Date" for all entries before submitting.');
      //   return;
      // }
      const payload = {
        // "currentTreatment": [
        //   {
        //     "cancerTreatment": values.cancerTreatment,
        //     "treatmentDate": values.treatmentDate
        //   }
        // ],
        "cancerTreatment": cancerFormData,
        "nameOfProvider": values.providerName,
        "officename": values.officeName,
        "phone": contactNumber,
        "countryCode": countryCode,
        "fax": values.faxNumber,
        "clinicalTrialName": values.clinicalTrialName,
        "nameOfDisease": values.nameOfDisease,
        "medicalYearOfDiagnosis": values.yearOfDiagnosis,
        "medicalStatus": values.currentStatus,
        "surgicalName": values.surgicalHistoryName,
        "surgicalCurrent": values.currentYesNo,
        "appointmentId": appointmentId,
      }
      try {
        console.log("appointmentBook step 4 payload=", payload);

        setIsLoader(true);
        let res = await authenticationServices.appointmentBook(payload, 4);
        console.log("appointmentBook step 4 result==", res);
        if (res.data.status === 200) {
          const appointmentId = res.data.data.appointmentId
          setIsLoader(false);
          toast.success(res.data.message, {
            position: toast.POSITION.TOP_RIGHT,
          });
          // navigate("/")
          navigate("/new-appointment-5", { state: { appointmentId: appointmentId }, replace: true })
        } else {
          setIsLoader(false);
          toast.error(res.data.message, {
            position: toast.POSITION.TOP_RIGHT,
          });
        }
      } catch (error) {
        toast.error(error, {
          position: toast.POSITION.TOP_RIGHT,
        });
      }
    },
  });

  const handleMobileChange = (value, data) => {
    setCountryCode(data.dialCode)
    formik.setFieldValue("phoneNumber", value)
    let contactNumbernew = value.slice(data.dialCode.length)
    setcontactNumber(contactNumbernew)
  }
  return (
    <>
      <div className="new-appointment4">
        {IsLoader && <SpinnerLoader />}
        <LoginNavbar />
        <div className="container-fluid custom-container-fluid mb-5">
          <div className=" parent-div">
            <Sidebar />
            <div className=" child-div">
              <div className="child-navabar">
                <AppointNavbar />
              </div>

              <div className="form-groupes">
                <div className="header-heading">
                  <h1> Current Treatment</h1>
                </div>
                <Form onSubmit={formik.handleSubmit}>
                  <div className='cancer-from-data'>


                    {cancerFormData.map((data, index) => (
                      <Row key={index}>
                        <Col md={6}>
                          <FormGroup>
                            <Label>Cancer Treatment</Label>
                            <Input
                              type="text"
                              value={data.cancerTreatment}
                              onChange={(e) => handleFieldChange(index, 'cancerTreatment', e.target.value)}
                            />
                          </FormGroup>
                        </Col>
                        <Col md={4}>
                          <FormGroup>
                            <Label>Treatment Date</Label>
                            <Input
                              type="date"
                              value={data.treatmentDate}
                              onChange={(e) => handleFieldChange(index, 'treatmentDate', e.target.value)}
                              max={new Date().toISOString().split('T')[0]}
                              min="1980-01-01"
                            />
                          </FormGroup>
                        </Col>
                        <Col md={2}>
                          {index === cancerFormData.length - 1 && (
                            <div className="addmore" >
                              <Link onClick={handleAddMore}>
                                + Add More
                              </Link>
                            </div>
                          )}
                          {index !== cancerFormData.length - 1 && (
                            <div className="remove">
                              <Link onClick={() => handleRemove(index)} style={{ color: "#FF5733" }}>
                                - Remove
                              </Link>
                            </div>
                          )}
                        </Col>
                      </Row>
                    ))}
                  </div>
                  {/* <Row>
                    <Col md={6}>
                      <FormGroup>
                        <Label >
                          Cancer Treatment
                        </Label>
                        <Input
                          id="cancerTreatment"
                          type="text"
                          {...formik.getFieldProps('cancerTreatment')}
                        />
                        {formik.touched.cancerTreatment && formik.errors.cancerTreatment ? (
                          <div className="validation_error">{formik.errors.cancerTreatment}</div>
                        ) : null}

                      </FormGroup>
                    </Col>
                    <Col md={4}>
                      <FormGroup>
                        <Label>
                          Treatment Date
                        </Label>
                        <Input
                          id="treatmentDate"
                          name="treatmentDate"
                          placeholder="date placeholder"
                          max={new Date().toISOString().split('T')[0]}
                          min="1980-01-01"
                          type="date"
                          {...formik.getFieldProps("treatmentDate")}
                          className={formik.touched.treatmentDate && formik.errors.treatmentDate ? 'is-invalid' : ""}
                        />

                        {formik.errors.treatmentDate ? <small className='validation_error'>{formik.errors.treatmentDate}</small> : null}


                      </FormGroup>
                    </Col>
                    <Col md={2}>
                      <div className="addmore">
                        <Link href="#">+ Add More</Link>
                      </div>
                    </Col>
                  </Row> */}
                  {/* Second Row Start */}
                  <div className="header-heading">
                    <h1> Oncology Team</h1>
                  </div>
                  <Row>
                    <Col md={6}>
                      <FormGroup>
                        <Label >
                          Name of Provider
                        </Label>
                        <Input
                          id="providerName"
                          type="text"
                          {...formik.getFieldProps('providerName')}
                        />
                        {formik.touched.providerName && formik.errors.providerName ? (
                          <div className="validation_error">{formik.errors.providerName}</div>
                        ) : null}
                      </FormGroup>
                    </Col>
                    <Col md={6}>
                      <FormGroup>
                        <Label >
                          Office Name
                        </Label>
                        <Input
                          id="officeName"
                          type="text"
                          {...formik.getFieldProps('officeName')}
                        />
                        {formik.touched.officeName && formik.errors.officeName ? (
                          <div className="validation_error">{formik.errors.officeName}</div>
                        ) : null}
                      </FormGroup>

                    </Col>
                  </Row>
                  {/* Third Row Start */}
                  <Row>
                    <Col md={6}>
                      <FormGroup>
                        <Label >
                          Phone Number
                        </Label>
                        <PhoneInput
                          country="us"
                          preferredCountries={["us"]}
                          placeholder="Type your contact number here"
                          value={formik.values.phoneNumber}
                          onBlur={formik.handleBlur}
                          // onChange={(value) => formik.setFieldValue("phoneNumber", value)}
                          onChange={handleMobileChange}
                          enableSearch={true}
                          // {...formik.getFieldProps("phoneNumber")}
                          inputStyle={{ width: "100%" }}
                          inputClass={formik.touched.phoneNumber && formik.errors.phoneNumber ? " is-invalid" : ""}
                          inputProps={{ name: "phoneNumber" }}
                        />
                        {formik.touched.phoneNumber && formik.errors.phoneNumber ? <small className="validation_error">{formik.errors.phoneNumber}</small> : null}
                      </FormGroup>
                    </Col>
                    <Col md={6}>
                      <FormGroup>
                        <Label >
                          Fax Number
                        </Label>
                        <Input
                          id="faxNumber"
                          type="text"
                          {...formik.getFieldProps('faxNumber')}
                          onBlur={(e) => {
                            const isValidFaxNumber = usaFaxNumberRegex.test(e.target.value);
                            if (!isValidFaxNumber) {
                              // Handle validation error, e.g. set an error message or show an alert
                            }
                            // Continue handling onBlur event as needed
                          }}
                        />

                        {formik.touched.faxNumber && formik.errors.faxNumber ? (
                          <div className="validation_error">{formik.errors.faxNumber}</div>
                        ) : null}
                      </FormGroup>
                    </Col>

                  </Row>
                  <Row>
                    <Col md={6}>
                      <FormGroup>
                        <Label>Clinical Trail name (If any)</Label>
                        <Input
                          id="clinicalTrialName"
                          type="text"
                          {...formik.getFieldProps('clinicalTrialName')}
                        />
                        {formik.touched.clinicalTrialName && formik.errors.clinicalTrialName ? (
                          <div className="validation_error">{formik.errors.clinicalTrialName}</div>
                        ) : null}
                      </FormGroup>
                    </Col>
                  </Row>
                  {/* Second Last Div */}
                  <div className="header-heading-past">
                    <h1>Medical History</h1>
                  </div>
                  <Row>
                    <Col md={6}>
                      <FormGroup>
                        <Label >
                          Name of Disease
                        </Label>
                        <Input
                          id="medicalHistoryDisease"
                          type="text"
                          {...formik.getFieldProps('medicalHistoryDisease')}
                        />
                        {formik.touched.medicalHistoryDisease && formik.errors.medicalHistoryDisease ? (
                          <div className="validation_error">{formik.errors.medicalHistoryDisease}</div>
                        ) : null}
                      </FormGroup>
                    </Col>
                    <Col md={6}>
                      <FormGroup>
                        <Label >
                          Year of Diagnosis
                        </Label>
                        <Input
                          id="yearOfDiagnosis"
                          type="select"
                          {...formik.getFieldProps('yearOfDiagnosis')}
                        >
                          <option value="">Select</option>
                          {dropDownData?.year.length ?
                            dropDownData?.year.map((item, ind) => (

                              <option value={item.value} key={ind}>{item.label}</option>
                            ))
                            : ""
                          }
                        </Input>
                        {formik.touched.yearOfDiagnosis && formik.errors.yearOfDiagnosis ? (
                          <div className="validation_error">{formik.errors.yearOfDiagnosis}</div>
                        ) : null}

                      </FormGroup>
                    </Col>

                  </Row>
                  {/* Second Row Start */}
                  <Row>
                    <Col md={6}>
                      <FormGroup>
                        <Label >
                          Current Status
                        </Label>
                        <Input
                          id="currentStatus"
                          type="text"
                          {...formik.getFieldProps('currentStatus')}
                        />
                        {formik.touched.currentStatus && formik.errors.currentStatus ? (
                          <div className="validation_error">{formik.errors.currentStatus}</div>
                        ) : null}

                      </FormGroup>
                    </Col>
                  </Row>
                  {/* Third Row Start */}
                  <div className="header-heading-past">
                    <h1>Surgical History</h1>
                  </div>
                  <Row>
                    <Col md={6}>
                      <FormGroup>
                        <Label >
                          Name (Year of Diagnosis)
                        </Label>
                        <Input
                          id="surgicalHistoryName"
                          type="text"
                          {...formik.getFieldProps('surgicalHistoryName')}
                        />
                        {formik.touched.surgicalHistoryName && formik.errors.surgicalHistoryName ? (
                          <div className="validation_error">{formik.errors.surgicalHistoryName}</div>
                        ) : null}

                      </FormGroup>
                    </Col>
                    <Col md={6}>
                      <FormGroup>
                        <Label >
                          Current (Yes/No)
                        </Label>
                        <Input
                          id="currentYesNo"
                          type="select"
                          {...formik.getFieldProps('currentYesNo')}
                        >
                          <option value="">Select</option>
                          <option value="Yes">Yes</option>
                          <option value="No">No</option>
                        </Input>
                        {formik.touched.currentYesNo && formik.errors.currentYesNo ? (
                          <div className="validation_error">{formik.errors.currentYesNo}</div>
                        ) : null}
                      </FormGroup>
                    </Col>

                  </Row>


                  <div className='button-container'>
                    {/* <Link to={'/new-appointment-5'}> */}
                    <Button color="primary" className='next-button'>
                      Next
                    </Button>
                    {/* </Link> */}

                  </div>
                </Form>
              </div>

            </div>
          </div>
        </div>
      </div>
      <Footer />

    </>
  )
}

export default NewAppointment4
