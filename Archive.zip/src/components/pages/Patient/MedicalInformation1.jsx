import React, { useState, useEffect } from 'react'
import { Input, Table } from 'reactstrap'
import { useNavigate, Link } from 'react-router-dom'
import { Progress, Form, FormGroup, Button, Label } from 'reactstrap'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import Logoimage from '../../../assests/images/ys.png'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import { useFormik } from 'formik'
import * as Yup from "yup";
import { toast } from "react-toastify";
import { checkSpace } from "../../../utils";
import Sidebar from '../../common/Sidebar/Sidebar'




function MedicalInformation1() {
    const navigate = useNavigate();

    useEffect(() => {
        const medicalStepData = localStorage.getItem("medicalStepData")
            ? JSON.parse(localStorage.getItem("medicalStepData"))
            : "";
        if (medicalStepData && Object.keys(medicalStepData)?.length && medicalStepData.hasOwnProperty('medicalInformation')) {
            getPatchform();
        }
    }, [])

    //    fill the data
    const getPatchform = () => {
        const medicalStepData = localStorage.getItem("medicalStepData")
            ? JSON.parse(localStorage.getItem("medicalStepData"))
            : "";
        if (medicalStepData && Object.keys(medicalStepData)?.length && medicalStepData.hasOwnProperty('medicalInformation')) {
            const { medicalInformation: { expert_you_need, seen_within_week, main_concern_today } } = medicalStepData
            if (expert_you_need && seen_within_week && main_concern_today) {
                formik.setValues({
                    expert_you_need: expert_you_need,
                    seen_within_week: seen_within_week,
                    main_concern_today: main_concern_today,
                });

            }
        }
    };
    const medicalStepData = localStorage.getItem('medicalStepData');
    // console.log(medicalStepData);
    const validationSchema = Yup.object().shape({
        expert_you_need: Yup.string().required('Please select your need.'),
        seen_within_week: Yup.string().required('Please select.'),
        main_concern_today: Yup.string().required("Please fill the feedback"),
    });
    const formik = useFormik({
        initialValues: {
            expert_you_need: '',
            seen_within_week: '',
            main_concern_today: '',

        },
        validationSchema: validationSchema,

        onSubmit: async (values) => {
            const step1Data = localStorage.getItem("medicalStepData")
                ? JSON.parse(localStorage.getItem("medicalStepData"))
                : "";


            const payload = {
                ...step1Data,
                medicalInformation: {
                    ...values,
                    seen_within_week: Number(values.seen_within_week)
                }

            };


            try {
                console.log("medicalStepData payload=", payload);
                localStorage.setItem("medicalStepData", JSON.stringify(payload));
                navigate("/medical-information2")
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        }

    });


    return (
        <>
            <div className='medical-information'>
                <LoginNavbar />
                <div className="container mb-5">
                    <div className="parent-div">
                        <Sidebar />



                        <div className="child-div">

                            <Form onSubmit={formik.handleSubmit}>

                                <FormGroup>
                                    <Label for="examplePassword">
                                        What expert do you need?
                                    </Label>
                                    <Input
                                        id="exampleSelect"
                                        name="expert_you_need"
                                        type="select"
                                        placeholder='Selector'
                                        {...formik.getFieldProps("expert_you_need")}
                                        onKeyDown={checkSpace}
                                        className={formik.touched.expert_you_need && formik.errors.expert_you_need ? 'is-invalid' : ""}
                                    >
                                        <option>Select Expert</option>
                                        <option>Dr.Faizan</option>
                                        <option>Dr.Frahan</option>
                                        <option>Dr.Shams</option>
                                        <option>Dr.Akib</option>

                                    </Input>
                                    {formik.touched.expert_you_need && formik.errors.expert_you_need ? <small className="validation_error">{formik.errors.expert_you_need}</small> : null}
                                </FormGroup>
                                <FormGroup>
                                    <Label for="examplePassword">
                                        How soon do you need to be seen?
                                    </Label>
                                    <Input
                                        id="exampleSelect"
                                        name="seen_within_week"
                                        type="select"
                                        {...formik.getFieldProps("seen_within_week")}
                                        onKeyDown={checkSpace}
                                        className={formik.touched.seen_within_week && formik.errors.seen_within_week ? 'is-invalid' : ""}
                                    >
                                        <option>Select Weeks</option>
                                        <option>1</option>
                                        <option>2</option>
                                        <option>3</option>

                                    </Input>
                                    {formik.touched.seen_within_week && formik.errors.seen_within_week ? <small className="validation_error">{formik.errors.seen_within_week}</small> : null}
                                </FormGroup>
                                <FormGroup>
                                    <Label for="examplePassword" className='text-area'>
                                        What is your main concern today? <span>(Word Limit  100 Characters)</span>
                                    </Label>
                                    <Input

                                        name="main_concern_today"
                                        type="textarea"
                                        placeholder='type here...'
                                        rows={3}
                                        {...formik.getFieldProps("main_concern_today")}
                                        onKeyDown={checkSpace}
                                        className={formik.touched.main_concern_today && formik.errors.main_concern_today ? 'is-invalid' : ""}
                                    />
                                    {formik.touched.main_concern_today && formik.errors.main_concern_today ? <small className="validation_error">{formik.errors.main_concern_today}</small> : null}


                                </FormGroup>
                                <Button className='btn-secondry' type="submit">
                                    Next
                                </Button>
                            </Form>
                        </div>
                    </div>
                </div>
            </div>

            <Footer />


        </>
    )
}

export default MedicalInformation1
