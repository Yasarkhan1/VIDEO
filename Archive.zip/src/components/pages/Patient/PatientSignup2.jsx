import React, { useState, useEffect, useRef } from 'react'
import { FormGroup, Input, Label, Form, FormText, Button, Progress, Row, Col } from 'reactstrap';
import tick from "../../../assests/images/check-circle-svgrepo-com (2).svg";
import blueTick from "../../../assests/images/blue-tick.svg";
import cpnLogo from "../../../assests/images/CPNHealthFINAL_fontembed.svg";
import { ReactComponent as CrossIcon } from "../../../assests/images/close-circle-svgrepo-com.svg";
import calenderImg from "../../../assests/images/calender-svgrepo-com.svg";
import Footer from '../../common/Footer/Footer';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { useNavigate, Link } from 'react-router-dom';
import { useFormik } from "formik";
import * as Yup from "yup";
import { checkSpace } from "../../../utils";
import dayjs from "dayjs";
import { toast } from "react-toastify";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import e from 'cors';
import { async } from 'q';
import authenticationServices from "../../../services";

const PatientSignup2 = () => {

    const fileInputRef = useRef(null);
    const navigate = useNavigate()
    const [IsLoader, setIsLoader] = useState(false);
    const [countryData, setCountryData] = useState([])
    const [profileImage, setProfileImage] = useState(null);
    const [gender, setGender] = useState("")
    const [aggrementData, setAggrementData] = useState({})
    const [selectedCountryId, setSelectedCountryId] = useState('');
    const [selectedCountryName, setSelectedCountryName] = useState('');
    const [countryCode, setCountryCode] = useState('');
    const [contactNumber, setcontactNumber] = useState('');
    const handleGanderChange = (e) => {
        const { name, value } = e.target;
        setGender(value);
        formik.setFieldValue("gender", value)
        formik.setFieldTouched("gender", false)

    }

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        // console.log("image file==", file);
        setProfileImage(file);
    }

    const getAllcountryApi = async () => {
        try {
            let res = await authenticationServices.getAllcountry();
            console.log("getCountry==", res);
            if (res.data.status === 200) {
                setCountryData(res.data.countries)
            }
        } catch (error) {
            toast.error(error, {
                position: toast.POSITION.TOP_RIGHT,
            });
        }
    }

    const getAggrementApi = async (countryId) => {
        const payload = {
            "countryId": countryId
        }
        console.log("payload", payload);
        try {
            let res = await authenticationServices.getAggrement(payload);
            // console.log("getAggrementApi==", res);
            if (res.data.status === 200) {
                setAggrementData(res.data.agreements[0])
            }
        } catch (error) {
            toast.error(error, {
                position: toast.POSITION.TOP_RIGHT,
            });
        }
    }

    useEffect(() => {
        const step1Data = localStorage.getItem("patientSignupData")
            ? JSON.parse(localStorage.getItem("patientSignupData"))
            : "";
        const { email, password } = step1Data
        if (!email || !password) {
            navigate('/signup-as-patient-1')
        } else {
            getPatchform();
            getAllcountryApi()
        }
    }, [])
    // fill data in fields after back.
    const getPatchform = () => {
        const step2Data = localStorage.getItem("patientSignupData")
            ? JSON.parse(localStorage.getItem("patientSignupData"))
            : "";
        console.log("step2Data++++", step2Data);
        const { name, dateOfBirth, sex, address, contactNumber, selectedCountryId } = step2Data
        const dateString = dayjs(dateOfBirth).format('YYYY-MM-DD');
        // console.log("Date: ", dateString);
        if (name && dateOfBirth) {
            formik.setValues({
                name: name,
                dateOfBirth: dateString,
                gender: sex,
                address: address,
                mobileNumber: countryCode + contactNumber,
                // country: selectedCountryId,
            });
            // console.log("dateOfBirth==", new Date(dateOfBirth).toString());
            // setDob(dateOfBirth)

            setSelectedCountryId(selectedCountryId)
            setGender(sex)
        }
    };

    const formik = useFormik({
        initialValues: {
            name: "",
            dateOfBirth: "",
            gender: "",
            address: "",
            mobileNumber: "",
            country: "",
        },
        validationSchema: Yup.object({
            name: Yup.string()
                .required("*First name is required.")
                .min(3, "minimum three character are required."),
            dateOfBirth: Yup.string()
                .required("*Date Of birth is required."),
            gender: Yup.string()
                .required("*Gender is required."),
            address: Yup.string()
                .required("*Address is required.")
                .min(5, "minimum five character are required."),
            mobileNumber: Yup.string()
                .required("*Contact number is required."),
            // .matches(
            //     /^[6-9]{1}[0-9]{9}$/,
            //     "Enter valid contact number"
            // ),
            country: Yup.string()
                .required("*Country is required."),
        }),

        onSubmit: async (values) => {
            const step1Data = localStorage.getItem("patientSignupData")
                ? JSON.parse(localStorage.getItem("patientSignupData"))
                : "";
            const { email, password } = step1Data

            // if (!profileImage) {
            //     toast.warn("Please upload a profile image.", {
            //         position: toast.POSITION.TOP_RIGHT,
            //     });
            //     return; // Prevent form submission
            // }
            const payload = {
                email: email,
                password: password,
                name: values.name,
                dateOfBirth: dayjs(values.dateOfBirth).format('YYYY-MM-DD'),
                sex: values.gender,
                address: values.address,
                contactNumber: contactNumber,
                selectedCountryId: values.country,
                country: selectedCountryName,
                image: profileImage,
                hipaaAgreement: [{
                    "key": aggrementData?.name,
                    "_id": aggrementData?._id,
                    "status": true
                }],
                countryCode: "+" + countryCode
            };
            console.log("signup 2 payload+++", payload);

            try {
                // console.log("patient details payload=", payload, JSON.stringify(payload));
                localStorage.setItem("patientSignupData", JSON.stringify(payload));
                navigate("/signup-as-patient-3", { state: { step2Payload: payload } })
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        }
    });


    useEffect(() => {
        // Make your API call using selectedCountryId

        if (selectedCountryId && countryData.length) {
            getAggrementApi(selectedCountryId)
            console.log("countryData==", countryData);
            formik.setFieldValue("country", selectedCountryId)
            const countryName = countryData?.find(x => x._id === selectedCountryId)
            if (countryName && Object.keys(countryName)?.length) {
                console.log("countryName?.name==", countryName, countryName?.name);

                setSelectedCountryName(countryName?.name)
            }
        }

    }, [selectedCountryId, countryData]);


    const handleMobileChange = (value, data) => {
        setCountryCode(data.dialCode)
        formik.setFieldValue("mobileNumber", value)
        let contactNumbernew = value.slice(data.dialCode.length)
        setcontactNumber(contactNumbernew)
    }

    const handleRemoveImage = () => {
        setProfileImage(null); // Remove the uploaded image by setting the state to null
        // Reset the file input value to clear the selected image
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
        }
    };
    return (
        <>
       
        <div className='patient-login-details-2'>
            <div className="container">
                <div className="logo-container">
                    <div className="logo-cpn">
                        <Link to="/login-as-patient">
                            <img src={cpnLogo} alt="Logo" />
                        </Link>
                    </div>
                    <div className="login-button">
                        <Link to="/login-as-patient">
                            <Button>
                                Login
                            </Button>
                        </Link>
                    </div>
                </div>
                <div className="otp-input">

                    <Progress multi>
                        <Progress
                            bar
                            value="33.33"
                            style={{
                                height: '5px'
                            }}
                        />
                        <Progress
                            bar
                            color="success"
                            value="33.33"

                        />
                        <Progress
                            bar
                            color="info"
                            value="33.33"

                        />
                    </Progress>
                </div>
                <div className="text-sign-up">
                    <h1>Sign Up as a Patient</h1>
                </div>

                {/* mobile view */}
                
                <div className="text-sign-up-2">
                            <img src={tick} alt="" />
                            <h1>Personal Details</h1>
                        </div>
            </div>
            <div className="container">
                <div className="content-date">
                    <div className="login-detail">
                        <div className="login-detail-img">
                            <img src={tick} alt="" />
                            <h1>Login Details</h1>
                        </div>
                        
                        <div className="login-detail-img2-data">
                            <img src={tick} alt="" />
                            <h1>Personal Details</h1>
                        </div>
                        <div className="login-detail-img3-data">
                            <img src={tick} alt="" />
                            <h1>Sign HiPAA Agreement, CPN Agreement</h1>
                        </div>
                    </div>
                    <div className="form-data-container">
                        <Form onSubmit={formik.handleSubmit}>
                            <FormGroup>
                                <Label for="exampleFullname">
                                    Full Name
                                </Label>
                                <Input
                                    name="name"
                                    placeholder="Enter Patient Name"
                                    type="text"
                                    {...formik.getFieldProps("name")}
                                    onKeyDown={checkSpace}
                                    className={formik.touched.name && formik.errors.name ? 'is-invalid' : ""}
                                />
                                {formik.touched.name && formik.errors.name ? <small className="validation_error">{formik.errors.name}</small> : null}
                            </FormGroup>
                            <FormGroup className='dob-select'>
                                <Label for="exampleDate">
                                    Date of Birth
                                </Label>
                                <Input
                                    id="dateOfBirth"
                                    name="dateOfBirth"
                                    placeholder="Enter Dob"
                                    max={new Date().toISOString().split('T')[0]}
                                    min="1980-01-01"
                                    type="date"
                                    {...formik.getFieldProps("dateOfBirth")}
                                    className={formik.touched.dateOfBirth && formik.errors.dateOfBirth ? 'is-invalid form-control' : "form-control"}
                                />
                                {/* <DatePicker
                                    selected={dob}
                                    placeholderText="Enter Dob"
                                    dateFormat="dd/MM/yyyy"
                                    showIcon={true}
                                    // required
                                    maxDate={new Date()}
                                    showYearDropdown={true}
                                    isClearable={dob}
                                    // className="form-control"
                                    name="startDate"
                                    {...formik.getFieldProps("dateOfBirth")}
                                    // withPortal
                                    className={formik.touched.dateOfBirth && formik.errors.dateOfBirth ? 'is-invalid form-control' : "form-control"}
                                    onChange={(date) => { setDob(date); formik.setFieldValue("dateOfBirth", date) }} //only when value has changed
                                /> */}
                                {formik.touched.dateOfBirth && formik.errors.dateOfBirth ? <small className="validation_error">{formik.errors.dateOfBirth}</small> : null}
                            </FormGroup>

                            <FormGroup {...formik.getFieldProps("gender")}>
                                <div className='gender-radiotype' >
                                    <span>Gender</span>

                                    <FormGroup check>
                                        <Input
                                            name="gander"
                                            type="radio"
                                            value="Male"
                                            onChange={handleGanderChange}
                                            checked={gender == "Male"}
                                        />
                                        {' '}
                                        <Label check>
                                            Male
                                        </Label>
                                    </FormGroup>
                                    <FormGroup check>
                                        <Input
                                            name="gander"
                                            type="radio"
                                            value="Female"
                                            onChange={handleGanderChange}
                                            checked={gender == "Female"}
                                        />
                                        {' '}
                                        <Label check>
                                            Female
                                        </Label>
                                    </FormGroup>
                                    <FormGroup check>
                                        <Input
                                            name="gander"
                                            type="radio"
                                            value="ntos"
                                            onChange={handleGanderChange}
                                            checked={gender == "ntos"}
                                        />
                                        {' '}
                                        <Label check>
                                            Prefer not to say
                                        </Label>
                                    </FormGroup>
                                </div>
                                {formik.touched.gender && formik.errors.gender ? <small className="validation_error">{formik.errors.gender}</small> : null}
                            </FormGroup>
                            <FormGroup>
                                <Label for='exampleAddress'>
                                    Address
                                </Label>
                                <Input
                                    id='exampleAddress'
                                    name='Address'
                                    placeholder='Enter Your Address'
                                    {...formik.getFieldProps("address")}
                                    onKeyDown={checkSpace}
                                    type='text'
                                    className={formik.touched.address && formik.errors.address ? 'is-invalid' : ""}
                                />
                                {formik.touched.address && formik.errors.address ? <small className="validation_error">{formik.errors.address}</small> : null}
                            </FormGroup>
                            <FormGroup>
                                <Label for=''>
                                    Contact Number
                                </Label>
                                <PhoneInput
                                    country="us"
                                    preferredCountries={["us"]}
                                    placeholder="Type your contact number here"
                                    value={formik.values.mobileNumber}
                                    onBlur={formik.handleBlur}
                                    // onChange={(value) => formik.setFieldValue("mobileNumber", value)}
                                    onChange={handleMobileChange}
                                    enableSearch={true}
                                    // {...formik.getFieldProps("mobileNumber")}
                                    inputStyle={{ width: "100%" }}
                                    inputClass={formik.touched.mobileNumber && formik.errors.mobileNumber ? " is-invalid" : ""}
                                    inputProps={{ name: "mobileNumber" }}
                                />
                                {formik.touched.mobileNumber && formik.errors.mobileNumber ? <small className="validation_error">{formik.errors.mobileNumber}</small> : null}
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleSelect">Country</Label>
                                <Input
                                    id="exampleSelect"
                                    name="country"
                                    type="select"
                                    // {...formik.getFieldProps("country")}
                                    value={formik.values.country}
                                    onChange={(e) => {
                                        const selectedId = e.target.value;
                                        setSelectedCountryId(selectedId); // Update the selected country ID
                                        formik.handleChange(e); // Update Formik's state
                                    }}
                                    onBlur={formik.handleBlur}

                                    className={formik.touched.country && formik.errors.country ? 'is-invalid' : ""}

                                >
                                    <option value="">Select Country</option>
                                    {
                                        countryData?.length ? countryData?.map((item, index) => (
                                            <option value={item?._id} key={index

                                            }>{item?.name}</option>
                                        ))
                                            : null
                                    }
                                    {/* <option value="india">INDIA</option>
                                    <option>USA</option>
                                    <option>UAE</option>
                                    <option>US</option> */}

                                </Input>
                                {formik.touched.country && formik.errors.country ? <small className="validation_error">{formik.errors.country}</small> : null}
                            </FormGroup>

                            <Row>
                                <Col md={4}>
                                    <FormGroup>
                                        <label htmlFor="imageUpload" className="form-label">
                                            Upload Image
                                        </label>
                                    </FormGroup>
                                </Col>
                                <Col md={8}>
                                    <FormGroup>
                                        <input
                                            type="file"
                                            className="form-control"
                                            id="imageUpload"
                                            accept="image/*"
                                            onChange={handleImageChange}
                                            ref={fileInputRef}
                                            style={{ height: '32px' }}
                                        />
                                        {profileImage && (
                                            <div className="image-preview">
                                                <img
                                                    src={URL.createObjectURL(profileImage)}
                                                    alt="Uploaded"
                                                    className="mt-3"
                                                />
                                                <span className="remove-icon" onClick={handleRemoveImage}>
                                                    <CrossIcon />
                                                </span>
                                            </div>

                                        )}
                                    </FormGroup>
                                </Col>
                            </Row>

                            <Button className='btn-secondry' type='submit'>
                                Next
                            </Button>
                        </Form>
                        <br />
                        <div className="last-form-content mb-4">
                            <Link to="/signup-as-patient-1"><h3>Go to Back</h3></Link>
                        </div>
                    </div>
                </div>
            </div>
           
        </div>
        <Footer />
        </>
    )
}

export default PatientSignup2