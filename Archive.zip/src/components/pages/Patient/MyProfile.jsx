import React, { useState } from 'react'
import { Table } from 'reactstrap'
import { Link } from 'react-router-dom'
import { Progress, Form, FormGroup, Button } from 'reactstrap'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import Logoimage from '../../../assests/images/ys.png'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar';
import { useSelector, useDispatch } from 'react-redux';
import dayjs from "dayjs";
import Sidebar from '../../common/Sidebar/Sidebar'
function MyProfile() {
    const [IsLoader, setIsLoader] = useState(false);
    const userData = useSelector((state) => state.user.data);
    // console.log("userData++>>", userData);
    return (
        <>

            <div className='my-profile'>
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className="parent-div">
                        <Sidebar />

                        <div className="child-div">
                            <div className="middle-contnet">
                                <div className="row g-0 py-2  border-bottom">
                                    <div className="col-sm-6 col-md-4">
                                        <h3 className='heading-profile'>Name</h3>

                                    </div>
                                    <div className="col-sm-2 col-md-6">
                                        <h4 className='heading-profile1'>{userData?.personalDetails?.name}</h4>
                                    </div>
                                    <div className="line"></div>
                                </div>
                                {/* Date of Birth */}
                                <div className="row g-0  py-2 border-bottom ">
                                    <div className="col-sm-6 col-md-4">
                                        <h3 className='heading-profile'>Date of Birth</h3>

                                    </div>
                                    <div className="col-sm-2 col-md-6">
                                        <h4 className='heading-profile1'>{dayjs(userData?.dateofbirth).format('DD/MM/YYYY')}</h4>
                                        {/* <h4 className='heading-profile1'>12/01/2003</h4> */}
                                    </div>
                                    <div className="line"></div>
                                </div>
                                {/* Gender */}
                                <div className="row g-0  py-2 border-bottom ">
                                    <div className="col-sm-6 col-md-4">
                                        <h3 className='heading-profile'>Gender</h3>

                                    </div>
                                    <div className="col-sm-2 col-md-6">
                                        <h4 className='heading-profile1'>{userData?.personalDetails?.sex}</h4>
                                    </div>
                                    <div className="line"></div>
                                </div>
                                {/* Email Address */}
                                <div className="row g-0  py-2 border-bottom">
                                    <div className="col-sm-6 col-md-4">
                                        <h3 className='heading-profile'>Email Address</h3>

                                    </div>
                                    <div className="col-sm-2 col-md-6">
                                        <h4 className='heading-profile1'>{userData?.email}</h4>
                                    </div>
                                    <div className="line"></div>
                                </div>
                                {/* Password */}
                                <div className="row g-0  py-2 border-bottom">
                                    <div className="col-sm-6 col-md-4">
                                        <h3 className='heading-profile'>Password</h3>

                                    </div>
                                    <div className="col-sm-2 col-md-6">
                                        <h4 className='heading-profile1'>{userData?.pass}</h4>
                                    </div>
                                    <div className="line"></div>
                                </div>
                                {/* Country */}
                                <div className="row g-0  py-2 border-bottom">
                                    <div className="col-sm-6 col-md-4">
                                        <h3 className='heading-profile'>Country</h3>

                                    </div>
                                    <div className="col-sm-2 col-md-6">
                                        <h4 className='heading-profile1'>{userData?.personalDetails?.country}</h4>
                                    </div>
                                    <div className="line"></div>
                                </div>
                                {/* Contact Number */}
                                <div className="row g-0  py-2  ">
                                    <div className="col-sm-6 col-md-4">
                                        <h3 className='heading-profile'>Contact Number</h3>

                                    </div>
                                    <div className="col-sm-2 col-md-6">
                                        <h4 className='heading-profile1'>{userData?.personalDetails?.countryCode}{userData?.personalDetails?.contactNumber}</h4>
                                    </div>

                                </div>
                                {/* Country */}

                            </div>
                            <div className="left-side-image-edit">
                                <div className="profile-image-left">
                                    <img src={userData?.personalDetails?.image ?? Logoimage} alt="" />
                                </div>
                                <div className="left-side-button">
                                    <Link to='/my-profile-edit'>

                                        <button>Edit</button>
                                    </Link>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <Footer />


        </>
    )
}

export default MyProfile
