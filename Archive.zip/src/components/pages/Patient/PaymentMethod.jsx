import React, { useState, useEffect } from 'react'
import { Table } from 'reactstrap'
import { Link } from 'react-router-dom'
import { Progress, Form, FormGroup, Button, Modal, ModalHeader, ModalBody, ModalFooter, Input, Row, Label } from 'reactstrap'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import Logoimage from '../../../assests/images/ys.png'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import Sidebar from '../../common/Sidebar/Sidebar'
import CreditCardForm from '../../common/CreditCardForm/CreditCardForm';
import authenticationServices from "../../../services";
import { useSelector } from 'react-redux';
import { toast } from "react-toastify";
import SpinnerLoader from '../../common/Spinner';

function PaymentMethod() {
    const [IsLoader, setIsLoader] = useState(false);
    const [modal, setModal] = useState(false);
    const [openCard, setOpenCard] = useState(false);
    const [isCardAdded, setisCardAdded] = useState(false);
    const [allCardData, setallCardData] = useState([]);
    const [selectedCardId, setSelectedCardId] = useState('');

    const toggle = () => { setModal(!modal) };

    const cardToggle = () => {
        setOpenCard(!openCard)
    }
    useEffect(() => {
        getAllCardApi()
    }, [])

    const getAllCardApi = async () => {
        try {
            setIsLoader(true);
            let res = await authenticationServices.getAllCard();
            console.log("getAllCard>>>==", res);
            if (res.data.status === 200) {
                setIsLoader(false);
                const result = res.data.data.addCardDetails
                setallCardData(result)
            }
        } catch (error) {
            setIsLoader(false);
            toast.error(error, {
                position: toast.POSITION.TOP_RIGHT,
            });
        }
    }

    return (
        <>
            <div className='payment-method'>
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className="parent-div">
                        <Sidebar />
                        <div className="child-div">
                            <div class="child-navabar text-center">
                                <h6>Payment Method</h6>
                            </div>
                            <div class="dot-line"></div>
                            <div className="payment-card-information">
                                {allCardData.length ? allCardData.map((card, index) => (
                                    <div key={index + card._id} className="left-card-detail mb-3 flex ">
                                        <Input
                                            className='input-set'
                                            type='radio'
                                            name='visaCard'
                                            value={card.cardId}
                                            checked={selectedCardId === card.cardId}
                                            onChange={() => setSelectedCardId(card.cardId)}
                                        />
                                        <h6>{card.name}</h6>
                                        <h6 style={{ marginLeft: "30%" }}>{card.cardNumber}</h6>

                                    </div>
                                )) :
                                    <div className="left-card-detail mb-3">

                                        <h6>Card Not Found</h6>
                                        {/* Render other card details here */}
                                    </div>
                                }
                                <div className="add-card-detail-button">
                                    <Button className='add-card' onClick={cardToggle}>Add New Card</Button>
                                </div>
                            </div>



                        </div>
                    </div>
                </div>
            </div>

            <Footer />
            <div>
                <Modal isOpen={openCard} className="custom-modal ">
                    <div className="modal-overlay credit-card-modal">
                        <ModalHeader toggle={cardToggle} />
                        <ModalBody>
                            <div style={{ textAlign: '' }}>
                                < CreditCardForm allCardData={allCardData} selectedCardId={selectedCardId} openCard={openCard} setOpenCard={setOpenCard} getAllCardApi={getAllCardApi} />
                                {/* <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '120px' }}>
                                    <img src={Checkpoint} alt="Icon" />
                                </div>
                                <div >
                                    <h2 style={{ fontSize: "22px", marginBottom: "15px" }}>
                                        Your appointment has been requested. You will get a notification soon.
                                    </h2>

                                </div> */}
                            </div>
                        </ModalBody>
                    </div>
                </Modal>
            </div>
        </>
    )
}

export default PaymentMethod
