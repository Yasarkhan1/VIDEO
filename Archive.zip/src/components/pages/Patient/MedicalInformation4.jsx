import React, { useState, useEffect } from 'react'
import { Table } from 'reactstrap'
import { Link, useNavigate } from 'react-router-dom'
import { Progress, Form, FormGroup, Button, Row, Label, Input, Col } from 'reactstrap'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import Logoimage from '../../../assests/images/ys.png'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import { useFormik } from 'formik'
import * as Yup from "yup";
import { object } from 'prop-types'
import { toast } from "react-toastify";
import Sidebar from '../../common/Sidebar/Sidebar'


function MedicalInformation4() {
    // const [alcoholCheck, setAlcoholCheck] = useState(false);
    // const [tobaccoCheck, setTobaccoCheck] = useState(false);
    // const [recreationalDrugCheck, setRecreationalDrugCheck] = useState(false);
    const navigate = useNavigate();
    useEffect(() => {
        const medicalStepData = localStorage.getItem("medicalStepData")
            ? JSON.parse(localStorage.getItem('medicalStepData'))
            : "";
            if (medicalStepData && Object.keys(medicalStepData)?.length && medicalStepData.hasOwnProperty("familyHistory")) {

            getPatchform();
        }
    }, [])

    // const convertDate = (inputDate) => {
    //     const parsedDate = dayjs(inputDate, 'DD-MM-YYYY');
    //     const formattedDate = parsedDate.format('YYYY-MM-DD');
    //     return formattedDate;
    // };

    //    fill form and getpatch form

    const getPatchform = () => {
        const medicalStepData = localStorage.getItem("medicalStepData")
            ? JSON.parse(localStorage.getItem("medicalStepData"))
            : "";
        {

            // const { familyRelationHistory: { family_relation, name_of_disease, marital_status, employed, recreational_drug_use,
            //     recreational_drug_active, tobacco_use, alcohol_use, dose, frequency, duration } } = familyRelationHistory
            // console.log("familyRelationHistory", familyRelationHistory);

            const { familyHistory, socialHistory, medication } = medicalStepData
            console.log("familyHistory", familyHistory, socialHistory, medication);


            formik.setValues({
                family_relation: familyHistory?.family_relation,
                name_of_disease: familyHistory?.name_of_disease,
                marital_status: socialHistory?.marital_status,
                employed: socialHistory?.employed,
                alcoholCheck: socialHistory?.alcohol_use,
                number_of_drinks: socialHistory?.number_of_drinks,
                tobacco_use: socialHistory?.tobacco_use,
                number_of_tobacco: socialHistory?.number_of_tobacco,
                recreational_drug_use: socialHistory?.recreational_drug_use,
                recreational_drug_active: socialHistory?.recreational_drug_active,
                dose: medication?.medication_dose,
                frequency: medication?.frequency,
                duration: medication?.duration


            });


        }
    };


    const validationSchema = Yup.object().shape({
        family_relation: Yup.string().required("Please select."),
        name_of_disease: Yup.string().required("Enter your disease name."),
        marital_status: Yup.string().required("Please select."),
        employed: Yup.string().required("Please select."),
        // alcohol_use: Yup.string().required("Please select."),
        // tobacco_use: Yup.string().required("Enter Your Number."),
        // recreational_drug_use: Yup.string().required("Enter drug name"),
        recreational_drug_active: Yup.string().required("Please select."),
        dose: Yup.string().required("Enter your dose name."),
        frequency: Yup.string().required("Please select your frequency."),
        duration: Yup.string().required("Enter your duration."),
        number_of_drinks: Yup.string().test(
            'isRequired',
            'Select numbers of drink',
            function (value) {
                const { alcoholCheck } = this.parent;
                if (alcoholCheck === 'YES') {
                    return Yup.string().required().isValidSync(value);
                }
                return true;
            }
        ),
        number_of_tobacco: Yup.string().test(
            'isRequired',
            'Please Enter a Number',
            function (value) {
                const { tobacco_use } = this.parent;
                if (tobacco_use === 'YES') {
                    return Yup.string().required().isValidSync(value);
                }
                return true;
            }
        ),
        recreational_drug_active: Yup.string().test(
            'isRequired',
            'Enter Type of Cancer',
            function (value) {
                const { recreational_drug_use } = this.parent;
                if (recreational_drug_use === 'YES') {
                    return Yup.string().required().isValidSync(value);
                }
                return true;
            }
        )


    });

    const formik = useFormik({
        initialValues: {
            family_relation: "",
            name_of_disease: "",
            marital_status: "",
            employed: "",
            alcohol_use: "",
            tobacco_use: "",
            recreational_drug_use: "",
            recreational_drug_active: "",
            dose: "",
            frequency: "",
            duration: "",
            alcoholCheck: "NO",
            tobaccoCheck: "NO",
            recreationalDrugCheck: "NO",
            number_of_drinks: "",
            number_of_tobacco: ""
        },
        validationSchema: validationSchema,
        onSubmit: async (values) => {
            // const step1Data = localStorage.getItem("familyRelationHistory")
            //     ? JSON.parse(localStorage.getItem("familyRelationHistory"))
            //     : "";

            const previousFormData = localStorage.getItem("medicalStepData")
                ? JSON.parse(localStorage.getItem("medicalStepData"))
                : "";

            const payload = {

                ...previousFormData,

                "familyHistory": {
                    "family_relation": values.family_relation,
                    "name_of_disease": values.name_of_disease
                },
                "socialHistory": {
                    "marital_status": values.marital_status,
                    "employed": values.employed,
                    "alcohol_use": values.alcoholCheck,
                    "number_of_drinks": values.number_of_drinks,
                    "tobacco_use": values.tobacco_use,
                    "number_of_tobacco": values.number_of_tobacco,
                    "recreational_drug_use": values.recreational_drug_use,
                    "recreational_drug_active": values.recreational_drug_active
                },
                "medication": {
                    medication_dose: values.dose,
                    "frequency": values.frequency,
                    "duration": values.duration
                }
            };


            try {
                console.log("familyHistory  payload=", payload);
                // localStorage.setItem("familyRelationHistory", JSON.stringify(payload));
                localStorage.setItem("medicalStepData", JSON.stringify(payload));
                navigate("/medical-information5")
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        }

    });

    // useEffect(()=>{
    //     if (!alcoholCheck) {
    //         formik.setFieldError('alcohol_use', '');
    //         formik.setFieldTouched('alcohol_use', false);
    //     }
    // },[alcoholCheck])

    console.log("formik", formik.errors)
    const handleRadioChange = (event) => {
        console.log("event.target.value==", event.target.name);
        const name = event.target.name
        const value = event.target.value;
        if (name === "alcoholCheck") {
            formik.setFieldValue('alcoholCheck', value);
            // setAlcoholCheck(event.target.value === 'Yes');
            if (event.target.value === 'NO') {
                formik.setFieldValue('number_of_drinks', '');
                formik.setFieldError('number_of_drinks', '');
                formik.setFieldTouched('number_of_drinks', false);

            }
            // console.log("formik.errors.alcohol_use", formik.errors.alcohol_use);
        }
        if (name === "tobacco_use") {
            formik.setFieldValue('tobacco_use', value);
            // setTobaccoCheck(event.target.value === 'Yes');
            if (event.target.value === 'NO') {
                formik.setFieldValue('number_of_tobacco', '');
                formik.setFieldError('number_of_tobacco', '');
                formik.setFieldTouched('number_of_tobacco', false);
            }
            //    console.log('formik.errors.tobacco_use', formik.errors.tobacco_use );
        };
        if (name === "recreational_drug_use") {
            // setrecreational_drug_use(event.target.value === 'Yes');
            formik.setFieldValue('recreational_drug_use', value);
            if (event.target.value === 'NO') {
                formik.setFieldValue('recreational_drug_active', '');
                formik.setFieldError('recreational_drug_active', '');
                formik.setFieldTouched('recreational_drug_active', false);
            }
        };

    };
    return (
        <>
            <div className='medical-information4'>
                <LoginNavbar />
                <div className="container mb-5">
                    <div className="parent-div">
                        <Sidebar />

                        <div className="child-div">
                            <div className="progress-bar-container">
                                <div className="progress-bar">
                                    <span>3</span>
                                </div>

                            </div>
                            <div className="middle-content">
                                <Form onSubmit={formik.handleSubmit}>
                                    <Row>
                                        <h1>Family History</h1>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleSelect">
                                                    Relation
                                                </Label>
                                                <Input
                                                    name="family_relation"
                                                    type="select"
                                                    {...formik.getFieldProps("family_relation")}
                                                    className={formik.touched.family_relation && formik.errors.family_relation ? 'is-invalid' : ""}
                                                >
                                                    <option>Select family relation</option>
                                                    <option>Father</option>
                                                    <option>Mother</option>
                                                    <option>Brother</option>
                                                    <option>Sister</option>
                                                </Input>
                                                {formik.touched.family_relation && formik.errors.family_relation ? <small className='validation_error'>{formik.errors.family_relation}</small> : ""}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleText">
                                                    Name of Disease
                                                </Label>
                                                <Input

                                                    name="name_of_disease"
                                                    type="Text"
                                                    placeholder='Enter Name of Disease'
                                                    {...formik.getFieldProps("name_of_disease")}
                                                    className={formik.touched.name_of_disease && formik.errors.name_of_disease ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.name_of_disease && formik.errors.name_of_disease ? <small className='validation_error'>{formik.errors.name_of_disease}</small> : ""}

                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <h1>Social History</h1>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleSelect">
                                                    Marital status
                                                </Label>
                                                <Input
                                                    name="marital_status"
                                                    type="select"
                                                    {...formik.getFieldProps("marital_status")}
                                                    className={formik.touched.marital_status && formik.errors.marital_status ? 'is-invalid' : ""}
                                                >
                                                    <option>Select marital status</option>
                                                    <option>Married</option>
                                                    <option>Unmarried</option>
                                                </Input>
                                                {formik.touched.marital_status && formik.errors.marital_status ? <small className='validation_error'>{formik.errors.marital_status}</small> : ""}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleSelect">
                                                    Employed (Yes/No)
                                                </Label>
                                                <Input
                                                    name="employed"
                                                    type="select"
                                                    {...formik.getFieldProps("employed")}
                                                    className={formik.touched.employed && formik.errors.employed ? 'is-invalid' : ""}
                                                >
                                                    <option>Select Yes or No</option>
                                                    <option>Yes</option>
                                                    <option>No</option>
                                                </Input>
                                                {formik.touched.employed && formik.errors.employed ? <small className='validation_error'>{formik.errors.employed}</small> : ""}
                                            </FormGroup>
                                        </Col>

                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleFile"> Alcohol Use
                                                    <input type="radio" id="Drink" name="alcoholCheck" value="YES" style={{ margin: "1px 5px" }} checked={formik.values.alcoholCheck === 'YES'} onChange={handleRadioChange} />
                                                    Yes (Drinks/Week) <input type="radio" id="No" name="alcoholCheck" value="NO" style={{ margin: "1px 5px" }} checked={formik.values.alcoholCheck === 'NO'} onChange={handleRadioChange} />
                                                    No
                                                </Label>
                                                {formik.values.alcoholCheck === 'YES' &&
                                                    <>
                                                        <Input
                                                            name="number_of_drinks"
                                                            type="select"
                                                            {...formik.getFieldProps("number_of_drinks")}

                                                            className={formik.touched.number_of_drinks && formik.errors.number_of_drinks ? 'is-invalid' : ""}
                                                        >
                                                            <option>Enter Number of Drinks</option>
                                                            <option>1</option>
                                                            <option>2</option>
                                                            <option>3</option>
                                                            <option>4</option>
                                                        </Input>
                                                        {formik.touched.number_of_drinks && formik.errors.number_of_drinks ? <small className='validation_error'>{formik.errors.number_of_drinks}</small> : ""}
                                                    </>
                                                }
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label>Tobacco Use
                                                    <input type="radio" id="Number of" name="tobacco_use" value="YES" style={{ margin: "1px 5px" }} checked={formik.values.tobacco_use === 'YES'} onChange={handleRadioChange} />
                                                    Yes (Number of Packs/Day)
                                                    <input type="radio" id="css" name="tobacco_use" value="NO" style={{ margin: "1px 5px" }} checked={formik.values.tobacco_use === 'NO'} onChange={handleRadioChange} />
                                                    No
                                                </Label>
                                                {formik.values.tobacco_use === 'YES' &&
                                                    <>
                                                        <Input
                                                            name="number_of_tobacco"
                                                            type="text"
                                                            placeholder='Number of Packs/Day'
                                                            {...formik.getFieldProps("number_of_tobacco")}
                                                            className={formik.touched.number_of_tobacco && formik.errors.number_of_tobacco ? 'is-invalid' : ""}
                                                        />
                                                        {formik.touched.number_of_tobacco && formik.errors.number_of_tobacco ? <small className='validation_error'>{formik.errors.number_of_tobacco}</small> : ""}
                                                    </>
                                                }
                                            </FormGroup>
                                        </Col>

                                        <Col md={6}>

                                            <Label for="exampletext">Recreational drug use Use
                                                <input type="radio" id="Name" name="recreational_drug_use" value="YES" style={{ margin: "2px 5px" }} checked={formik.values.recreational_drug_use === 'YES'} onChange={handleRadioChange} />
                                                Yes (Name, Active)
                                                <input type="radio" id="No" name="recreational_drug_use" value="NO" style={{ margin: "1px 5px" }} checked={formik.values.recreational_drug_use === 'NO'} onChange={handleRadioChange} />
                                                No
                                            </Label>

                                            <Row>
                                                <Col md={8}>

                                                    <FormGroup>
                                                        {formik.values.recreational_drug_use === 'YES' &&
                                                            <>
                                                                <Input
                                                                    name="recreational_drug_active"
                                                                    placeholder="Enter Type of Cancer"
                                                                    type="text"
                                                                    {...formik.getFieldProps("recreational_drug_active")}
                                                                    className={formik.touched.recreational_drug_active && formik.errors.recreational_drug_active ? 'is-invalid' : ""}
                                                                />
                                                                {formik.touched.recreational_drug_active && formik.errors.recreational_drug_active ? <small className='validation_error'>{formik.errors.recreational_drug_active}</small> : null}
                                                            </>}
                                                    </FormGroup>

                                                </Col>

                                                <Col md={4}>

                                                    <FormGroup>
                                                        {formik.values.recreational_drug_use === 'YES' &&
                                                            <>
                                                                <Input
                                                                    name="recreational_drug_active"
                                                                    placeholder="Enter Type of Cancer"
                                                                    type="select"
                                                                    {...formik.getFieldProps("recreational_drug_active")}
                                                                    className={formik.touched.recreational_drug_active && formik.errors.recreational_drug_active ? 'is-invalid' : ""}
                                                                >

                                                                    <option value="" disabled selected>Select Active</option>
                                                                    <option value="on">ON</option>
                                                                    <option value="Off">OFF</option>

                                                                </Input>
                                                                {formik.touched.recreational_drug_active && formik.errors.recreational_drug_active ? <small className='validation_error'>{formik.errors.recreational_drug_active}</small> : null}
                                                            </>}
                                                    </FormGroup>

                                                </Col>
                                            </Row>
                                        </Col>

                                    </Row>

                                    <Row className='my-3'>
                                        <h1>Medication</h1>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleText">Medication (Dose)</Label>
                                                <Input
                                                    name="dose"
                                                    type="text"
                                                    placeholder='Enter Medication'
                                                    {...formik.getFieldProps("dose")}
                                                    className={formik.touched.dose && formik.errors.dose ? 'is-invalid' : ""}

                                                />
                                                {formik.touched.dose && formik.errors.dose ? <small className='validation_error'>{formik.errors.dose}</small> : ""}
                                            </FormGroup>
                                        </Col>

                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleFile">Frequency</Label>
                                                <Input
                                                    name="frequency"
                                                    type="select"
                                                    {...formik.getFieldProps("frequency")}
                                                    className={formik.touched.frequency && formik.errors.frequency ? 'is-invalid' : ""}
                                                >
                                                    <option>Select Frequency</option>
                                                    <option value="2mm">22mm</option>
                                                    <option value="6mm">12mm</option>
                                                </Input>
                                                {formik.touched.frequency && formik.errors.frequency ? <small className='validation_error'>{formik.errors.frequency}</small> : ""}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleFile">Duration</Label>
                                                <Input

                                                    name="duration"
                                                    type="text"
                                                    placeholder='Enter Duration'
                                                    {...formik.getFieldProps("duration")}
                                                    className={formik.touched.duration && formik.errors.duration ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.duration && formik.errors.duration ? <small className='validation_error'>{formik.errors.duration}</small> : ""}
                                            </FormGroup>
                                        </Col>
                                    </Row>

                                    <Button className='btn-secondry' type='submit'>
                                        Next
                                    </Button>
                                </Form>

                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <Footer />


        </>
    )
}

export default MedicalInformation4
