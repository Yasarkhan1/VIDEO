import React, { useEffect, useState } from 'react';
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import Sidebar from '../../common/Sidebar/Sidebar'
import { FormGroup, Form, Button, Input, Label, Col, Row } from 'reactstrap'
import { Formik, useFormik } from 'formik';
import * as Yup from 'yup';
import AppointNavbar from '../../common/AppointmentNavbar/AppointNavbar'
import Footer from '../../common/Footer/Footer'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { toast } from "react-toastify";
import dayjs from "dayjs";
import authenticationServices from "../../../services";
import { useSelector } from 'react-redux';
import SpinnerLoader from '../../common/Spinner';
const validationSchema = Yup.object().shape({
    // preferredName: Yup.string().required('Preferred Name is required'),
    // age: Yup.string().required('Age is required'),
    // dob: Yup.date().nullable().required('Date of Birth is required'),
    // height: Yup.string().required('Height is required'),
    // weight: Yup.string().required('Weight is required'),
    // location: Yup.string().required('Location is required'),
    // preferredName: Yup.string().required('Preferred Name is required'),
    // age: Yup.string().required('Age is required'),
    // dob: Yup.date().nullable().required('Date of Birth is required'),
    // height: Yup.string().required('Height is required'),
    // weight: Yup.string().required('Weight is required'),
    // location: Yup.string().required('Location is required'),
});

function NewAppointment2() {
    const location = useLocation()
    const userData = useSelector((state) => state?.user?.data);
    const dropDownData = useSelector((state) => state.allDropDown.data);
    // console.log("dropDownData====+++", dropDownData);
    console.log("userDarta+++", userData);
    const navigate = useNavigate()
    const appointmentId = location?.state?.appointmentId
    const [IsLoader, setIsLoader] = useState(false);
    const [selectedDate, setSelectedDate] = useState(null);

    const handleDateChange = (date) => {
        setSelectedDate(date);
    };

    // useEffect to redirect step 1 if previous form not submitted
    // useEffect(() => {
    //     if (appointmentId === '' || appointmentId === undefined) {
    //         navigate("/new-appointment-1")
    //     }
    // }, [appointmentId])

    const formik = useFormik({
        initialValues: {
            preferredName: '',
            age: '',
            dob: null,
            height: '',
            weight: '',
            location: '',
        },
        validationSchema: validationSchema,
        onSubmit: async (values) => {
            // Handle form submission
            console.log(values);
            const payload = {
                "PreferredName": values.preferredName,
                "age": values.age,
                "dateOfBirth": dayjs(values.dob).format('DD/MM/YYYY'),
                "height": values.height,
                "weight": values.weight,
                "locatoin": values.location,
                "appointmentId": appointmentId,
            }
            try {
                console.log("appointmentBook step 2 payload=", payload);

                setIsLoader(true);
                let res = await authenticationServices.appointmentBook(payload, 2);
                console.log("appointmentBook step 2 result==", res);
                if (res.data.status === 200) {
                    const appointmentId = res.data.data.appointmentId
                    setIsLoader(false);
                    toast.success(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                    // navigate("/")
                    navigate("/new-appointment-3", { state: { appointmentId: appointmentId }, replace: true })
                } else {
                    setIsLoader(false);
                    toast.error(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                }
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
            // navigate('/new-appointment-3')
        },
    });

    return (
        <>
            <div className="new-appointment2">
                {IsLoader && <SpinnerLoader />}
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className="parent-div">
                        <Sidebar />
                        <div className="child-div">
                            <div className="child-navabar">
                                <AppointNavbar />
                            </div>

                            <div className="form-groupes">
                                <Form onSubmit={formik.handleSubmit}>
                                    <Row>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="preferredName">Preferred Name</Label>
                                                <Input
                                                    id="preferredName"
                                                    type="text"
                                                    {...formik.getFieldProps('preferredName')}
                                                    invalid={formik.touched.preferredName && formik.errors.preferredName ? true : false}
                                                />
                                                {formik.touched.preferredName && formik.errors.preferredName ? (
                                                    <div className="validation_error">{formik.errors.preferredName}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="age">Age</Label>
                                                <Input
                                                    id="age"
                                                    type="select"
                                                    {...formik.getFieldProps('age')}
                                                    invalid={formik.touched.age && formik.errors.age ? true : false}
                                                >
                                                    <option value="">Select</option>
                                                    {dropDownData?.age.length ?
                                                        dropDownData?.age.map((item, ind) => (

                                                            <option value={item.value} key={ind}>{item.label}</option>
                                                        ))
                                                        : ""
                                                    }
                                                </Input>
                                                {formik.touched.age && formik.errors.age ? (
                                                    <div className="validation_error">{formik.errors.age}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="dob">Date of Birth</Label>
                                                {userData?.personalDetails?.dateOfBirth &&
                                                    <Input
                                                        id="dateOfBirth"
                                                        name="dob"
                                                        placeholder="Enter Dob"
                                                        max={new Date().toISOString().split('T')[0]}
                                                        min="1980-01-01"
                                                        type="date"
                                                        disabled
                                                        defaultValue={userData?.personalDetails?.dateOfBirth}
                                                        // {...formik.getFieldProps("dob")}
                                                        className={formik.touched.dob && formik.errors.dob ? 'is-invalid form-control' : "form-control"}
                                                    />}
                                                {/* <DatePicker
                                                    id="dob"
                                                    selected={selectedDate}
                                                    onChange={(date) => {
                                                        formik.setFieldValue('dob', date);
                                                        handleDateChange(date);
                                                    }}
                                                    maxDate={new Date()}
                                                    minDate={new Date("1980-01-01")}
                                                    showYearDropdown={true}
                                                    isClearable={selectedDate}
                                                    scrollableYearDropdown={true}
                                                    yearDropdownItemNumber={43}
                                                    // invalid={formik.touched.dob && formik.errors.dob ? true : false}
                                                    className={formik.touched.dob && formik.errors.dob ? 'is-invalid form-control' : "form-control"}
                                                    dateFormat="dd/MM/yyyy"
                                                    placeholderText="Select DOB"
                                                // className="input-datepicker"
                                                /> */}
                                                {formik.touched.dob && formik.errors.dob ? (
                                                    <div className="validation_error">{formik.errors.dob}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="height">Height</Label>
                                                <Input
                                                    id="height"
                                                    type="select"
                                                    {...formik.getFieldProps('height')}
                                                    invalid={formik.touched.height && formik.errors.height ? true : false}
                                                >
                                                    <option value="">Select</option>

                                                    {dropDownData?.height.length ?
                                                        dropDownData?.height.map((item, ind) => (

                                                            <option value={item.value} key={ind}>{item.label}</option>
                                                        ))
                                                        : ""
                                                    }
                                                </Input>
                                                {formik.touched.height && formik.errors.height ? (
                                                    <div className="validation_error">{formik.errors.height}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="weight">Weight</Label>
                                                <Input
                                                    id="weight"
                                                    type="select"
                                                    {...formik.getFieldProps('weight')}
                                                    invalid={formik.touched.weight && formik.errors.weight ? true : false}
                                                >
                                                    <option value="">Select</option>
                                                    {dropDownData?.weight.length ?
                                                        dropDownData?.weight.map((item, ind) => (

                                                            <option value={item.value} key={ind}>{item.label}</option>
                                                        ))
                                                        : ""
                                                    }
                                                </Input>
                                                {formik.touched.weight && formik.errors.weight ? (
                                                    <div className="validation_error">{formik.errors.weight}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="location">Location</Label>
                                                <Input
                                                    id="location"
                                                    type="text"
                                                    {...formik.getFieldProps('location')}
                                                    invalid={formik.touched.location && formik.errors.location ? true : false}
                                                />
                                                {formik.touched.location && formik.errors.location ? (
                                                    <div className="validation_error">{formik.errors.location}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <div className='button-container'>
                                        {/* <Link to={'/new-appointment-3'}> */}
                                        <Button color="primary" className="next-button" type="submit">
                                            Next
                                        </Button>
                                        {/* </Link> */}
                                    </div>
                                </Form>
                                {/* 
                                <div className='button-container'>
                                    <Link to={'/new-appointment-3'}>
                                        <Button color="primary" className='next-button'>
                                            Next
                                        </Button>
                                    </Link>

                                </div>  */}
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <Footer />

        </>
    )
}

export default NewAppointment2
