import React, { useState } from 'react'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import Sidebar from '../../common/Sidebar/Sidebar'
import { FormGroup, Form, Button, Input, Label, Col, Row } from 'reactstrap'
import { Formik, useFormik } from 'formik';
import * as Yup from 'yup'; // Import Yup for validation
import AppointNavbar from '../../common/AppointmentNavbar/AppointNavbar'
import Footer from '../../common/Footer/Footer'
import { Link, useNavigate } from 'react-router-dom'
import SpinnerLoader from '../../common/Spinner';
import { checkSpace, saveToSessionStorage } from "../../../utils";
import { toast } from "react-toastify";
import authenticationServices from "../../../services";
import { useSelector } from 'react-redux';

const validationSchema = Yup.object().shape({
    expert: Yup.string().required('Expert is required'),
    urgency: Yup.string().required('Urgency is required'),
    concern: Yup.string()
        .max(100, 'Main concern must be at most 100 characters')
        .required('Main concern is required'),
});

function NewAppointment() {
    const dropDownData = useSelector((state) => state.allDropDown.data);
    // console.log("dropDownData====+++", dropDownData);
    const navigate = useNavigate()
    const [IsLoader, setIsLoader] = useState(false);
    const formik = useFormik({
        initialValues: {
            expert: '',
            urgency: '',
            concern: '',
        },
        validationSchema: validationSchema,
        onSubmit: async (values) => {
            // Handle form submission
            console.log(values);
            const payload = {
                "expertNeed": values.expert,
                "seen": values.urgency,
                "concernToDay": values.concern
            }
            try {
                console.log("appointmentBook step 1  payload=", payload);

                setIsLoader(true);
                let res = await authenticationServices.appointmentBook(payload, 1);
                console.log("appointmentBook step 1 result==", res);
                if (res.data.status === 200) {
                    const appointmentId = res.data.data.appointmentId
                    setIsLoader(false);
                    toast.success(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                    // navigate("/")
                    navigate("/new-appointment-2", { state: { appointmentId: appointmentId }, replace: true })
                } else {
                    setIsLoader(false);
                    toast.error(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                }
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        },
    });

    return (
        <>
            <div className="new-appointment">
                {IsLoader && <SpinnerLoader />}
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className="parent-div">
                        <Sidebar />
                        <div className="child-div">
                            <div className="child-navabar">
                                <AppointNavbar />
                            </div>

                            <div className="form-groupes">
                                <Form onSubmit={formik.handleSubmit}>
                                    <Row>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="expert">What expert do you need?</Label>
                                                <Input
                                                    id="expert"
                                                    name="expert"
                                                    type="select"
                                                    {...formik.getFieldProps('expert')}
                                                    invalid={formik.touched.expert && formik.errors.expert ? true : false}
                                                >
                                                    <option value="">Select</option>
                                                    {dropDownData?.expertNeed.length ?
                                                        dropDownData?.expertNeed.map((item, ind) => (

                                                            <option value={item._id} key={ind}>{item.name}</option>
                                                        ))
                                                        : ""}
                                                </Input>
                                                {formik.touched.expert && formik.errors.expert ? (
                                                    <div className="validation_error">{formik.errors.expert}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="urgency">How soon do you need to be seen?</Label>
                                                <Input
                                                    id="urgency"
                                                    name="urgency"
                                                    type="select"
                                                    {...formik.getFieldProps('urgency')}
                                                    invalid={formik.touched.urgency && formik.errors.urgency ? true : false}
                                                >
                                                    <option value="">Select</option>
                                                    {dropDownData?.soon.length ?
                                                        dropDownData?.soon.map((item, ind) => (

                                                            <option value={item._id} key={ind}>{item.name}</option>
                                                        ))
                                                        : ""
                                                    }
                                                </Input>
                                                {formik.touched.urgency && formik.errors.urgency ? (
                                                    <div className="validation_error">{formik.errors.urgency}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <FormGroup>
                                        <Label for="concern">
                                            What is your main concern today? <span>(Word Limit 100 Characters)</span>
                                        </Label>
                                        <Input
                                            id="concern"
                                            name="concern"
                                            type="textarea"
                                            placeholder="Type here..."
                                            {...formik.getFieldProps('concern')}
                                            invalid={formik.touched.concern && formik.errors.concern ? true : false}
                                        />
                                        {formik.touched.concern && formik.errors.concern ? (
                                            <div className="validation_error">{formik.errors.concern}</div>
                                        ) : null}
                                    </FormGroup>
                                    <div className='button-container'>
                                        <Button color="primary" className="next-button" type="submit">
                                            Next
                                        </Button>
                                    </div>
                                </Form>

                                {/* <div>
                                    <Link to={'/new-appointment-2'}>
                                    <Button color="primary" className='next-button'>
                                        Next
                                    </Button>
                                    </Link>

                                </div> */}
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <Footer />

        </>
    )
}

export default NewAppointment
