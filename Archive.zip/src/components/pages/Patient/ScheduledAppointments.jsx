import React, { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Progress, Form, FormGroup, Button, Modal, ModalHeader, ModalBody, ModalFooter, Input, Row, Col } from 'reactstrap'
import Creaditcard from '../../../assests/images/credit-card-pay-svgrepo-com.png';
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import Sidebar from '../../common/Sidebar/Sidebar'
import { toast } from "react-toastify";
import authenticationServices from "../../../services";
import SpinnerLoader from '../../common/Spinner';
import Logoimage from '../../../assests/images/ys.png'
import ReactPaginate from 'react-paginate';

const ScheduledAppointments = () => {
    const navigate = useNavigate();
    const [IsLoader, setIsLoader] = useState(false);
    const [open, setOpen] = useState(false);
    const notesToggle = () => { setOpen(!open) };
    const [slectedTab, setslectedTab] = useState('tab1')
    const [appointmentListData, setAppointmentListData] = useState([])
    const [expertData, setExpertData] = useState([])
    const [currentPage, setCurrentPage] = useState(0);
    const appointmentsPerPage = 5;

    const handlePageClick = ({ selected }) => {
        setCurrentPage(selected);
    };

    const offset = currentPage * appointmentsPerPage;
    const currentAppointments = appointmentListData.slice(offset, offset + appointmentsPerPage);

    const getScheduleAppointment = async () => {
        try {
            setIsLoader(true);
            let res = await authenticationServices.getAllAppointments();
            console.log("getAllAppointments ===>>", res);
            if (res.data.status === 200) {
                const result = res.data.data
                setAppointmentListData(result)
                setIsLoader(false);
                toast.success(res.data.message, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            } else {
                setIsLoader(false);
                toast.error(res.data.message, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        } catch (error) {
            toast.error(error, {
                position: toast.POSITION.TOP_RIGHT,
            });
        }
    }

    useEffect(() => {
        getScheduleAppointment()
    }, [])

    const tabChange = (value) => {
        setslectedTab(value)
    }

    const getConsultant = async (expertId) => {
        try {
            setIsLoader(true);
            let res = await authenticationServices.getEcDertailsById(expertId);
            console.log("getEcDertailsById ===>>", res.data.data[0]);
            if (res.data.status === 200) {
                const result = res.data.data[0]
                setExpertData(result)
                setIsLoader(false);
                setOpen(true)
                // toast.success(res.data.message, {
                //     position: toast.POSITION.TOP_RIGHT,
                // });
            } else {
                setIsLoader(false);
                toast.error(res.data.message, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        } catch (error) {
            toast.error(error, {
                position: toast.POSITION.TOP_RIGHT,
            });
        }
    }

    console.log("open==", open)
    return (
        <>
            <div className="scheduled-Appointments">
                {IsLoader && <SpinnerLoader />}
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className="parent-div">
                        <Sidebar />
                        <div className="child-div">
                            <div className="child-navabar text-center">

                                <h6>Scheduled Appointments</h6>
                            </div>
                            <div className="dot-line"></div>

                            <div className="container-table">

                                <table className="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">S.No.</th>
                                            <th scope="col">Appointment Date</th>
                                            <th scope="col">EC Name</th>
                                            <th scope="col">Appointment ID</th>
                                            <th scope='col'>Appointment Status</th>
                                            <th scope='col'>Payment Status</th>
                                            <th scope='col'>Call Status</th>
                                            <th scope='col'>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        {/* {appointmentListData?.length ?

                                            appointmentListData.map((item, index) => (
                                                <tr key={index + item._id}>
                                                    <th scope="row">{index + 1}</th>
                                                    <td>--</td>
                                                    <td>--</td>
                                                    <td>{item._id}</td>
                                                    <td>{item.status}</td>
                                                    <td>{item.paymentStatus}</td>
                                                    <td> <Link to="">Initiate Call </Link></td>
                                                    <td onClick={notesToggle}> <Link >View </Link></td>
                                                </tr>

                                            ))
                                            : <tr><td colSpan={8}>Data Not Found</td></tr>
                                        } */}
                                        {currentAppointments.length ? (
                                            currentAppointments.map((item, index) => (
                                                <tr key={index + item._id}>
                                                    <th scope="row">{index + 1}</th>
                                                    <td>--</td>
                                                    <td>--</td>
                                                    <td>{item._id}</td>
                                                    <td>{item.status}</td>
                                                    <td>{item.paymentStatus}</td>
                                                    <td> <Link to={`/initiate-call/${item._id}`} state={{ seheduleAppointment: item.seheduleAppointment }}>Initiate Call </Link></td>
                                                    <td > <Link onClick={() => getConsultant(item?.seheduleAppointment?.expertConsulatant)}>View </Link></td>
                                                </tr>
                                            ))
                                        ) : (
                                            <tr>
                                                <td colSpan={8}>Data Not Found</td>
                                            </tr>
                                        )}
                                        {/* <tr>
                                            <th scope="row">2</th>
                                            <td>Dr. Abdul Kareem</td>
                                            <td>36</td>
                                            <td>25 May, 2023</td>
                                            <td>Medicam</td>
                                            <td>Pending</td>

                                            <td> <Link to="/initiate-call">Initiate Call </Link></td>
                                            <td><a href='#'>View</a></td>
                                        </tr>
                                         */}
                                    </tbody>
                                </table>
                                {appointmentListData.length > 0 && (
                                    <ReactPaginate
                                        previousLabel={'Previous'}
                                        nextLabel={'Next'}
                                        breakLabel={'...'}
                                        breakClassName={'break-me'}
                                        pageCount={Math.ceil(appointmentListData.length / appointmentsPerPage)}
                                        marginPagesDisplayed={2}
                                        pageRangeDisplayed={5}
                                        onPageChange={handlePageClick}
                                        containerClassName={'pagination'}
                                        subContainerClassName={'pages pagination'}
                                        activeClassName={'active'}
                                        previousClassName={currentPage === 0 ? 'disabled-class' : ''}
                                        nextClassName={
                                            currentPage === Math.ceil(appointmentListData.length / appointmentsPerPage) - 1
                                                ? 'disabled-class'
                                                : ''
                                        }
                                    />
                                )}
                            </div>



                        </div>
                    </div>
                </div>

            </div>
            <Footer />

            <div>
                <Modal isOpen={open} toggle={notesToggle} className="custom-modal" centered>
                    <div className="modal-overlay">
                        <ModalHeader toggle={notesToggle} />
                        <ModalBody>
                            <div>
                                <Row>
                                    <Col>
                                        <button className={`Ec_Name_button ${slectedTab === 'tab1' ? '' : 'disable-color'}`} onClick={() => tabChange("tab1")}>EC Name</button>

                                    </Col>
                                    <Col>
                                        <button className={`professional_button ${slectedTab === 'tab2' ? '' : 'disable-color'}`} onClick={() => tabChange("tab2")}>Professional</button>
                                    </Col>
                                    <Col>
                                        <button className={`call_charges_button ${slectedTab === 'tab3' ? '' : 'disable-color'}`} onClick={() => tabChange("tab3")}>Call Charges</button>
                                    </Col>
                                </Row>
                                {/* First Button Profile-Ec */}
                                {slectedTab === 'tab1' && <div className="profile-ec mt-4">
                                    <div className="middle-contnet">
                                        <div className="row g-0 py-2  border-bottom">
                                            <div className="col-sm-6 col-md-4">
                                                <h3 className='heading-profile'>EC Name</h3>

                                            </div>
                                            <div className="col-sm-2 col-md-6">
                                                <h4 className='heading-profile'>{expertData?.personalDetails?.name}</h4>
                                            </div>
                                            <div className="line"></div>
                                        </div>


                                        {/* Country */}
                                        <div className="row g-0  py-2 border-bottom">
                                            <div className="col-sm-6 col-md-4">
                                                <h3 className='heading-profile'>Location</h3>

                                            </div>
                                            <div className="col-sm-2 col-md-6">
                                                {/* <h4 className='heading-profile1'></h4> */}
                                                <h4 className='heading-profile'>{expertData?.personalDetails?.address1 + ` ` + expertData?.personalDetails?.address2}</h4>
                                            </div>
                                            <div className="line"></div>
                                        </div>
                                        {/* time-zone */}
                                        <div className="row g-0  py-2 border-bottom">
                                            <div className="col-sm-6 col-md-4">
                                                <h3 className='heading-profile'>Time Zone</h3>

                                            </div>
                                            <div className="col-sm-2 col-md-6">
                                                <h4 className='heading-profile1'></h4>
                                            </div>
                                            <div className="line"></div>
                                        </div>


                                        {/* Country */}

                                    </div>
                                    <div className="left-side-image-edit">
                                        <div className="profile-image-left">
                                            <img src={expertData?.personalDetails?.image} alt="" />
                                        </div>

                                    </div>
                                </div>}
                                {/* Second Button Professional */}
                                {slectedTab === 'tab2' && <div className="professional mt-4">
                                    <div className="professional-contnet">
                                        <div className="row g-0 py-2  border-bottom">
                                            <div className="col-sm-6 col-md-4">
                                                <h3 className='heading-profile'>Speciality</h3>
                                            </div>
                                            <div className="col-sm-2 col-md-6">
                                                <h4 className='heading-profile'>{expertData?.professionalDetails?.specialty}</h4>
                                                {/* <h5 className='heading-profile1'>Alim</h5> */}
                                            </div>
                                            <div className="line"></div>
                                        </div>


                                        {/* Country */}
                                        <div className="row g-0  py-2 border-bottom">
                                            <div className="col-sm-6 col-md-4">

                                                <h3 className='heading-profile'>Degree</h3>

                                            </div>
                                            <div className="col-sm-2 col-md-6">
                                                <h4 className='heading-profile'>{expertData?.professionalDetails?.degree}</h4>
                                                {/* <h4 className='heading-profile1'></h4> */}
                                            </div>
                                            <div className="line"></div>
                                        </div>
                                        {/* time-zone */}
                                        <div className="row g-0  py-2 border-bottom">
                                            <div className="col-sm-6 col-md-4">
                                                <h3 className='heading-profile'>Medical School</h3>

                                            </div>
                                            <div className="col-sm-2 col-md-6">
                                                <h4 className='heading-profile'>{expertData?.professionalDetails?.institution?.name}</h4>
                                                {/* <h4 className='heading-profile1'></h4> */}
                                            </div>
                                            <div className="line"></div>
                                        </div>


                                        {/* Residency */}
                                        <div className="row g-0  py-2 border-bottom">
                                            <div className="col-sm-6 col-md-4">
                                                <h3 className='heading-profile'>Residency</h3>

                                            </div>
                                            <div className="col-sm-2 col-md-6">
                                                <h4 className='heading-profile'>{expertData?.professionalDetails?.residency?.name}</h4>
                                                {/* <h4 className='heading-profile1'></h4> */}
                                            </div>
                                            <div className="line"></div>
                                        </div>
                                        {/* Fellowship */}
                                        <div className="row g-0  py-2 border-bottom">
                                            <div className="col-sm-6 col-md-4">
                                                <h3 className='heading-profile'>Fellowship</h3>

                                            </div>
                                            <div className="col-sm-2 col-md-6">
                                                {/* <h4 className='heading-profile1'></h4> */}
                                                <h4 className='heading-profile'>{expertData?.professionalDetails?.fellowship?.name}</h4>
                                            </div>
                                            <div className="line"></div>
                                        </div>

                                        {/* Area of Expertise */}
                                        <div className="row g-0  py-2 border-bottom">
                                            <div className="col-sm-6 col-md-4">
                                                <h3 className='heading-profile'>Area of Expertise</h3>

                                            </div>
                                            <div className="col-sm-2 col-md-6">
                                                <h4 className='heading-profile'>{expertData?.employmentDetails?.areaOfExpertise}</h4>
                                                {/* <h4 className='heading-profile1'></h4> */}
                                            </div>
                                            <div className="line"></div>
                                        </div>
                                        {/* Role */}
                                        <div className="row g-0  py-2 border-bottom">
                                            <div className="col-sm-6 col-md-4">
                                                <h3 className='heading-profile'>Role</h3>

                                            </div>
                                            <div className="col-sm-2 col-md-6">
                                                <h4 className='heading-profile'>{expertData?.employmentDetails?.currentRole}</h4>
                                                {/* <h4 className='heading-profile1'></h4> */}
                                            </div>
                                            <div className="line"></div>
                                        </div>
                                        {/*  Current Employer */}
                                        <div className="row g-0  py-2 border-bottom">
                                            <div className="col-sm-6 col-md-4">
                                                <h3 className='heading-profile'> Current Employer</h3>

                                            </div>
                                            <div className="col-sm-2 col-md-6">
                                                {/* <h4 className='heading-profile1'></h4> */}
                                                <h4 className='heading-profile'>{expertData?.employmentDetails?.name}</h4>
                                            </div>
                                            <div className="line"></div>
                                        </div>
                                        {/*     Web Profile */}
                                        <div className="row g-0  py-2 border-bottom">
                                            <div className="col-sm-6 col-md-4">
                                                <h3 className='heading-profile'>    Web Profile</h3>

                                            </div>
                                            <div className="col-sm-2 col-md-6">
                                                <h4 className='heading-profile1'></h4>
                                                {/* <h4 className='heading-profile'>{expertData?.employmentDetails?.currentRole}</h4> */}
                                            </div>
                                            {/* <div className="line"></div> */}
                                        </div>
                                    </div>

                                </div>}
                                {/* Third Button Call Charges */}
                                {slectedTab === 'tab3' && <div className="profile-ec mt-4">
                                    <div className="CallCharges-content">
                                        <div className="row g-0 py-2">
                                            <div className=" col-md-12">
                                                <img src={Creaditcard} alt="" />
                                                <h3>Fees ${expertData?.employmentDetails?.professionalFee}</h3>
                                            </div>

                                        </div>

                                    </div>

                                </div>}
                            </div>
                        </ModalBody>
                    </div>
                </Modal>
            </div>
        </>
    )
}

export default ScheduledAppointments
