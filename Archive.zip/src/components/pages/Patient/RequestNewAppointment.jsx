import React, { useEffect, useState } from 'react'
import { FormGroup, Form, Button, Input, Label, Col } from 'reactstrap'
import { Link, useNavigate } from 'react-router-dom'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import Footer from '../../common/Footer/Footer'
import Logoimage from '../../../assests/images/ys.png'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import { Formik, useFormik } from 'formik'
import * as Yup from "yup";
import { checkSpace } from "../../../utils";
import { object } from 'prop-types'
import { toast } from "react-toastify";
import Sidebar from '../../common/Sidebar/Sidebar'
import authenticationServices from "../../../services";

function RequestNewAppointment() {
    const navigate = useNavigate();
    const [IsLoader, setIsLoader] = useState(false);
    // Function to validate the card number using Luhn algorithm
    const validateCardNumber = (value) => {
        // Remove non-digit characters
        const cardNumber = value.replace(/\D/g, '');

        let sum = 0;
        let doubleUp = false;
        for (let i = cardNumber.length - 1; i >= 0; i--) {
            let digit = parseInt(cardNumber.charAt(i), 10);
            if (doubleUp) {
                if ((digit *= 2) > 9) digit -= 9;
            }
            sum += digit;
            doubleUp = !doubleUp;
        }
        return sum % 10 === 0;
    };


    const validationSchema = Yup.object().shape({
        expert_you_need: Yup.string().required("Please select."),
        seen_within_week: Yup.string().required("Please select week"),
        main_concern_today: Yup.string().required("Please type message."),
        card_number: Yup.string()
            .required('Card number is required.')
            .matches(/^[1-9]\d*$/, 'Card number must not start with zero.')
            .matches(/^\d+$/, 'Card number must be numeric.')
            .test(
                'card_number',
                'Invalid card number.',
                (value) => validateCardNumber(value)
            ),
        // .matches(/^\d{16}$/, 'Invalid card number')
        // .required('Card number is required'),
        card_expiry: Yup.string().required("Enter card expiry date.")
            .test(
                'card_expiry',
                'Invalid expiry date.',
                (value) => /^(0[1-9]|1[0-2])\/\d{2}$/.test(value)
            )
            .test('card_expiry', 'Invalid expiry date.', (value) => {
                if (!value) return false;

                const currentDate = new Date();
                const currentYear = Number(currentDate.getFullYear().toString().slice(-2)); // Get the last two digits of the current year
                const currentMonth = currentDate.getMonth() + 1;

                const [expiryMonth, expiryYear] = value.split('/');
                const cardExpiryYear = parseInt(expiryYear, 10);
                const cardExpiryMonth = parseInt(expiryMonth, 10);
                console.log("currentYear,currentMonth,cardExpiryYear,cardExpiryMonth", currentYear, currentMonth, cardExpiryYear, cardExpiryMonth);
                if (
                    cardExpiryYear < (currentYear) ||
                    ((cardExpiryYear === (currentYear)) && (cardExpiryMonth < currentMonth))
                ) {
                    console.log("inside if");
                    return false;
                }

                return true;
            }),
        //   .matches(/^(0[1-9]|1[0-2])\/\d{2}$/, 'Invalid expiry date. Use MM/YY format.'),
        card_cvv: Yup.string().required("Enter your cvv number.").matches(/^\d{3}$/, 'CVV number must be 3 digits.'),
        card_holder_name: Yup.string().required("Enter card holder name")

    })
    const formik = useFormik({
        initialValues: {
            expert_you_need: '',
            seen_within_week: "",
            main_concern_today: '',
            card_number: '',
            card_expiry: '',
            card_cvv: '',
            card_holder_name: '',
        },
        validationSchema: validationSchema,

        onSubmit: async (values) => {


            const payload = {
                ...values,

                "seen_within_week": Number(values.seen_within_week),
                "card_number": String(values.card_number),
                "card_cvv": String(values.card_cvv)

            };
            console.log("payload")


            try {
                console.log("RequestNewAppointment payload=", payload);
                setIsLoader(true);
                const res = await authenticationServices.requestNewAppointment(payload)
                console.log(res)
                if (res.status === 200) {
                    navigate("/scheduled-appointments")
                    toast.success(res.data.responseMessage, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                } else {
                    setIsLoader(false);
                    toast.error(res.data.responseMessage, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                }
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        }


    });
    // console.log("formik error", formik.errors);

    return (
        <>
            <div className='request-new-appointment'>

                <LoginNavbar />
                <div className="container mb-5">
                    <div className="parent-div">
                        <Sidebar />
                        <div className="child-div">
                            <form onSubmit={formik.handleSubmit}>
                                <FormGroup>
                                    <Label for="exampleSelect">
                                        What expert do you need?
                                    </Label>
                                    <Input

                                        name="expert_you_need"
                                        type="select"
                                        placeholder="Select Expert"
                                        {...formik.getFieldProps("expert_you_need")}
                                        className={formik.touched.expert_you_need && formik.errors.expert_you_need ? 'is-invalid' : ""}
                                    >
                                        <option>Select Expert</option>
                                        <option>Mother</option>
                                        <option>Father</option>

                                    </Input>
                                    {formik.touched.expert_you_need && formik.errors.expert_you_need ? <small className='validation_error'>{formik.errors.expert_you_need}</small> : null}
                                </FormGroup>
                                <FormGroup>
                                    <Label for="exampleSelect">
                                        How soon do you need to be seen?
                                    </Label>
                                    <Input

                                        name="seen_within_week"
                                        type="select"
                                        {...formik.getFieldProps("seen_within_week")}
                                        className={formik.touched.seen_within_week && formik.errors.seen_within_week ? 'is-invalid' : "null"}
                                    >
                                        <option>Select Week</option>
                                        <option>1</option>
                                        <option>2</option>
                                        <option>3</option>

                                    </Input>
                                    {formik.touched.seen_within_week && formik.errors.seen_within_week ? <small className='validation_error'>{formik.errors.seen_within_week}</small> : ""}
                                </FormGroup>
                                <FormGroup>
                                    <Label for="exampleText" className='text-area'>
                                        What is your main concern today? <span>(Word Limit  100 Characters)</span>
                                    </Label>
                                    <Input
                                        name='main_concern_today'
                                        type="textarea"
                                        placeholder='Type here...'
                                        maxLength={100}
                                        rows={4}
                                        {...formik.getFieldProps("main_concern_today")}
                                        className={formik.touched.main_concern_today && formik.errors.main_concern_today ? 'is-invalid' : "null"}
                                    />
                                    {formik.touched.main_concern_today && formik.errors.main_concern_today ? <small className='validation_error'>{formik.errors.main_concern_today}</small> : ""}
                                </FormGroup>
                                <FormGroup>
                                    <div className="card-payment">
                                        <label className='card-details'>Add Card Details</label>
                                        <div className="card-number">
                                            <Input
                                                min={1}
                                                maxLength={16}
                                                type='number'
                                                name='card_number'
                                                placeholder='Enter your card number'
                                                {...formik.getFieldProps("card_number")}
                                                onKeyDown={checkSpace}
                                                onInput={(e) => (e.target.value = e.target.value.slice(0, 16))}
                                                onWheel={(e) => e.target.blur()}
                                                className={formik.touched.card_number && formik.errors.card_number ? 'is-invalid' : "null"}
                                            />
                                        </div>
                                        {formik.touched.card_number && formik.errors.card_number ? <small className='validation_error' style={{ padding: "0px 16px" }}>{formik.errors.card_number}</small> : ""}

                                        <div className="container d-flex">
                                            <div className="row">
                                                <div className="col">

                                                    <Label>Card Expiry</Label>
                                                    <Input
                                                        type="text"
                                                        name='card_expiry'
                                                        placeholder='MM/YY'
                                                        maxLength={5}
                                                        {...formik.getFieldProps("card_expiry")}


                                                        className={formik.touched.card_expiry && formik.errors.card_expiry ? 'is-invalid' : "null"}
                                                    />

                                                    {formik.touched.card_expiry && formik.errors.card_expiry ? <small className='validation_error'>{formik.errors.card_expiry}</small> : ""}
                                                </div>
                                                <div className="col">
                                                    <Label>Cvv</Label>
                                                    <Input
                                                        name='card_cvv'
                                                        type='number'
                                                        placeholder='Enter cvv code'
                                                        {...formik.getFieldProps("card_cvv")}
                                                        onKeyDown={checkSpace}
                                                        onInput={(e) => (e.target.value = e.target.value.slice(0, 3))}
                                                        onWheel={(e) => e.target.blur()}
                                                        className={formik.touched.card_cvv && formik.errors.card_cvv ? 'is-invalid' : "null"}

                                                    />
                                                    {formik.touched.card_cvv && formik.errors.card_cvv ? <small className='validation_error'>{formik.errors.card_cvv}</small> : ""}
                                                </div>
                                            </div>
                                        </div>
                                        <div className="container text-left">
                                            <div className="row">
                                                <div className="col">
                                                    <Label>Card Holder Name</Label>
                                                    <Input
                                                        name='card_holder_name'
                                                        type='text'
                                                        placeholder='Enter card holder name'
                                                        {...formik.getFieldProps("card_holder_name")}
                                                        className={formik.touched.card_holder_name && formik.errors.card_holder_name ? 'is-invalid' : "null"}
                                                    />
                                                    {formik.touched.card_holder_name && formik.errors.card_holder_name ? <small className='validation_error'>{formik.errors.card_holder_name}</small> : ""}
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <Button className='btn-secondry' type='submit'>
                                        Submit
                                    </Button>
                                </FormGroup>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <Footer />
        </>
    )
}

export default RequestNewAppointment