import React, { useState, useEffect } from 'react';
import { FormGroup, Input, Label, Form, Button } from 'reactstrap';
import { useNavigate, useLocation } from 'react-router-dom';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { checkSpace } from '../../../utils';
import authenticationServices from '../../../services';
import authenticationCpnIsServices from '../../../services/cpnIsServices';
import authenticationExpertServices from '../../../services/expertServices';
import { toast } from 'react-toastify';
import SpinnerLoader from '../../common/Spinner';

import patientOtp from '../../../assests/images/Mask Group 16.png';
import cpnLogo from '../../../assests/images/CPNHealthFINAL_fontembed.svg';
import eyeClose from '../../../assests/images/eye-closed-svgrepo-com.png';
import { ReactComponent as HideIcon } from '../../../assests/images/hide.svg';
import { ReactComponent as ShowIcon } from '../../../assests/images/view.svg';

const ResetPassword = () => {
    const navigate = useNavigate();
    const location = useLocation()
    console.log(location.state);
    const [toggleIcon, setToggleIcon] = useState(false);
    const { state } = useLocation();
    const userId = state?.userId || '';
    const comingFrom = location?.state?.comingFrom
    const [IsLoader, setIsLoader] = useState(false);

    const togglePassword = () => {
        setToggleIcon(!toggleIcon);
    };

    useEffect(() => {
        if (!userId) {
            navigate('/');
        }
    }, [state]);

    const formik = useFormik({
        initialValues: {
            password: '',
            confirmPassword: '',
        },
        validationSchema: Yup.object({
            password: Yup.string()
                .required('*Password is required')
                .matches(
                    /^(?=.*?[A-Z])(?=(.*[a-z]){1,})(?=(.*[\d]){1,})(?=(.*[\W]){1,})(?!.*\s).{8,}$/,
                    'Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character'
                ),
            confirmPassword: Yup.string()
                .required('*Confirm password is required')
                .matches(
                    /^(?=.*?[A-Z])(?=(.*[a-z]){1,})(?=(.*[\d]){1,})(?=(.*[\W]){1,})(?!.*\s).{8,}$/,
                    'Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character'
                )
                .oneOf([Yup.ref('password'), null], 'Password and Confirm password should be same'),
        }),

        onSubmit: async (values) => {
            const payload = {
                newPassword: values.password,
                userId: userId,
            };
            try {
                setIsLoader(true);
                let res;
                if (comingFrom === "cpn-login") {
                    res = await authenticationCpnIsServices.cpnResetpassword(payload);
                    if (res.data.status === 200) {
                        setIsLoader(false);
                        navigate('/login-as-cpn');
                        toast.success(res.data.message, {
                            position: toast.POSITION.TOP_RIGHT,
                        });
                    } else {
                        setIsLoader(false);
                        toast.error(res.data.message, {
                            position: toast.POSITION.TOP_RIGHT,
                        });
                    }
                } else if (comingFrom === "expert-login") {
                    res = await authenticationExpertServices.expertResetPassword(payload);
                    if (res.data.status === 200) {
                        setIsLoader(false);
                        navigate('/login-as-expert');
                        toast.success(res.data.message, {
                            position: toast.POSITION.TOP_RIGHT,
                        });
                    } else {
                        setIsLoader(false);
                        toast.error(res.data.message, {
                            position: toast.POSITION.TOP_RIGHT,
                        });
                    }
                }
                else {
                    res = await authenticationServices.patientResetpassword(payload);
                    if (res.data.status === 200) {
                        setIsLoader(false);
                        navigate('/login-as-patient');
                        toast.success(res.data.message, {
                            position: toast.POSITION.TOP_RIGHT,
                        });
                    } else {
                        setIsLoader(false);
                        toast.error(res.data.message, {
                            position: toast.POSITION.TOP_RIGHT,
                        });
                    }
                }

            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        },
    });

    return (
        <div className='patient-reset-password'>
            {IsLoader && <SpinnerLoader />}
            <div className='container-fluid'>
                <div className='image'>
                    <img src={patientOtp} alt='Patient OTP' />
                    <div className="content-image">
                        <p>The Checkpoint Now</p>
                        <h1>Consult our trusted cancer experts</h1>
                        <h6>- We understand cancer, its treatments and its side effects </h6>
                        <h6>- Make An Appointment </h6>
                    </div>
                </div>
                <div className='form'>
                    <div className='container-form-data'>
                        <div className='logo'>
                            <img src={cpnLogo} alt='CPN Logo' />
                        </div>
                        <div className="patient-form-content">
                            <div className="logo-as-patient">
                                <h1>Reset Password</h1>
                            </div>
                            <div className="logo-as-patient-para">
                                <p>
                                    Set the new password for your account so you can login
                                    and access all the features.
                                </p>
                            </div>
                            <div className="container-data-form">
                                <Form onSubmit={formik.handleSubmit}>
                                    <FormGroup className='password'>
                                        <Label for='examplePassword'>New Password</Label>
                                        <div className='input-container'>
                                            <Input
                                                placeholder='Enter Password'
                                                type={!toggleIcon ? 'password' : 'text'}
                                                onKeyDown={checkSpace}
                                                {...formik.getFieldProps('password')}
                                                invalid={formik.touched.password && formik.errors.password ? true : false}
                                            />
                                            <span className='pwdToggle' onClick={togglePassword}>
                                                {toggleIcon ? <ShowIcon /> : <HideIcon />}
                                            </span>
                                        </div>
                                        {formik.touched.password && formik.errors.password ? (
                                            <span className='validation_error'>{formik.errors.password}</span>
                                        ) : null}
                                    </FormGroup>

                                    <FormGroup className='confirm-password'>
                                        <Label for='examplePassword'>Confirm New Password</Label>
                                        <div className='input-container'>
                                            <Input
                                                placeholder='Enter Password'
                                                type={!toggleIcon ? 'password' : 'text'}
                                                onKeyDown={checkSpace}
                                                {...formik.getFieldProps('confirmPassword')}
                                                invalid={formik.touched.confirmPassword && formik.errors.confirmPassword ? true : false}
                                            />
                                            <span className='pwdToggle' onClick={togglePassword}>
                                                {toggleIcon ? <ShowIcon /> : <HideIcon />}
                                            </span>
                                        </div>
                                        {formik.touched.confirmPassword && formik.errors.confirmPassword ? (
                                            <small className='validation_error'>{formik.errors.confirmPassword}</small>
                                        ) : null}
                                    </FormGroup>

                                    <Button className='btn-secondary reset-button' type='submit'>
                                        Reset
                                    </Button>
                                </Form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ResetPassword;
