import React, { useEffect, useState } from 'react';
import Footer from '../../common/Footer/Footer';
import { Col } from 'reactstrap';
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar';
import Sidebar from '../../common/Sidebar/Sidebar';
import authenticationServices from "../../../services";
import { toast } from "react-toastify";
import SpinnerLoader from '../../common/Spinner';

const PatientFAQ = () => {
    const [IsLoader, setIsLoader] = useState(false);
    const [open, setOpen] = useState(false);
    const notesToggle = () => { setOpen(!open) };
    const [slectedTab, setslectedTab] = useState('tab1')
    const [faqData, setFaqData] = useState([]);
    const [currentPage, setCurrentPage] = useState(0);
    // const appointmentsPerPage = 5;

    const getPetientFaq = async () => {
        try {
            setIsLoader(true);
            let res = await authenticationServices.getPetientFaq();
            console.log("getPetientFaq ===>>", res);
            if (res.data.status === 200) {
                const result = res.data.faq;
                setFaqData(result);
                setIsLoader(false);
                toast.success(res.data.message, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            } else {
                setIsLoader(false);
                toast.error(res.data.message, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        } catch (error) {
            toast.error(error, {
                position: toast.POSITION.TOP_RIGHT,
            });
        }
    }

    useEffect(() => {
        getPetientFaq();
    }, []);


    return (
        <>
            <div className='patient-faq'>
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className="parent-div">
                        <Sidebar />
                        <div className="child-div">
                            <div className="container">
                                <div className="row-content">
                                    <h1>FAQ</h1>
                                    <div className="accordion" id="accordionExample">
                                        {faqData.map((faqItem, index) => (
                                            <div className="accordion-item" key={index}>
                                                <h2 className="accordion-header" id={`heading${index}`}>
                                                    <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                                        data-bs-target={`#collapse${index}`} aria-expanded="false" aria-controls={`collapse${index}`}>
                                                        {faqItem.question}
                                                    </button>
                                                </h2>
                                                <div id={`collapse${index}`} className="accordion-collapse collapse" aria-labelledby={`heading${index}`}
                                                    data-bs-parent="#accordionExample">
                                                    <div className="accordion-body">
                                                        {faqItem.answer}
                                                    </div>
                                                </div>
                                                <hr />
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Footer />
        </>
    );
}

export default PatientFAQ;

 
