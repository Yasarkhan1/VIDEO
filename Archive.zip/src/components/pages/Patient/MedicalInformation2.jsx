import React, { useState, useEffect } from 'react'
import { Table } from 'reactstrap'
import { useNavigate, Link } from 'react-router-dom'
import { Progress, Form, FormGroup, Button, Row, Label, Input, Col } from 'reactstrap'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import Logoimage from '../../../assests/images/ys.png'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import { useFormik } from 'formik'
import * as Yup from "yup";
import { toast } from "react-toastify";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { checkSpace } from "../../../utils";
import Sidebar from '../../common/Sidebar/Sidebar'
import dayjs from 'dayjs';
import 'dayjs/locale/en'; // Import the English locale
dayjs.extend(window.dayjs_plugin_customParseFormat);
// import customParseFormat from 'dayjs/plugin/customParseFormat';
// import customFormat from 'dayjs/plugin/customFormat';
// dayjs.extend(customParseFormat);
// dayjs.extend(customFormat);

function MedicalInformation2() {
    const navigate = useNavigate();
   
    const today = new Date().toISOString().split("T")[0]
    

    useEffect(() => {
        const medicalStepData = localStorage.getItem("medicalStepData")
            ? JSON.parse(localStorage.getItem("medicalStepData"))
            : "";
        
        if (medicalStepData && Object.keys(medicalStepData)?.length && medicalStepData.hasOwnProperty('medicalHistory') && medicalStepData.hasOwnProperty('pastTreatment')) {
           
            getPatchform();
        }
    }, [])

    const convertDate = (inputDate) => {
        const parsedDate = dayjs(inputDate, 'DD-MM-YYYY');
        const formattedDate = parsedDate.format('YYYY-MM-DD');
        return formattedDate;
    };

    // fill the data
    const getPatchform = () => {
        const medicalStepData = localStorage.getItem("medicalStepData")
            ? JSON.parse(localStorage.getItem("medicalStepData"))
            : "";
        // if (Object.keys(medicalStepData)?.length && Object.keys(medicalStepData?.medicalHistory)?.length && Object.keys(medicalStepData?.pastTreatment)?.length) {

            // const { medicalHistory: { type_of_cancer, year_of_diagnosis, location_of_primary_cancer, metastatic, stage_of_cancer
            //     , past_cancer_treatment, isChemotherapy, chemotherapy_date, radiation, radiation_date, surgery
            //     , surgery_date, targeted_therapies, targeted_therapies_date, immunotherapies, immunotherapies_date } } = medicalHistory
            const { medicalHistory , pastTreatment } = medicalStepData
            console.log("medicalHistory", medicalHistory ,pastTreatment);

                formik.setValues({
                    type_of_cancer: medicalHistory?.type_of_cancer ? medicalHistory?.type_of_cancer :"",
                    year_of_diagnosis: medicalHistory?.year_of_diagnosis,
                    location_of_primary_cancer: medicalHistory?.location_of_primary_cancer,
                    metastatic: medicalHistory?.metastatic,
                    stage_of_cancer: medicalHistory?.stage_of_cancer,
                    past_cancer_treatment: pastTreatment?.past_cancer_treatment,
                    isChemotherapy: pastTreatment?.isChemotherapy,
                    chemotherapy_date:convertDate(pastTreatment?.chemotherapy_date),
                    radiation: pastTreatment?.radiation,
                    radiation_date: convertDate(pastTreatment?.radiation_date),
                    surgery: pastTreatment?.surgary,
                    surgery_date: convertDate(pastTreatment?.surgary_date),
                    targeted_therapies: pastTreatment?.targeted_therapies,
                    targeted_therapies_date:convertDate(pastTreatment?.targeted_therapies_date),
                    immunotherapies: pastTreatment?.immunotherapies,
                    immunotherapies_date:convertDate(pastTreatment?.immunotherapies_date)

                });

            
        // }
    };

    const validationSchema = Yup.object().shape({
        type_of_cancer: Yup.string().required('Please select.'),
        year_of_diagnosis: Yup.string().required('Please select.'),
        location_of_primary_cancer: Yup.string().required("Enter loctaion."),
        metastatic: Yup.string().required("Please select."),
        stage_of_cancer: Yup.string().required("Please select state."),
        past_cancer_treatment: Yup.string().required('Enter type cancer.'),
        isChemotherapy: Yup.string().required("Enter type cancer."),
        // chemotherapy_date: Yup.string().required("Please select."),
        radiation: Yup.string().required("Please select."),
        // radiation_date: Yup.string().required("Please select date. "),
        surgery: Yup.string().required("Select date."),
        // surgery_date: Yup.string().required("Please Select Date."),
        targeted_therapies: Yup.string().required("Please Select. "),
        // targeted_therapies_date: Yup.string().required("Please Select Date. "),
        immunotherapies: Yup.string().required("Please select."),
        // immunotherapies_date: Yup.string().required("Please Enter date."),
        chemotherapy_date: Yup.string().test(
            'isRequired',
            'Select Date',
            function (value) {
                const { isChemotherapy } = this.parent;
                if (isChemotherapy === 'YES') {
                    return Yup.string().required().isValidSync(value);
                }
                return true;
            }
        ),
        radiation_date: Yup.string().test(
            'isRequired',
            'Select Date',
            function (value) {
                const { radiation } = this.parent;
                if (radiation === 'YES') {
                    return Yup.string().required().isValidSync(value);
                }
                return true;
            }
        ),
        surgery_date: Yup.string().test(
            'isRequired',
            'Select Date',
            function (value) {
                const { surgery } = this.parent;
                if (surgery === 'YES') {
                    return Yup.string().required().isValidSync(value);
                }
                return true;
            }
        ),
        targeted_therapies_date: Yup.string().test(
            'isRequired',
            'Select Date',
            function (value) {
                const { targeted_therapies } = this.parent;
                if (targeted_therapies === 'YES') {
                    return Yup.string().required().isValidSync(value);
                }
                return true;
            }
        ),
        immunotherapies_date:Yup.string().test(
            'isRequired',
            'Select Date',
            function (value) {
                const { immunotherapies } = this.parent;
                if (immunotherapies === 'YES') {
                    return Yup.string().required().isValidSync(value);
                }
                return true;
            }
        ),

    });
    const formik = useFormik({
        initialValues: {
            type_of_cancer: '',
            year_of_diagnosis: '',
            location_of_primary_cancer: '',
            metastatic: '',
            stage_of_cancer: '',
            past_cancer_treatment: '',
            isChemotherapy: '',
            chemotherapy_date: '',
            radiation: '',
            radiation_date: '',
            surgery: '',
            surgery_date: '',
            targeted_therapies: '',
            targeted_therapies_date: '',
            immunotherapies: '',
            immunotherapies_date: '',
            isChemotherapyCheck: "NO",
            radiationCheck: "NO",
            surgeryCheck: "NO",
            targeted_therapiesCheck:"NO",
            immunotherapiesCheck:"NO",


        },
        validationSchema: validationSchema,
        onSubmit: async (values) => {
            // const step1Data = localStorage.getItem("medicalHistory")
            //     ? JSON.parse(localStorage.getItem("medicalHistory"))
            //     : "";
            // const { type_of_cancer, year_of_diagnosis } = step1Data
            const previousFormData=localStorage.getItem("medicalStepData")
            ? JSON.parse(localStorage.getItem("medicalStepData"))
            : "";

            const payload = {
                ...previousFormData,
                
                medicalHistory:{
                    type_of_cancer: values.type_of_cancer,
                    year_of_diagnosis: values.year_of_diagnosis,
                    location_of_primary_cancer:values.location_of_primary_cancer,
                    metastatic: values.metastatic,
                    stage_of_cancer: values.stage_of_cancer,
                },
                pastTreatment:{
                    "past_cancer_treatment":values.past_cancer_treatment,
                    "isChemotherapy": values.isChemotherapy,
                    "chemotherapy_date":values.chemotherapy_date ? dayjs(values.chemotherapy_date).format('DD-MM-YYYY') : "NULL",
                    "radiation":values.radiation,
                    "radiation_date":values.radiation_date ? dayjs(values.radiation_date).format('DD-MM-YYYY'): "NULL",
                    "surgary":values.surgery,
                    "surgary_date":values.surgery_date ? dayjs(values.surgery_date).format('DD-MM-YYYY') : "NULL",
                    "targeted_therapies":values.targeted_therapies,
                    "targeted_therapies_date":values.targeted_therapies_date ? dayjs(values.targeted_therapies_date).format('DD-MM-YYYY') : "NULL",
                    "immunotherapies":values.immunotherapies,
                    "immunotherapies_date":values.immunotherapies_date ? dayjs(values.immunotherapies_date).format('DD-MM-YYYY') : "NULL",
                    }
                

            };
            console.log("payload")


            try {
                console.log("medicalHistory payload=", payload);
                // localStorage.setItem("medicalHistory", JSON.stringify(payload));
                localStorage.setItem("medicalStepData", JSON.stringify(payload));
                navigate("/medical-information3")
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        }


    });
    const handleSelectChange = (e) => {
        console.log("e.target.value==", e.target.name);
        const name = e.target.name
        const value = e.target.value;

        if (name === "isChemotherapy") {
            formik.setFieldValue('isChemotherapy', value);
            // setAlcoholCheck(event.target.value === 'Yes');
            if (e.target.value === 'No') {
                formik.setFieldValue('chemotherapy_date', '');
                formik.setFieldError('chemotherapy_date', '');
                formik.setFieldTouched('chemotherapy_date', false);

            }
        }
        if (name === "radiation") {
            formik.setFieldValue('radiation', value);
            if (e.target.value === "NO") {
                formik.setFieldValue('radiation_date', '');
                formik.setFieldError('radiation_date', '');
                formik.setFieldTouched('radiation_date', false);
            }
        }
        if (name === "radiation") {
            formik.setFieldValue('radiation', value);
            if (e.target.value === "NO") {
                formik.setFieldValue('radiation_date', '');
                formik.setFieldError('radiation_date', '');
                formik.setFieldTouched('radiation_date', false);
            }
        }
        if (name === "surgery") {
            formik.setFieldValue('surgery', value);
            if (e.target.value === "NO") {
                formik.setFieldValue('surgery_date', '');
                formik.setFieldError('surgery_date', '');
                formik.setFieldTouched('surgery_date', false);
            }
        }

        if (name === "targeted_therapies") {
            formik.setFieldValue('targeted_therapies', value);
            if (e.target.value === "NO") {
                formik.setFieldValue('targeted_therapies_date', '');
                formik.setFieldError('targeted_therapies_date', '');
                formik.setFieldTouched('targeted_therapies_date', false);
            }
        }
        if (name === "targeted_therapies") {
            formik.setFieldValue('targeted_therapies', value);
            if (e.target.value === "NO") {
                formik.setFieldValue('targeted_therapies_date', '');
                formik.setFieldError('targeted_therapies_date', '');
                formik.setFieldTouched('targeted_therapies_date', false);
            }
        }

        if (name === "immunotherapies") {
            formik.setFieldValue('immunotherapies', value);
            if (e.target.value === "NO") {
                formik.setFieldValue('immunotherapies_date', '');
                formik.setFieldError('immunotherapies_date', '');
                formik.setFieldTouched('immunotherapies_date', false);
            }
        }
    }
    console.log("formik", formik.errors)

   
    return (
        <>
            <div className='medical-information2'>
                <LoginNavbar />
                <div className="container mb-5">
                    <div className="parent-div">
                        <Sidebar />

                        <div className="child-div">
                            <div className="progress-bar-container">
                                <div className="progress-bar">
                                    <span>1</span>
                                </div>

                            </div>
                            <div className="middle-content">
                                <Form onSubmit={formik.handleSubmit}>
                                    <h1>Medical History</h1>
                                    <Row>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleText">
                                                    Type of Cancer
                                                </Label>
                                                <Input
                                                    id="exampleText"
                                                    name="type_of_cancer"
                                                    placeholder="Enter Type of Cancer"
                                                    type="text"
                                                    {...formik.getFieldProps("type_of_cancer")}
                                                    className={formik.touched.type_of_cancer && formik.errors.type_of_cancer ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.type_of_cancer && formik.errors.type_of_cancer ? <small className="validation_error">{formik.errors.type_of_cancer}</small> : null}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleDate">
                                                    Years of Diagnosis
                                                </Label>
                                                <Input
                                                    id="exampleSelect"
                                                    name="year_of_diagnosis"
                                                    type="select"
                                                    {...formik.getFieldProps("year_of_diagnosis")}
                                                    className={formik.touched.year_of_diagnosis && formik.errors.year_of_diagnosis ? 'is-invalid' : ""}
                                                >
                                                    <option>Select Year</option>
                                                    <option>2022 </option>
                                                    <option>2021 </option>
                                                    <option>2020 </option>
                                                    <option>2021 </option>
                                                </Input>
                                                {formik.touched.year_of_diagnosis && formik.errors.year_of_diagnosis ? <small className="validation_error">{formik.errors.year_of_diagnosis}</small> : null}
                                            </FormGroup>
                                        </Col>
                                    </Row>

                                    <Row>
                                        <Col md={6} >
                                            <FormGroup>
                                                <Label for="exampleSelect">
                                                    Location of Primary Cancer
                                                </Label>
                                                <Input
                                                    id="exampleText"
                                                    name="location_of_primary_cancer"
                                                    placeholder="Enter Location of Primary Cancer"
                                                    type="text"
                                                    {...formik.getFieldProps("location_of_primary_cancer")}
                                                    className={formik.touched.location_of_primary_cancer && formik.errors.location_of_primary_cancer ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.location_of_primary_cancer && formik.errors.location_of_primary_cancer ? <small className="validation_error">{formik.errors.location_of_primary_cancer}</small> : null}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleText">
                                                    Metastatic
                                                </Label>
                                                <Input
                                                    id="exampleSelect"
                                                    name="metastatic"
                                                    type="select"
                                                    {...formik.getFieldProps("metastatic")}
                                                    className={formik.touched.metastatic && formik.errors.metastatic ? 'is-invalid' : ""}
                                                >
                                                    <option>
                                                        Select Yes or No
                                                    </option>
                                                    <option value="Yes">Yes</option>
                                                    <option value="No">No</option>
                                                </Input>
                                                {formik.touched.metastatic && formik.errors.metastatic ? <small className="validation_error">{formik.errors.metastatic}</small> : null}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleText">
                                                    Stage
                                                </Label>
                                                <Input
                                                    id="exampleSelect"
                                                    name="stage_of_cancer"
                                                    type="select"
                                                    {...formik.getFieldProps("stage_of_cancer")}
                                                    className={formik.touched.stage_of_cancer && formik.errors.stage_of_cancer ? 'is-invalid' : ""}
                                                >
                                                    <option style={{ color: "#C9C9C9" }}>Select stage</option>
                                                    <option>1</option>
                                                    <option>2</option>
                                                    <option>3</option>
                                                </Input>
                                                {formik.touched.stage_of_cancer && formik.errors.stage_of_cancer ? <small className='validation_error'>{formik.errors.stage_of_cancer}</small> : null}
                                            </FormGroup>
                                        </Col>
                                    </Row>

                                    <h2>Past Treatment</h2>

                                    <Row>

                                        <Col md={6}>
                                            <Label for="exampleText">
                                                Past Cancer Treatment <span>(With Duration)</span>
                                            </Label>
                                            <FormGroup>
                                                <Input
                                                    id="exampleText"
                                                    name="past_cancer_treatment"
                                                    placeholder="Enter Type of Cancer"
                                                    type="text"
                                                    {...formik.getFieldProps("past_cancer_treatment")}
                                                    className={formik.touched.past_cancer_treatment && formik.errors.past_cancer_treatment ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.past_cancer_treatment && formik.errors.past_cancer_treatment ? <small className='validation_error'>{formik.errors.past_cancer_treatment}</small> : null}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>

                                            <Label>Chemotherapy <span>(Yes/No (Date))</span></Label>
                                            <Row>
                                                <Col md={6}>
                                                    <FormGroup>
                                                        <Input
                                                            id="exampleText"
                                                            name="isChemotherapy"
                                                            placeholder="Enter Type of Cancer"
                                                            type="select"
                                                            onChange={handleSelectChange}
                                                            {...formik.getFieldProps("isChemotherapy")}
                                                            className={formik.touched.isChemotherapy && formik.errors.isChemotherapy ? 'is-invalid' : ""}
                                                        >
                                                            <option value="Select">Select Yes or No</option>
                                                            <option value="YES">Yes</option>
                                                            <option value="NO">No</option>

                                                        </Input>

                                                        {formik.touched.isChemotherapy && formik.errors.isChemotherapy ? <small className='validation_error'>{formik.errors.isChemotherapy}</small> : null}
                                                    </FormGroup>

                                                </Col>

                                                <Col md={6}>
                                                    {/* <Label><br /></Label> */}
                                                    <FormGroup>
                                                        {formik.values.isChemotherapy === 'YES' &&
                                                            <>
                                                                <Input
                                                                    id="exampleText"
                                                                    name="chemotherapy_date"
                                                                    placeholder="Enter Type of Cancer"
                                                                    type="date"
                                                                    max={today}
                                                                    {...formik.getFieldProps("chemotherapy_date")}
                                                                    className={formik.touched.chemotherapy_date && formik.errors.chemotherapy_date ? 'is-invalid' : ""}
                                                                />
                                                                {formik.touched.chemotherapy_date && formik.errors.chemotherapy_date ? <small className='validation_error'>{formik.errors.chemotherapy_date}</small> : null}
                                                            </>}
                                                    </FormGroup>

                                                </Col>
                                            </Row>
                                        </Col>



                                    </Row>
                                    <Row>

                                        <Col md={3}>
                                            <FormGroup>
                                                <Label>Radiation <span>(Yes/No (Date))</span></Label>
                                                <Input
                                                    id="exampleSelect"
                                                    name="radiation"
                                                    type="select"
                                                    onChange={handleSelectChange}
                                                    {...formik.getFieldProps("radiation")}
                                                    className={formik.touched.radiation && formik.errors.radiation ? 'is-invalid' : ""}
                                                >
                                                    <option>Select Yes or No</option>
                                                    <option value="YES">Yes </option>
                                                    <option value="NO">No</option>
                                                </Input>
                                                {formik.touched.radiation && formik.errors.radiation ? <small className='validation_error'>{formik.errors.radiation}</small> : null}
                                            </FormGroup>

                                        </Col>

                                        <Col md={3}>
                                            <Label><br /></Label>
                                            <FormGroup>
                                                {formik.values.radiation === 'YES' &&
                                                    <>
                                                        <Input
                                                            id="exampleDate"
                                                            name="radiation_date"
                                                            placeholder="date placeholder"
                                                            type="date"
                                                            min="1970-01-01"
                                                            max={today}
                                                            {...formik.getFieldProps("radiation_date")}
                                                            className={formik.touched.radiation_date && formik.errors.radiation_date ? 'is-invalid' : ""}
                                                        />

                                                        {formik.touched.radiation_date && formik.errors.radiation_date ? <small className='validation_error'>{formik.errors.radiation_date}</small> : null}
                                                    </>}
                                            </FormGroup>

                                        </Col>


                                        <Col md={3}>

                                            <FormGroup>
                                                <Label>Surgery <span>(Yes/No (Date))</span></Label>
                                                <Input
                                                    id="exampleSelect"
                                                    name="surgery"
                                                    type="select"
                                                    onChange={handleSelectChange}
                                                    {...formik.getFieldProps("surgery")}
                                                    className={formik.touched.surgery && formik.errors.surgery ? 'is-invalid' : ""}
                                                >
                                                    <option>Select Yes or No</option>
                                                    <option value="YES">Yes</option>
                                                    <option value="No">No</option>
                                                </Input>
                                                {formik.touched.surgery && formik.errors.surgery ? <small className='validation_error'>{formik.errors.surgery}</small> : null}

                                            </FormGroup>
                                        </Col>
                                        <Col md={3}>
                                            <Label><br /></Label>
                                            <FormGroup>

                                                {formik.values.surgery === 'YES' &&
                                                    <>
                                                        <Input
                                                            id="exampleDate"
                                                            name="surgery_date"
                                                            placeholder="date placeholder"
                                                            max={today}
                                                            min="1970-01-01"
                                                            type="date"
                                                            {...formik.getFieldProps("surgery_date")}
                                                            className={formik.touched.surgery_date && formik.errors.surgery_date ? 'is-invalid' : ""}
                                                        />
                                                        {/* <DatePicker
                                                    selected={dob}
                                                    placeholderText="Select date"
                                                    dateFormat="dd/MM/yyyy"
                                                    showIcon={true}
                                                    // required
                                                    minDate={new Date()}
                                                    showYearDropdown={true}
                                                    isClearable={dob}
                                                    // className="form-control"
                                                    name="surgery_date"
                                                    {...formik.getFieldProps("surgery_date")}
                                                    // withPortal
                                                    className={formik.touched.surgery_date && formik.errors.surgery_date ? 'is-invalid form-control' : "form-control"}
                                                    onChange={(date) => { setDob(date); formik.setFieldValue("surgery_date", date) }} //only when value has changed
                                                /> */}
                                                        {formik.touched.surgery_date && formik.errors.surgery_date ? <small className='validation_error'>{formik.errors.surgery_date}</small> : null}
                                                    </>}
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <Row>

                                        <Col md={6}>

                                            <Label>Targeted Therapies <span>(Yes/No (Date))</span></Label>
                                            <Row>
                                                <Col md={6}>
                                                    <FormGroup>
                                                        <Input
                                                            id="exampleText"
                                                            name="targeted_therapies"
                                                            placeholder="Enter Type of Cancer"
                                                            type="select"
                                                            onChange={handleSelectChange}
                                                            {...formik.getFieldProps("targeted_therapies")}
                                                            className={formik.touched.targeted_therapies && formik.errors.targeted_therapies ? 'is-invalid' : ""}
                                                             >
                                                            <option value="Select">Select</option>
                                                            <option value="YES">Yes</option>
                                                            <option value="NO">No</option>

                                                        </Input>

                                                        {formik.touched.targeted_therapies && formik.errors.targeted_therapies ? <small className='validation_error'>{formik.errors.targeted_therapies}</small> : null}
                                                    </FormGroup>

                                                </Col>

                                                <Col md={6}>
                                                    {/* <Label><br /></Label> */}
                                                    <FormGroup>
                                                        {formik.values.targeted_therapies === 'YES' &&
                                                            <>
                                                                <Input
                                                                    id="exampleText"
                                                                    name="targeted_therapies_date"
                                                                    placeholder="Enter Type of Cancer"
                                                                    type="date"
                                                                    min="1970-01-01"
                                                                    max={today}
                                                                    {...formik.getFieldProps("targeted_therapies_date")}
                                                                    className={formik.touched.targeted_therapies_date && formik.errors.targeted_therapies_date ? 'is-invalid' : ""}
                                                                />
                                                                {formik.touched.targeted_therapies_date && formik.errors.targeted_therapies_date ? <small className='validation_error'>{formik.errors.targeted_therapies_date}</small> : null}
                                                            </>}
                                                    </FormGroup>

                                                </Col>
                                            </Row>
                                        </Col>



                                        <Col md={6}>

                                            <Label>Immunotherapies <span>(Yes/No (Date))</span></Label>
                                            <Row>
                                                <Col md={6}>
                                                    <FormGroup>
                                                        <Input
                                                            id="exampleText"
                                                            name="immunotherapies"
                                                            placeholder="Enter Type of Cancer"
                                                            type="select"
                                                            onChange={handleSelectChange}
                                                            {...formik.getFieldProps("immunotherapies")}
                                                            className={formik.touched.immunotherapies && formik.errors.immunotherapies ? 'is-invalid' : ""}
                                                        >
                                                            <option value="Select">Select</option>
                                                            <option value="YES">Yes</option>
                                                            <option value="NO">No</option>

                                                        </Input>

                                                        {formik.touched.immunotherapies && formik.errors.immunotherapies ? <small className='validation_error'>{formik.errors.immunotherapies}</small> : null}
                                                    </FormGroup>

                                                </Col>

                                                <Col md={6}>
                                                    {/* <Label><br /></Label> */}
                                                    <FormGroup>
                                                    {formik.values.immunotherapies === 'YES' &&
                                                            <>
                                                        <Input
                                                            id="exampleText"
                                                            name="immunotherapies_date"
                                                            placeholder="Enter Type of Cancer"
                                                            type="date"
                                                            min="1970-01-01"
                                                            max={today}
                                                            {...formik.getFieldProps("immunotherapies_date")}
                                                            className={formik.touched.immunotherapies_date && formik.errors.immunotherapies_date ? 'is-invalid' : ""}
                                                        />
                                                        {formik.touched.immunotherapies_date && formik.errors.immunotherapies_date ? <small className='validation_error'>{formik.errors.immunotherapies_date}</small> : null}
                                                    </>}
                                                    </FormGroup>

                                                </Col>
                                            </Row>
                                        </Col>

                                    </Row>

                                    <Button className='btn-secondry' type='submit'>
                                        Next
                                    </Button>
                                </Form>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <Footer />


        </>
    )
}

export default MedicalInformation2
