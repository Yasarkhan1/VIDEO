import React, { useState, useEffect } from 'react';
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import Sidebar from '../../common/Sidebar/Sidebar'
import { FormGroup, Form, Button, Input, Label, Col, Row } from 'reactstrap'
import { Formik, useFormik } from 'formik'
import Plus from '../../../assests/images/plus-solid.svg'
import PDFImage from '../../../assests/images/pdf-file.svg'
import AppointNavbar from '../../common/AppointmentNavbar/AppointNavbar'
import Footer from '../../common/Footer/Footer'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import dayjs from "dayjs";
import authenticationServices from "../../../services";
import { useSelector } from 'react-redux';
import * as Yup from 'yup';
import { toast } from "react-toastify";
import SpinnerLoader from '../../common/Spinner'
import { ReactComponent as CrossIcon } from "../../../assests/images/close-circle-svgrepo-com.svg";

const validationSchema = Yup.object().shape({
    // medicationName: Yup.string().required('Name of Medication is required'),
    // allergyName: Yup.string().required('Name of Allergy is required'),
    // labName: Yup.string().required('Lab Name is required'),
    // labDetails: Yup.string().required('Lab Details is required'),
    // imagingDetails: Yup.string().required('Imaging Details is required'),
    // otherDetails: Yup.string().required('Other Details is required'),
});

function NewAppointment6() {
    const location = useLocation()
    const navigate = useNavigate()
    const [IsLoader, setIsLoader] = useState(false);
    const appointmentId = location?.state?.appointmentId
    const [uploadedDocs, setUploadedDocs] = useState({
        lab: [],
        imaging: [],
        other: [],
    });

    // useEffect to redirect step 1 if previous form not submitted
    // useEffect(() => {
    //     if (appointmentId === '' || appointmentId === undefined) {
    //         navigate("/new-appointment-1")
    //     }
    // }, [appointmentId])


    const formik = useFormik({
        initialValues: {
            medicationName: '',
            allergyName: '',
            labName: '',
            labDetails: '',
            imagingDetails: '',
            otherDetails: '',
        },
        validationSchema: validationSchema,
        onSubmit: async (values) => {
            // Handle form submission
            console.log(values);
            try {

                setIsLoader(true);
                const formData = new FormData();
                formData.append("allergyMedication", values.medicationName);
                formData.append("allergy", values.allergyName);
                formData.append("labName", values.labName);
                formData.append("labDetails", values.labDetails);
                // formData.append("labAttachments", uploadedDocs.lab);
                uploadedDocs.lab.forEach((item, i) => {
                    formData.append(("labAttachments" + '[' + i + ']'), item);
                });
                uploadedDocs.imaging.forEach((item, i) => {
                    formData.append(("imageAttachments" + '[' + i + ']'), item);
                });
                uploadedDocs.other.forEach((item, i) => {
                    formData.append(("additionalAttachments" + '[' + i + ']'), item);
                });
                formData.append("imagingDetails", values.imagingDetails);
                formData.append("additionalImagingDetails", values.otherDetails);

                formData.append("appointmentId", appointmentId)
                // formData.append("additionalDetails", values.otherDetails)


                let res = await authenticationServices.appointmentBookStep6(formData);
                console.log("appointmentBook step 6 result==", res);
                if (res.data.status === 200) {
                    const appointmentId = res.data.data.appointmentId
                    setIsLoader(false);
                    toast.success(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                    // navigate("/")
                    navigate("/new-appointment-7", { state: { appointmentId: appointmentId }, replace: true })
                } else {
                    setIsLoader(false);
                    toast.error(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                }
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        },
    });
    // console.log("uploadedDocLab=-==", uploadedDocs);
    const handleFileUpload = (event) => {
        const file = event.target.files[0];
        const name = event.target.name;
        if (file) {
            setUploadedDocs((prevState) => {
                let updatedFiles = [...prevState[name], file]; // Add the new file to the array
                return {
                    ...prevState,
                    [name]: updatedFiles,
                };
            });
        }
    };

    const handleFileLabRemove = (index) => {
        setUploadedDocs((prevState) => {
            let updatedFiles = [...prevState.lab];
            updatedFiles.splice(index, 1); // Remove the file at the given index
            return {
                ...prevState,
                lab: updatedFiles,
            };
        });
    };

    const handleFileImagingRemove = (index) => {
        setUploadedDocs((prevState) => {
            let updatedFiles = [...prevState.imaging];
            updatedFiles.splice(index, 1); // Remove the file at the given index
            return {
                ...prevState,
                imaging: updatedFiles,
            };
        });
    };

    const handleFileOtherRemove = (index) => {
        setUploadedDocs((prevState) => {
            let updatedFiles = [...prevState.other];
            updatedFiles.splice(index, 1); // Remove the file at the given index
            return {
                ...prevState,
                other: updatedFiles,
            };
        });
    };
    return (
        <>
            <div className="new-appointment6">
                {IsLoader && <SpinnerLoader />}
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className=" parent-div">
                        <Sidebar />
                        <div className=" child-div">
                            <div className="child-navabar">
                                <AppointNavbar />
                            </div>

                            <div className="form-groupes">
                                <div className="header-heading">
                                    <h1>Allergies from Medicines</h1>
                                </div>
                                <Form onSubmit={formik.handleSubmit}>
                                    <Row>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label >
                                                    Name of Medication
                                                </Label>
                                                <Input
                                                    id="medicationName"
                                                    type="text"
                                                    {...formik.getFieldProps('medicationName')}
                                                    className={formik.touched.medicationName && formik.errors.medicationName ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.medicationName && formik.errors.medicationName ? (
                                                    <div className="validation_error">{formik.errors.medicationName}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label >
                                                    Name of Allergy
                                                </Label>
                                                <Input
                                                    id="allergyName"
                                                    type="text"
                                                    {...formik.getFieldProps('allergyName')}
                                                    className={formik.touched.allergyName && formik.errors.allergyName ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.allergyName && formik.errors.allergyName ? (
                                                    <div className="validation_error">{formik.errors.allergyName}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>

                                    </Row>
                                    {/* Second Row Start */}
                                    <div className="header-heading">
                                        <h1>Labs</h1>
                                    </div>
                                    <Row>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label >
                                                    Lab Name
                                                </Label>
                                                <Input
                                                    id="labName"
                                                    type="text"
                                                    {...formik.getFieldProps('labName')}
                                                    className={formik.touched.labName && formik.errors.labName ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.labName && formik.errors.labName ? (
                                                    <div className="validation_error">{formik.errors.labName}</div>
                                                ) : null}

                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <Label>Documents Attachment</Label>
                                            <div style={{ display: 'flex', alignItems: 'center', overflowX: 'auto' }}>
                                                <section className='upload-file mx-2'>
                                                    <input
                                                        type="file"
                                                        name="lab"
                                                        accept="image/*,.pdf,.txt,.doc"
                                                        onChange={handleFileUpload}
                                                        style={{ display: 'none' }}
                                                    />
                                                    <span onClick={() => document.querySelector('input[type="file"]').click()}>
                                                        <img src={Plus} alt="Upload" />
                                                    </span>
                                                </section>
                                                <div style={{ display: 'flex', alignItems: 'center', overflowX: 'auto' }}>
                                                    {uploadedDocs.lab?.map((file, index) => (
                                                        <div key={index} className="uploaded-pdf" >
                                                            {file.type.includes('image') ? (
                                                                <img src={URL.createObjectURL(file)} alt="Uploaded" />
                                                            ) : (
                                                                <img src={PDFImage} alt="Uploaded" />
                                                            )}
                                                            <span className="remove-icon" onClick={() => handleFileLabRemove(index)}>
                                                                {/* <img src={CrossIcon} alt="Remove" /> */}
                                                                <CrossIcon />
                                                            </span>
                                                        </div>
                                                    ))}
                                                </div>

                                            </div>
                                        </Col>
                                    </Row>
                                    {/* Third Row Start */}
                                    <Row>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label>Lab Details</Label>

                                                <Input
                                                    placeholder='type here....'
                                                    id="labDetails"
                                                    type="textarea"
                                                    {...formik.getFieldProps('labDetails')}
                                                    className={formik.touched.labDetails && formik.errors.labDetails ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.labDetails && formik.errors.labDetails ? (
                                                    <div className="validation_error">{formik.errors.labDetails}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>

                                    </Row>
                                    {/* Second Last Div */}
                                    <div className="header-heading-past">
                                        <h1>Imaging</h1>
                                    </div>
                                    <Row>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label >
                                                    Imaging Details
                                                </Label>
                                                <Input
                                                    id="imagingDetails"
                                                    type="textarea"
                                                    {...formik.getFieldProps('imagingDetails')}
                                                    className={formik.touched.imagingDetails && formik.errors.imagingDetails ? 'is-invalid' : ""}
                                                    placeholder='type here....'
                                                />
                                                {formik.touched.imagingDetails && formik.errors.imagingDetails ? (
                                                    <div className="validation_error">{formik.errors.imagingDetails}</div>
                                                ) : null}

                                            </FormGroup>
                                        </Col>
                                        {/* Upload-File */}
                                        <Col md={6}>
                                            <Label>Documents Attachment</Label>
                                            <div style={{ display: 'flex', alignItems: 'center' }}>
                                                <section className='upload-file'>
                                                    <input
                                                        type="file"
                                                        accept="image/*,.pdf,.txt,.doc"
                                                        name='imaging'
                                                        onChange={handleFileUpload}
                                                        style={{ display: 'none' }}
                                                    />
                                                    <span onClick={() => document.querySelector('input[name="imaging"]').click()}>
                                                        <img src={Plus} alt="Upload" />
                                                    </span>
                                                </section>
                                                <div style={{ display: 'flex', alignItems: 'center', overflowX: 'auto' }}>
                                                    {uploadedDocs.imaging?.map((file, index) => (
                                                        <div key={index} className="uploaded-pdf" >
                                                            {file.type.includes('image') ? (
                                                                <img src={URL.createObjectURL(file)} alt="Uploaded" />
                                                            ) : (
                                                                <img src={PDFImage} alt="Uploaded" />
                                                            )}
                                                            <span className="remove-icon" onClick={() => handleFileImagingRemove(index)}>
                                                                {/* <img src={CrossIcon} alt="Remove" /> */}
                                                                <CrossIcon />
                                                            </span>
                                                        </div>
                                                    ))}
                                                </div>
                                            </div>
                                        </Col>


                                    </Row>
                                    {/* Second Row Start */}
                                    <div className="header-heading-past">
                                        <h1>Other Additional Information</h1>
                                    </div>
                                    <Row>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label >
                                                    Imaging Details
                                                </Label>
                                                <Input
                                                    id="otherDetails"
                                                    type="textarea"
                                                    {...formik.getFieldProps('otherDetails')}
                                                    className={formik.touched.otherDetails && formik.errors.otherDetails ? 'is-invalid' : ""}
                                                    placeholder='type here....'
                                                />
                                                {formik.touched.otherDetails && formik.errors.otherDetails ? (
                                                    <div className="validation_error">{formik.errors.otherDetails}</div>
                                                ) : null}

                                            </FormGroup>
                                        </Col>

                                        <Col md={6}>
                                            <Label>Documents Attachment</Label>
                                            <div style={{ display: 'flex', alignItems: 'center' }}>
                                                <section className='upload-file'>
                                                    <input
                                                        type="file"
                                                        name='other'
                                                        accept="image/*,.pdf,.txt,.doc"
                                                        onChange={handleFileUpload}
                                                        style={{ display: 'none' }}
                                                    />
                                                    <span onClick={() => document.querySelector('input[name="other"]').click()}>
                                                        <img src={Plus} alt="Upload" />
                                                    </span>
                                                </section>
                                                <div style={{ display: 'flex', alignItems: 'center', overflowX: 'auto' }}>
                                                    {uploadedDocs.other?.map((file, index) => (
                                                        <div key={index} className="uploaded-pdf" >
                                                            {file.type.includes('image') ? (
                                                                <img src={URL.createObjectURL(file)} alt="Uploaded" />
                                                            ) : (
                                                                <img src={PDFImage} alt="Uploaded" />
                                                            )}
                                                            <span className="remove-icon" onClick={() => handleFileOtherRemove(index)}>
                                                                {/* <img src={CrossIcon} alt="Remove" /> */}
                                                                <CrossIcon />
                                                            </span>
                                                        </div>
                                                    ))}
                                                </div>
                                            </div>
                                        </Col>


                                    </Row>
                                    <div className="button-container">
                                        {/* <Link to={'/new-appointment-7'}> */}
                                        <Button color="primary" className='next-button'>
                                            Next
                                        </Button>
                                        {/* </Link> */}

                                    </div>
                                </Form>


                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <Footer />

        </>
    )
}

export default NewAppointment6
