import React, { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Row, Modal, ModalHeader, ModalBody, ModalFooter, Input, Button, Col } from 'reactstrap'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import Logoimage from '../../../assests/images/ys.png'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import Sidebar from '../../common/Sidebar/Sidebar'
import authenticationServices from "../../../services";





function PatientMeassage() {
    const [open1, setOpen] = useState(false);
    const toggle = () => { setOpen(!open1) };
    









   
    return (
        <>

            <div className='patient-messages'>
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className="parent-div">
                        <Sidebar />
                        <div className="child-div">
                            <div className="Initiate-message-button">
                                <button className='btn-initiate' onClick={toggle}>Initiate Message</button>
                            </div>
                            <Row className='text-detail-content'>

                                <Col md={3}>

                                    <div className="text-patient-left">
                                        <h5>Patient</h5>
                                        <h6>(10/08/23, 11:30Am)</h6>
                                    </div>
                                </Col>
                                <Col md={6}>
                                    <div className="text-patient-right">
                                        <h6>I want to book appointment for cancer treatment asap.</h6>

                                    </div>
                                </Col>
                                <Col md={3}>
                                    <div className="text-view-message">
                                        <Link to={"/patient-view-message"}>
                                            <i className="fa fa-edit fa-lg"></i>
                                        </Link>
                                    </div>
                                </Col>

                            </Row>


                        </div>
                    </div>
                </div>
            </div>
            <Footer />
            <div>
                <Modal isOpen={open1} toggle={toggle} className="custom-modal" centered>
                    <div className="modal-overlay">
                        <ModalHeader toggle={toggle} />
                        <ModalBody>
                            <div>
                                <h5 style={{ marginLeft: "5px" }}>Subject</h5>
                                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                                    <Input
                                        style={{ height: "37px" }}
                                        id='exampleSelect'
                                        type='select'

                                    >
                                        <option value="">Select Subject</option>
                                        <option value="">ja</option>
                                        <option value="">Va</option>


                                    </Input>


                                </div>
                                <h5 style={{ marginTop: "10px", marginLeft: "5px" }}>Description</h5>
                                <Input
                                    type='textarea'
                                    rows={6}
                                    placeholder='type here...'
                                />
                                <div >
                                    <Button className='initialbutton' onClick={() => { toggle() }}>Submit</Button>

                                </div>
                            </div>
                        </ModalBody>
                    </div>
                </Modal>
            </div>
        </>
    )
}

export default PatientMeassage
