import React, { useState, useEffect } from 'react'
import { FormGroup, Input, Label, Form, FormText, Button } from 'reactstrap';
import cpnLogo from "../../../assests/images/CPNHealthFINAL_fontembed.svg";
import patinetImage from "../../../assests/images/Mask Group 10.png";
import { useNavigate, Link } from 'react-router-dom';
import { ReactComponent as HideIcon } from "../../../assests/images/hide.svg";
import { ReactComponent as ShowIcon } from "../../../assests/images/view.svg";
import { useFormik } from "formik";
import * as Yup from "yup";
import { checkSpace, saveToSessionStorage, detectPlatform } from "../../../utils";
import authenticationServices from "../../../services";
import { toast } from "react-toastify";
import { useDispatch } from 'react-redux';
import { setUser } from '../../../stateManagement/userSlice';
import SpinnerLoader from '../../common/Spinner';
import { deviceToken } from "../../../getDeviceToken";

const PatientLogin = () => {

    const dispatch = useDispatch();
    const navigate = useNavigate()
    const [rememberME, setRememberME] = useState(false);
    const [IsLoader, setIsLoader] = useState(false);
    const [toggleIcon, setToggleIcon] = useState(false)

    const togglePassword = () => {
        setToggleIcon(!toggleIcon)
    }
    const deviceType = detectPlatform()
    let devicetoken = "";
    deviceToken.subscribe((res) => {
        devicetoken = res;
    });


    const formik = useFormik({
        initialValues: {
            email: localStorage.getItem("emailID") ? localStorage.getItem("emailID") : "",
            password: localStorage.getItem("password") ? window.atob(localStorage.getItem("password")) : "",
        },
        validationSchema: Yup.object({
            email: Yup.string().email("Invalid email address").required("*Email is required."),
            password: Yup.string()
                .required("*Password is required")
            // .matches(
            //     /^(?=.*?[A-Z])(?=(.*[a-z]){1,})(?=(.*[\d]){1,})(?=(.*[\W]){1,})(?!.*\s).{8,}$/,
            //     "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character"
            // ),
        }),

        onSubmit: async (values) => {
            const payload = {
                email: values.email,
                password: values.password,
                deviceType: deviceType,
                deviceToken: devicetoken,
            };

            if (rememberME) {
                localStorage.setItem("emailID", values.email);
                localStorage.setItem("password", window.btoa(values.password));
                localStorage.setItem("rememberME", rememberME);
            } else {
                localStorage.removeItem("emailID", values.email);
                localStorage.removeItem("password", window.btoa(values.password));
                localStorage.removeItem("rememberME", rememberME);
            }
            try {
                console.log("login payload=", payload);

                setIsLoader(true);
                let res = await authenticationServices.patientLogin(payload);
                console.log("login result==", res);
                if (res.data.status === 200) {
                    setIsLoader(false);
                    const token = res.data.data.token
                    // const userData = res.data.response.userData
                    // saveToSessionStorage("token", token)
                    // dispatch(setUser(userData));
                    sessionStorage.setItem("token", JSON.stringify(token));
                    toast.success(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                    sessionStorage.setItem("userType", "1")
                    navigate("/patient-dashboard", { replace: true })
                } else {
                    setIsLoader(false);
                    toast.error(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                }
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        },
    });


    const handleRememberMe = (event) => {
        setRememberME(event.target.checked);
    };

    useEffect(() => {
        if (localStorage.getItem("rememberME")) {
            setRememberME(true);
        }
    }, []);

    return (
        <div className='patient-login'>
            {IsLoader && <SpinnerLoader />}
            <div className="container-fluid ">
                <div className="image">
                    <img src={patinetImage} />
                    <div className="content-image">
                        <p> The Checkpoint Now</p>
                        <h1> Consult our trusted cancer experts</h1>
                        <h6> - We understand cancer, its treatments and its side effects </h6>
                        <h6> - Make An Appointment </h6>
                    </div>
                </div>
                <div className="right-side">
                    <div className="form-container">
                        <img className='right-div-logo' src={cpnLogo} alt="Logo" />
                        <h1 className='login-expert'>Login as a Patient</h1>
                        <Form onSubmit={formik.handleSubmit} className='form-size'>
                            <FormGroup>
                                <Label htmlFor="exampleEmail">
                                    Email Address
                                </Label>
                                <Input

                                    name="email"
                                    placeholder="Enter Email Address"
                                    type="text"
                                    {...formik.getFieldProps("email")}
                                    onKeyDown={checkSpace}
                                    invalid={formik.touched.email && formik.errors.email ? true : false}
                                />
                                {formik.touched.email && formik.errors.email ? <small className="validation_error">{formik.errors.email}</small> : null}
                            </FormGroup>
                            <FormGroup className="pasword">

                                {/* <img src={eyeClose} alt="" className='eyeclosed' /> */}
                                <Label htmlFor="examplePassword">
                                    Password
                                </Label>
                                <Input
                                    onKeyDown={checkSpace}
                                    {...formik.getFieldProps("password")}

                                    name="password"
                                    autoComplete="off"
                                    placeholder="Enter Password"
                                    type={!toggleIcon ? "password" : "text"}
                                    invalid={formik.touched.password && formik.errors.password ? true : false}
                                    className='extracsc' />
                                <span className={formik.touched.password && formik.errors.password ? 'pwdToggleError' : 'pwdToggle'}>
                                    {toggleIcon ? (
                                        <span onClick={togglePassword}>
                                            <ShowIcon />
                                        </span>
                                    ) : (
                                        <span onClick={togglePassword}>
                                            <HideIcon />
                                        </span>
                                    )}
                                </span>
                                {formik.touched.password && formik.errors.password ? (
                                    <span className="validation_error">{formik.errors.password}</span>
                                ) : null}

                            </FormGroup>

                            <FormGroup check>
                                <Input type="checkbox" checked={rememberME} onChange={handleRememberMe} />
                                {' '}
                                <Label check className='remember-me mb-4'>
                                    Remember me
                                </Label>
                            </FormGroup>
                            <Button className='login-button' type="submit">
                                Login
                            </Button>
                        </Form>
                        <div className="last-form-content mt-4">
                            <p><Link to="/forgot-password"> Forgot Password </Link></p>
                            <h6>Don't have an account? <Link to="/signup-as-patient-1" state={{ comingFrom: "patient-login" }} style={{ fontSize: "14px" }}> Sign Up </Link></h6>
                            <h3 onClick={() => navigate("/")}>Go to Home</h3>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    )
}

export default PatientLogin