import React, { useState, useEffect } from 'react'
import { FormGroup, Input, Label, Form, FormText, Button, Progress } from 'reactstrap';
import tick from "../../../assests/images/check-circle-svgrepo-com (2).svg";
import cpnLogo from "../../../assests/images/CPNHealthFINAL_fontembed.svg";
import eyeClose from "../../../assests/images/eye-closed-svgrepo-com.png";
import Footer from '../../common/Footer/Footer';

import { useNavigate, Link, useParams } from 'react-router-dom';
import { ReactComponent as HideIcon } from "../../../assests/images/hide.svg";
import { ReactComponent as ShowIcon } from "../../../assests/images/view.svg";
import { useFormik } from "formik";
import * as Yup from "yup";
import { checkSpace } from "../../../utils";
import authenticationServices from "../../../services";
import { toast } from "react-toastify";
import { async } from 'q';
import SpinnerLoader from '../../common/Spinner';
const PatientSignup1 = () => {

    const navigate = useNavigate()
    const [IsLoader, setIsLoader] = useState(false);
    const [toggleIcon1, setToggleIcon1] = useState(false)
    const [toggleIcon2, setToggleIcon2] = useState(false)
    const [acceptTnC, setAcceptTnC] = useState(false)
    const [isDisable, setisDisable] = useState(false);
    const [emailExistsError, setEmailExistsError] = useState('');
    const [toggleIcon, setToggleIcon] = useState(false)
    const params = useParams()
    const { email } = params
    console.log("params", email)
    useEffect(() => {
        if (email) {

        }
    }, [email])
    const togglePassword = () => {
        setToggleIcon(!toggleIcon)
    }
    const togglePassword1 = () => {
        setToggleIcon1(!toggleIcon1)
    }
    // const togglePassword2 = () => {
    //     setToggleIcon2(!toggleIcon2)
    // }


    const checkEmailIdApi = async (email) => {
        try {
            const payload = {
                "email": email
            }
            setIsLoader(true);
            let res = await authenticationServices.checkEmailIdExit(payload);
            // console.log("api res==", res);
            formik.setFieldTouched('email', true);
            if (res.data.status === 200) {
                setisDisable(true)
                setEmailExistsError(res.data.message)
                setIsLoader(false);
                toast.error(res.data.message, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            } else {
                setEmailExistsError()
                setIsLoader(false);
                setisDisable(false)
            }

        } catch (error) {
            setIsLoader(false);
            toast.error(error, {
                position: toast.POSITION.TOP_RIGHT,
            });
        }
    }

    const formik = useFormik({
        initialValues: {
            email: email ? email : "",
            password: "",
            confirmPassword: "",
        },
        validationSchema: Yup.object({
            email: Yup.string().email("Invalid email address").required("*Email is required."),
            password: Yup.string()
                .required("*Password is required")
                .matches(
                    /^(?=.*?[A-Z])(?=(.*[a-z]){1,})(?=(.*[\d]){1,})(?=(.*[\W]){1,})(?!.*\s).{8,}$/,
                    "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character"
                ),
            confirmPassword: Yup.string()
                .required("*Confirm password is required")
                .matches(
                    /^(?=.*?[A-Z])(?=(.*[a-z]){1,})(?=(.*[\d]){1,})(?=(.*[\W]){1,})(?!.*\s).{8,}$/,
                    "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character"
                ).oneOf([Yup.ref('password'), null], 'Password and Confirm password should be same')
        }),

        onSubmit: async (values) => {
            if (!acceptTnC) {
                toast.warn("Please Accept Terms & Conditions and Privacy Policy", {
                    position: toast.POSITION.TOP_RIGHT,
                });
                return
            } else {

                const patientSignupData = localStorage.getItem("patientSignupData")
                    ? JSON.parse(localStorage.getItem("patientSignupData"))
                    : "";
                const payload = {
                    ...patientSignupData,
                    email: values.email,
                    password: values.password,
                };

                try {
                    localStorage.setItem("patientSignupData", JSON.stringify(payload));
                    console.log("patient details payload=", payload);
                    navigate("/signup-as-patient-2")
                } catch (error) {
                    toast.error(error, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                }
            }
        }
    });


    useEffect(() => {
        getPatchform();
    }, []);

    const getPatchform = () => {
        const step1Data = localStorage.getItem("patientSignupData")
            ? JSON.parse(localStorage.getItem("patientSignupData"))
            : "";
        console.log("step1Data", step1Data);

        if (step1Data) {
            formik.setValues({

                email: step1Data.email,
                password: step1Data.password,
                confirmPassword: step1Data.password,
            });
        }
    };


    // Exsting email check API function
    const apiCall = async (email) => {
        try {
            checkEmailIdApi(email)
            // Call your API here
            // console.log('API called with email:500', email);
        } catch (error) {
            // console.error('API error:', error);
        }
    };


    // Debounce function
    const debounce = (func, delay) => {
        let timeoutId;
        return (...args) => {
            clearTimeout(timeoutId);
            timeoutId = setTimeout(() => {
                func(...args);
            }, delay);
        };
    };

    const debouncedApiCall = debounce(apiCall, 1000); // Adjust the debounce delay as needed

    const handleChange = (event) => {
        const newEmail = event.target.value;

        // Update Formik field value
        formik.handleChange(event);

        // Check email format
        const isValid = validateEmailFormat(newEmail);

        // Call the debounced API function only if the email format is valid
        if (isValid) {
            debouncedApiCall(newEmail);
        }
    };

    // Email format validation function
    const validateEmailFormat = (email) => {
        const pattern = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
        return pattern.test(email);
    };

    return (
        <>
            <div className='patient-login-details'>
                {IsLoader && <SpinnerLoader />}
                <div className="container">
                    <div className="logo-container">
                        <div className="logo-cpn">
                            <Link to="/login-as-patient">
                                <img src={cpnLogo} alt="Logo" />
                            </Link>
                        </div>

                        <div className="login-button">
                            <Link to="/login-as-patient">
                                <Button>
                                    Login
                                </Button>
                            </Link>
                        </div>
                    </div>
                    <div className="otp-input">
                        <Progress multi>
                            <Progress
                                bar
                                value="35.33"
                                style={{
                                    height: '3px'
                                }}
                            />
                            <Progress
                                bar
                                color="success"
                                value="35.33"
                                style={{ height: '3px' }}
                            />
                            <Progress
                                bar
                                color="info"
                                value="35.33"
                                style={{ height: '3px' }}
                            />

                        </Progress>
                    </div>
                    <div className="text-sign-up">
                        <h1>Sign Up as a Patient</h1>
                    </div>

                    {/* mobile view */}

                    <div className="text-sign-up-2">
                        <img src={tick} alt="" />
                        <h1>Login Details</h1>
                    </div>
                </div>
                <div className="container">
                    <div className="content-date">
                        <div className="login-detail">
                            <div className="login-detail-img">
                                <img src={tick} alt="" />
                                <h1>Login Details</h1>
                            </div>

                            <div className="login-detail-img2-data" style={{ opacity: '0.32' }}>
                                <img src={tick} alt="" />
                                <h1 >Personal Details</h1>
                            </div>
                            <div className="login-detail-img3-data">
                                <img src={tick} alt="" />
                                <h1> Sign HiPAA Agreement, CPN Agreement</h1>
                            </div>
                        </div>
                        <div className="form-data-container">

                            <Form onSubmit={formik.handleSubmit}>
                                <FormGroup>
                                    <Label htmlFor="exampleEmail">
                                        Email Address
                                    </Label>
                                    <Input
                                        id="exampleEmail"
                                        name="email"
                                        placeholder="Enter Email Address"
                                        type="email"
                                        disabled={email ? true : false}
                                        // {...formik.getFieldProps("email")}
                                        onKeyDown={checkSpace}
                                        className={formik.touched.email && (formik.errors.email || emailExistsError) ? 'is-invalid' : ''}
                                        value={formik.values.email}
                                        onBlur={formik.handleBlur}
                                        // onChange={formik.handleChange}
                                        // value={email}
                                        onChange={handleChange}
                                    // invalid={formik.touched.email && formik.errors.email ? true : false}
                                    />
                                    {formik.touched.email && (formik.errors.email || emailExistsError) ? (
                                        <small className="validation_error">{formik.errors.email || emailExistsError}</small>
                                    ) : null}
                                </FormGroup>
                                <FormGroup>
                                    <div className="pasword">
                                        {/* <img src={eyeClose} alt="" className='eyeclosed' /> */}
                                        <Label htmlFor="examplePassword">
                                            Password
                                        </Label>
                                        <Input

                                            name="password"
                                            placeholder="Enter Password"
                                            onKeyDown={checkSpace}
                                            {...formik.getFieldProps("password")}
                                            type={!toggleIcon1 ? "password" : "text"}
                                            className={formik.touched.password && formik.errors.password ? "is-invalid" : ""}
                                        // invalid={formik.touched.password && formik.errors.password ? true : false}
                                        />
                                        <span className={formik.touched.password && formik.errors.password ? 'pwdToggleError' : 'pwdToggle'}>
                                            {toggleIcon ? (
                                                <span onClick={togglePassword}>
                                                    <ShowIcon />
                                                </span>
                                            ) : (
                                                <span onClick={togglePassword}>
                                                    <HideIcon />
                                                </span>
                                            )}
                                        </span>
                                        {formik.touched.password && formik.errors.password ? (
                                            <span className="validation_error">{formik.errors.password}</span>
                                        ) : null}
                                    </div>
                                </FormGroup>

                                <FormGroup>
                                    <div className="confrimpasword">
                                        {/* <img src={eyeClose} alt="" className='eyeclosed' /> */}
                                        <Label htmlFor='examplePassword'> Confirm Password</Label>
                                        <Input
                                            name="confirmPassword"
                                            placeholder="Enter Password"
                                            type={!toggleIcon2 ? "password" : "text"}
                                            onKeyDown={checkSpace}
                                            {...formik.getFieldProps("confirmPassword")}
                                            invalid={formik.touched.confirmPassword && formik.errors.confirmPassword ? true : false}
                                        />
                                        {/* <span className='pwdToggle'>
                                        {toggleIcon2 ? (
                                            <span onClick={togglePassword2}>
                                                <ShowIcon />
                                            </span>
                                        ) : (
                                            <span onClick={togglePassword2}>
                                                <HideIcon />
                                            </span>
                                        )}
                                    </span> */}
                                        <span className={formik.touched.password && formik.errors.password ? 'pwdToggleError' : 'pwdToggle'}>
                                            {toggleIcon ? (
                                                <span onClick={togglePassword1}>
                                                    <ShowIcon />
                                                </span>
                                            ) : (
                                                <span onClick={togglePassword1}>
                                                    <HideIcon />
                                                </span>
                                            )}
                                        </span>
                                        {formik.touched.confirmPassword && formik.errors.confirmPassword ? (
                                            <small className="validation_error">{formik.errors.confirmPassword}</small>
                                        ) : null}
                                    </div>

                                </FormGroup>

                                <FormGroup check className='tnc-policy'>
                                    <Input type="checkbox" onChange={(e) => setAcceptTnC(e.target.checked)} checked={acceptTnC} />
                                    {' '}
                                    <Label check>
                                        Accept <Link to=''>Terms & Conditions</Link> and <Link to=''>Privacy Policy</Link>
                                    </Label>
                                </FormGroup>

                                <Button className='btn-secondry mb-4' type='submit' disabled={isDisable}>
                                    Next
                                </Button>
                            </Form>
                        </div>
                    </div>

                </div>

            </div>
            <Footer />
        </>

    )
}

export default PatientSignup1