import React, { useState, useEffect } from 'react'
import { Table } from 'reactstrap'
import { Link, useNavigate } from 'react-router-dom'
import { Progress, Form, FormGroup, Button, Row, Label, Input, Col } from 'reactstrap'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import Logoimage from '../../../assests/images/ys.png'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import { useFormik } from 'formik'
import * as Yup from "yup";
import { object } from 'prop-types'
import { toast } from "react-toastify";
import Sidebar from '../../common/Sidebar/Sidebar'
import authenticationServices from "../../../services";



function MedicalInformation5() {
    const navigate = useNavigate();
    const [IsLoader, setIsLoader] = useState(false);
    useEffect(() => {
        const nameOfMedication = localStorage.getItem("nameOfMedication")
            ? JSON.parse(localStorage.getItem('nameOfMedication'))
            : "";
        if (nameOfMedication && Object.keys(nameOfMedication)?.length) {

            getPatchform();
        }
    }, [])
    // get fill data and  show on back click 
    const getPatchform = () => {
        const nameOfMedication = localStorage.getItem("nameOfMedication")
            ? JSON.parse(localStorage.getItem("nameOfMedication"))
            : "";
        if (Object.keys(nameOfMedication)?.length && Object.keys(nameOfMedication?.nameOfMedication)?.length) {


            const { nameOfMedication: { allerygy, medication, lab, details, imaging,
                document, attachments, attachment, documents, imagings, choose, choosesfile } } = nameOfMedication
            console.log("nameOfMedication", nameOfMedication);


            if (medication && allerygy && details) {
                formik.setValues({
                    allerygy: allerygy,
                    medication: medication,
                    lab: lab,
                    details: details,
                    attachment: attachment,
                    attachments: attachments,
                    imaging: imaging,
                    document: document,
                    documents: documents,
                    imagings: imagings,
                    choose: choose,
                    choosesfile: choosesfile


                });

            }
        }
    };

    const validationSchema = Yup.object().shape({
        medication: Yup.string().required("Enter name of medication."),
        allerygy: Yup.string().required("Enter name of allerygy."),
        lab: Yup.string().required("Enter lab name."),
        details: Yup.string().required("Enter details."),
        attachment: Yup.string().required("choose file."),
        attachments: Yup.string().required("choose file."),
        imaging: Yup.string().required("Enter image details.."),
        document: Yup.string().required("choose file."),
        documents: Yup.string().required("choose file."),
        imagings: Yup.string().required("Enter image details.."),
        choose: Yup.string().required("Choose file."),
        choosesfile: Yup.string().required("Choose file."),
    })
    const formik = useFormik({
        initialValues: {
            medication: "",
            allerygy: "",
            lab: "",
            details: "",
            attachment: "",
            attachments: "",
            imaging: "",
            document: "",
            documents: "",
            imagings: "",
            choose: "",
            choosesfile: ""
        },
        validationSchema: validationSchema,
        onSubmit: async (values) => {
            const step1Data = localStorage.getItem("nameOfMedication")
                ? JSON.parse(localStorage.getItem("nameOfMedication"))
                : "";
            const previousFormData=localStorage.getItem("medicalStepData")
            ? JSON.parse(localStorage.getItem("medicalStepData"))
            : "";
    


            const payload = {
             // ...step1Data,
             ...previousFormData,
                nameOfMedication: {
                    ...values
                }
            };


            try {
                console.log("nameOfMedication  payload=", payload);
                // localStorage.setItem("nameOfMedication", JSON.stringify(payload));
                localStorage.setItem("medicalStepData", JSON.stringify(payload));
                navigate("/request-new-appointment")
                setIsLoader(true);
                const res = authenticationServices.medicalInformation(payload)
                console.log(res)
                if (res.status === 200) {
                    toast.success(res.data.responseMessage, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                } else {
                    setIsLoader(false);
                    toast.error(res.data.responseMessage, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                }

            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        }


    });
    console.log("formik", formik.errors)

    return (
        <>
            <div className='medical-information5'>
                <LoginNavbar />
                <div className="container mb-5">
                    <div className="parent-div">
                        <Sidebar />

                        <div className="child-div">
                            <div className="progress-bar-container">
                                <div className="progress-bar">
                                    <span>4</span>
                                </div>

                            </div>
                            <div className="middle-content">
                                <Form onSubmit={formik.handleSubmit}>
                                    <Row>
                                        <h1>Allergies</h1>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleText">
                                                    Name of Medication
                                                </Label>
                                                <Input

                                                    name="medication"
                                                    type="text"
                                                    placeholder='Enter Name of Medication'
                                                    {...formik.getFieldProps("medication")}
                                                    className={formik.touched.medication && formik.errors.medication ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.medication && formik.errors.medication ? <small className='validation_error'>{formik.errors.medication}</small> : ""}

                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleText">
                                                    Name of Allergy
                                                </Label>
                                                <Input

                                                    name="allergy"
                                                    type="Text"
                                                    placeholder='Enter Name of Allergy'
                                                    {...formik.getFieldProps("allerygy")}
                                                    className={formik.touched.allerygy && formik.errors.allerygy ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.allerygy && formik.errors.allerygy ? <small className='validation_error'>{formik.errors.allerygy}</small> : ""}
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <h1>Labs</h1>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleText">
                                                    Lab Name
                                                </Label>
                                                <Input

                                                    name="lab"
                                                    type="text"
                                                    placeholder='Enter Lab Name'
                                                    {...formik.getFieldProps("lab")}
                                                    className={formik.touched.lab && formik.errors.lab ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.lab && formik.errors.lab ? <small className='validation_error'>{formik.errors.lab}</small> : ""}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleText">
                                                    Details
                                                </Label>
                                                <Input

                                                    name="details"
                                                    type="Text"
                                                    placeholder='Enter Detail'
                                                    {...formik.getFieldProps("details")}
                                                    className={formik.touched.details && formik.errors.details ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.details && formik.errors.details ? <small className='validation_error'>{formik.errors.details}</small> : ""}
                                            </FormGroup>
                                        </Col>

                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleFile">Documents Attachment</Label>
                                                <Input

                                                    name="attachment"
                                                    type="file"
                                                    placeholder='Browse File'
                                                    {...formik.getFieldProps("attachment")}
                                                    className={formik.touched.attachment && formik.errors.attachment ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.attachment && formik.errors.attachment ? <small className='validation_error'>{formik.errors.attachment}</small> : ""}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label><br /></Label>
                                                <Input


                                                    name="attachments"
                                                    type="file"
                                                    placeholder='Browse File'
                                                    {...formik.getFieldProps("attachments")}
                                                    className={formik.touched.attachments && formik.errors.attachments ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.attachments && formik.errors.attachments ? <small className='validation_error'>{formik.errors.attachments}</small> : ""}
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <h1>Imaging</h1>
                                        <Col md={12}>
                                            <FormGroup>
                                                <Label for="exampleText">Imaging Details</Label>
                                                <Input

                                                    name="imaging"
                                                    type="text"
                                                    placeholder='Enter Imaging Details'
                                                    {...formik.getFieldProps("imaging")}
                                                    className={formik.touched.imaging && formik.errors.imaging ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.imaging && formik.errors.imaging ? <small className='validation_error'>{formik.errors.imaging}</small> : ""}
                                            </FormGroup>
                                        </Col>

                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleFile">Documents Attachment</Label>
                                                <Input

                                                    name="document"
                                                    type="file"
                                                    placeholder='Browse File'
                                                    {...formik.getFieldProps("document")}
                                                    className={formik.touched.document && formik.errors.document ? 'is-invalid' : ''}
                                                />
                                            </FormGroup>
                                            {formik.touched.docuemnt && formik.errors.docuemnt ? <small className='validation_error'>{formik.errors.document}</small> : ""}
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleFile"><br /></Label>
                                                <Input

                                                    name="documents"
                                                    type="file"
                                                    placeholder='Browse File'
                                                    {...formik.getFieldProps("documents")}
                                                    className={formik.touched.documents && formik.errors.documents ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.documents && formik.errors.documents ? <small className='validation_error'>{formik.errors.documents}</small> : ""}
                                            </FormGroup>
                                        </Col>
                                    </Row>

                                    <Row>
                                        <h1>Other Additional information</h1>
                                        <Col md={12}>
                                            <FormGroup>
                                                <Label for="exampleText">Imaging Details</Label>
                                                <Input

                                                    name="imagings"
                                                    type="text"
                                                    placeholder='Enter Imaging Details'
                                                    {...formik.getFieldProps("imagings")}
                                                    className={formik.touched.imagings && formik.errors.imagings ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.imagings && formik.errors.imagings ? <small className='validation_error'>{formik.errors.imagings}</small> : ""}
                                            </FormGroup>
                                        </Col>

                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleFile">Documents Attachment</Label>
                                                <Input

                                                    name="choose"
                                                    type="file"
                                                    placeholder='Browse File'
                                                    {...formik.getFieldProps("choose")}
                                                    className={formik.touched.choose && formik.errors.choose ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.choose && formik.errors.choose ? <small className='validation_error'>{formik.errors.choose}</small> : ""}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleFile"><br /></Label>
                                                <Input

                                                    name="chooses"
                                                    type="file"
                                                    placeholder='Browse File'
                                                    {...formik.getFieldProps("choosesfile")}
                                                    className={formik.touched.choosesfile && formik.errors.choosesfile ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.choosesfile && formik.errors.choosesfile ? <small className='validation_error'>{formik.errors.choosesfile}</small> : ""}
                                            </FormGroup>
                                        </Col>
                                    </Row>

                                    <Button className='btn-secondry' type='submit'>
                                        Save
                                    </Button>

                                </Form>


                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <Footer />


        </>
    )
}

export default MedicalInformation5
