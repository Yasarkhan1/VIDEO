import React, { useState, useEffect } from 'react';
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import Sidebar from '../../common/Sidebar/Sidebar'
import { FormGroup, Form, Button, Input, Label, Col, Row } from 'reactstrap'
import AppointNavbar from '../../common/AppointmentNavbar/AppointNavbar'
import Footer from '../../common/Footer/Footer'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import 'react-datepicker/dist/react-datepicker.css';
import authenticationServices from "../../../services";
import { useSelector } from 'react-redux';
import { Formik, useFormik } from 'formik';
import * as Yup from 'yup';
import { toast } from "react-toastify";
import SpinnerLoader from '../../common/Spinner'

const validationSchema = Yup.object().shape({
    // typeOfCancer: Yup.string().required('Type of Cancer is required'),
    // yearOfDiagnosis: Yup.string().required('Year of Diagnosis is required'),
    // locationOfPrimaryCancer: Yup.string().required('Location of primary Cancer is required'),
    // cancerStage: Yup.string().required('Cancer Stage is required'),
    // pastTreatment: Yup.string().required('Past Cancer Treatment is required'),
    // chemotherapy: Yup.string().required('Chemotherapy is required'),
    // radiation: Yup.string().required('Radiation is required'),
    // immunotherapi: Yup.string().required('Immunotherapi is required'),
    // targetTherapy: Yup.string().required('Target Therapy is required'),
    // surgery: Yup.string().required('Surgery is required'),
    // clinicalTrialName: Yup.string().required('Clinical Trail Name is required'),
    // clinicalTrialYear: Yup.string().required('Year is required'),
    chemotherapy_date: Yup.string().test(
        'isRequired',
        'Select Date',
        function (value) {
            const { chemotherapy } = this.parent;
            if (chemotherapy === 'Yes') {
                return Yup.string().required().isValidSync(value);
            }
            return true;
        }
    ),
    radiation_date: Yup.string().test(
        'isRequired',
        'Select Date',
        function (value) {
            const { radiation } = this.parent;
            if (radiation === 'Yes') {
                return Yup.string().required().isValidSync(value);
            }
            return true;
        }
    ),
    immunotherapi_date: Yup.string().test(
        'isRequired',
        'Select Date',
        function (value) {
            const { immunotherapi } = this.parent;
            if (immunotherapi === 'Yes') {
                return Yup.string().required().isValidSync(value);
            }
            return true;
        }
    ),
    targetTherapy_date: Yup.string().test(
        'isRequired',
        'Select Date',
        function (value) {
            const { targetTherapy } = this.parent;
            if (targetTherapy === 'Yes') {
                return Yup.string().required().isValidSync(value);
            }
            return true;
        }
    ),
    surgery_date: Yup.string().test(
        'isRequired',
        'Select Date',
        function (value) {
            const { surgery } = this.parent;
            if (surgery === 'Yes') {
                return Yup.string().required().isValidSync(value);
            }
            return true;
        }
    ),
});

function NewAppointment3() {
    const location = useLocation()
    const dropDownData = useSelector((state) => state.allDropDown.data);
    const navigate = useNavigate()
    const [IsLoader, setIsLoader] = useState(false);
    const appointmentId = location?.state?.appointmentId
    const [selectedDate, setSelectedDate] = useState(null);
    const [metastatic, setMetastatic] = useState("Yes");

    const handleDateChange = (date) => {
        setSelectedDate(date);
    }

    // useEffect to redirect step 1 if previous form not submitted
    // useEffect(() => {
    //     if (appointmentId === '' || appointmentId === undefined) {
    //         navigate("/new-appointment-1")
    //     }
    // }, [appointmentId])

    const formik = useFormik({
        initialValues: {
            typeOfCancer: '',
            yearOfDiagnosis: '',
            locationOfPrimaryCancer: '',
            cancerStage: '',
            pastTreatment: '',
            chemotherapy: '',
            radiation: '',
            immunotherapi: '',
            targetTherapy: '',
            surgery: '',
            clinicalTrialName: '',
            clinicalTrialYear: '',
            chemotherapy_date: '',
            radiation_date: '',
            immunotherapi_date: '',
            targetTherapy_date: '',
            surgery_date: '',

        },
        validationSchema: validationSchema,
        onSubmit: async (values) => {
            // Handle form submission
            console.log(values);
            const payload = {
                "typeOfCancer": values.typeOfCancer,
                "yearOfDiagnosis": values.yearOfDiagnosis,
                "location": values.locationOfPrimaryCancer,
                "metastatic": metastatic,
                "stage": values.cancerStage,
                "pastCancerTreatment": values.pastTreatment,
                "chemotherapy": {
                    "value": values.chemotherapy,
                    "date": values.chemotherapy_date
                },
                "radiation": {
                    "value": values.radiation,
                    "date": values.radiation_date
                },
                "surgery": {
                    "value": values.surgery,
                    "date": values.surgery_date
                },
                "targetedTherapies": {
                    "value": values.targetTherapy,
                    "date": values.targetTherapy_date
                },
                "immunotherapies": {
                    "value": values.immunotherapi,
                    "date": values.immunotherapi_date
                },
                "clinicalTrialName": values.clinicalTrialName,
                "year": values.year,
                "appointmentId": appointmentId,
            }
            try {
                console.log("appointmentBook step 3 payload=", payload);

                setIsLoader(true);
                let res = await authenticationServices.appointmentBook(payload, 3);
                console.log("appointmentBook step 3 result==", res);
                if (res.data.status === 200) {
                    const appointmentId = res.data.data.appointmentId
                    setIsLoader(false);
                    toast.success(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                    // navigate("/")
                    navigate("/new-appointment-4", { state: { appointmentId: appointmentId }, replace: true })
                } else {
                    setIsLoader(false);
                    toast.error(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                }
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        },
    });

    const handleMetastaticChange = (e) => {
        const { name, value } = e.target;
        setMetastatic(value);

    }

    // useEffect to reset fields on select "No" from dropdown
    useEffect(() => {
        if (formik.values.chemotherapy === 'No') {
            formik.setFieldValue('chemotherapy_date', '');
            formik.setFieldError('chemotherapy_date', '');
            formik.setFieldTouched('chemotherapy_date', false);
        }
        if (formik.values.radiation === 'No') {
            formik.setFieldValue('radiation_date', '');
            formik.setFieldError('radiation_date', '');
            formik.setFieldTouched('radiation_date', false);
        }
        if (formik.values.immunotherapi === 'No') {
            formik.setFieldValue('immunotherapi_date', '');
            formik.setFieldError('immunotherapi_date', '');
            formik.setFieldTouched('immunotherapi_date', false);
        }
        if (formik.values.targetTherapy === 'No') {
            formik.setFieldValue('targetTherapy_date', '');
            formik.setFieldError('targetTherapy_date', '');
            formik.setFieldTouched('targetTherapy_date', false);
        }
        if (formik.values.surgery === 'No') {
            formik.setFieldValue('surgery_date', '');
            formik.setFieldError('surgery_date', '');
            formik.setFieldTouched('surgery_date', false);
        }
    }, [formik.values.surgery, formik.values.chemotherapy, formik.values.radiation, formik.values.immunotherapi, formik.values.targetTherapy])
    // console.log("error>", formik.errors);

    return (
        <>
            <div className="new-appointment3">
                {IsLoader && <SpinnerLoader />}
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className="parent-div">
                        <Sidebar />
                        <div className="child-div">
                            <div className="child-navabar">
                                <AppointNavbar />
                            </div>

                            <div className="form-groupes">
                                <div className="header-heading">
                                    <h1>Cancer/Oncology History</h1>
                                </div>
                                <Form onSubmit={formik.handleSubmit}>
                                    <Row>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="typeOfCancer">Type of Cancer</Label>
                                                <Input
                                                    id="typeOfCancer"
                                                    type="text"
                                                    {...formik.getFieldProps('typeOfCancer')}
                                                />
                                                {formik.touched.typeOfCancer && formik.errors.typeOfCancer ? (
                                                    <div className="validation_error">{formik.errors.typeOfCancer}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="yearOfDiagnosis">Year of Diagnosis</Label>
                                                {/* <Input
                                                    id="yearOfDiagnosis"
                                                    type="text"
                                                    {...formik.getFieldProps('yearOfDiagnosis')}
                                                /> */}
                                                <Input
                                                    id="yearOfDiagnosis"
                                                    type="select"
                                                    {...formik.getFieldProps('yearOfDiagnosis')}
                                                >
                                                    <option value="">Select</option>
                                                    {dropDownData?.year.length ?
                                                        dropDownData?.year.map((item, ind) => (

                                                            <option value={item.value} key={ind}>{item.label}</option>
                                                        ))
                                                        : ""
                                                    }
                                                </Input>
                                                {formik.touched.yearOfDiagnosis && formik.errors.yearOfDiagnosis ? (
                                                    <div className="validation_error">{formik.errors.yearOfDiagnosis}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="locationOfPrimaryCancer">Location of primary Cancer</Label>
                                                <Input
                                                    id="locationOfPrimaryCancer"
                                                    type="text"
                                                    {...formik.getFieldProps('locationOfPrimaryCancer')}
                                                />
                                                {formik.touched.locationOfPrimaryCancer && formik.errors.locationOfPrimaryCancer ? (
                                                    <div className="validation_error">{formik.errors.locationOfPrimaryCancer}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <div className="radio-button">
                                                <h6>Metastatic (Yes/No)</h6>
                                                <input type="radio"
                                                    value="Yes"
                                                    onChange={handleMetastaticChange}
                                                    checked={metastatic === "Yes"} /> Yes
                                                <input type="radio" value="No" onChange={handleMetastaticChange}
                                                    checked={metastatic === "No"} /> No
                                            </div>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="cancerStage">Cancer Stage</Label>
                                                <Input
                                                    id="cancerStage"
                                                    type="select"
                                                    {...formik.getFieldProps('cancerStage')}
                                                >
                                                    <option value="">Select</option>
                                                    {dropDownData?.cancerStage.length ?
                                                        dropDownData?.cancerStage.map((item, ind) => (

                                                            <option value={item.value} key={ind}>{item.label}</option>
                                                        ))
                                                        : ""
                                                    }
                                                </Input>
                                                {formik.touched.cancerStage && formik.errors.cancerStage ? (
                                                    <div className="validation_error">{formik.errors.cancerStage}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="pastTreatment">Past Cancer Treatment (With Duration)</Label>
                                                <Input
                                                    id="pastTreatment"
                                                    type="text"
                                                    {...formik.getFieldProps('pastTreatment')}
                                                />
                                                {formik.touched.pastTreatment && formik.errors.pastTreatment ? (
                                                    <div className="validation_error">{formik.errors.pastTreatment}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>
                                        <Col md={2}>
                                            <FormGroup>
                                                <Label for="chemotherapy">Chemotherapy</Label>
                                                <Input
                                                    id="chemotherapy"
                                                    type="select"
                                                    {...formik.getFieldProps('chemotherapy')}
                                                >
                                                    {/* <option value="Select">Select</option> */}
                                                    <option value="">Select</option>
                                                    <option value="Yes">Yes</option>
                                                    <option value="No">No</option>
                                                </Input>
                                                {formik.touched.chemotherapy && formik.errors.chemotherapy ? (
                                                    <div className="validation_error">{formik.errors.chemotherapy}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>

                                        <Col md={4}>
                                            <div className="input-group">
                                                <Label>(Yes/No (Date))</Label>
                                                {
                                                    formik.values.chemotherapy === 'Yes' &&
                                                    <div className="date-picker-container">
                                                        <Input
                                                            id="chemotherapy_date"
                                                            name="chemotherapy_date"
                                                            placeholder="date placeholder"
                                                            max={new Date().toISOString().split('T')[0]}
                                                            min="1980-01-01"
                                                            type="date"
                                                            {...formik.getFieldProps("chemotherapy_date")}
                                                            className={formik.touched.chemotherapy_date && formik.errors.chemotherapy_date ? 'is-invalid' : ""}
                                                        />

                                                        {formik.errors.chemotherapy_date ? <small className='validation_error'>{formik.errors.chemotherapy_date}</small> : null}
                                                    </div>}
                                            </div>
                                        </Col>

                                    </Row>
                                    {/* Second Row Start */}
                                    <Row>
                                        <Col md={2}>
                                            <FormGroup>
                                                <Label for="targetTherapy">TargetTherapy</Label>
                                                <Input
                                                    id="targetTherapy"
                                                    type="select"
                                                    {...formik.getFieldProps('targetTherapy')}
                                                >
                                                    <option value="">Select</option>
                                                    <option value="Yes">Yes</option>
                                                    <option value="No">No</option>
                                                </Input>
                                                {formik.touched.targetTherapy && formik.errors.targetTherapy ? (
                                                    <div className="validation_error">{formik.errors.targetTherapy}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>

                                        <Col md={4}>
                                            <div className="input-group">
                                                <Label>(Yes/No (Date))</Label>
                                                {
                                                    formik.values.targetTherapy === 'Yes' &&
                                                    <div className="date-picker-container">
                                                        <Input
                                                            id="targetTherapy_date"
                                                            name="targetTherapy_date"
                                                            placeholder="date placeholder"
                                                            max={new Date().toISOString().split('T')[0]}
                                                            min="1980-01-01"
                                                            type="date"
                                                            {...formik.getFieldProps("targetTherapy_date")}
                                                            className={formik.touched.targetTherapy_date && formik.errors.targetTherapy_date ? 'is-invalid' : ""}
                                                        />
                                                        {formik.errors.targetTherapy_date ? <small className='validation_error'>{formik.errors.targetTherapy_date}</small> : null}
                                                    </div>}
                                            </div>
                                        </Col>

                                        <Col md={2}>
                                            <div className="input-group" >
                                                <Label>Radiation </Label>
                                                <FormGroup>
                                                    <Input
                                                        id="radiation"
                                                        type="select"
                                                        {...formik.getFieldProps('radiation')}
                                                    >
                                                        <option value="">Select</option>
                                                        <option value="Yes">Yes</option>
                                                        <option value="No">No</option>
                                                    </Input>
                                                    {formik.touched.radiation && formik.errors.radiation ? (
                                                        <div className="validation_error">{formik.errors.radiation}</div>
                                                    ) : null}
                                                </FormGroup>
                                            </div>
                                        </Col>
                                        <Col md={4}>
                                            <div className="input-group">
                                                <Label>(Yes/No (Date))</Label>
                                                {
                                                    formik.values.radiation === 'Yes' &&
                                                    <div className="date-picker-container">
                                                        <Input
                                                            id="radiation_date"
                                                            name="radiation_date"
                                                            placeholder="date placeholder"
                                                            max={new Date().toISOString().split('T')[0]}
                                                            min="1980-01-01"
                                                            type="date"
                                                            {...formik.getFieldProps("radiation_date")}
                                                            className={formik.touched.radiation_date && formik.errors.radiation_date ? 'is-invalid' : ""}
                                                        />
                                                        {formik.errors.radiation_date ? <small className='validation_error'>{formik.errors.radiation_date}</small> : null}
                                                    </div>}
                                            </div>
                                        </Col>



                                    </Row>
                                    {/* Third Row Start */}
                                    <Row>
                                        <Col md={2}>
                                            <FormGroup>
                                                <Label for="exampleEmail">
                                                    Immunotherapi
                                                </Label>
                                                <Input
                                                    id="immunotherapi"
                                                    type="select"
                                                    {...formik.getFieldProps('immunotherapi')}
                                                >
                                                    <option value="">Select</option>
                                                    <option value="Yes">Yes</option>
                                                    <option value="No">No</option>
                                                </Input>
                                                {formik.touched.immunotherapi && formik.errors.immunotherapi ? (
                                                    <div className="validation_error">{formik.errors.immunotherapi}</div>
                                                ) : null}

                                            </FormGroup>
                                        </Col>

                                        <Col md={4}>
                                            <div className="input-group">
                                                <Label>(Yes/No (Date))</Label>
                                                {
                                                    formik.values.immunotherapi === 'Yes' &&
                                                    <div className="date-picker-container">
                                                        <Input
                                                            id="immunotherapi_date"
                                                            name="immunotherapi_date"
                                                            placeholder="date placeholder"
                                                            max={new Date().toISOString().split('T')[0]}
                                                            min="1980-01-01"
                                                            type="date"
                                                            {...formik.getFieldProps("immunotherapi_date")}
                                                            className={formik.touched.immunotherapi_date && formik.errors.immunotherapi_date ? 'is-invalid' : ""}
                                                        />
                                                        {formik.errors.immunotherapi_date ? <small className='validation_error'>{formik.errors.immunotherapi_date}</small> : null}
                                                    </div>}
                                            </div>
                                        </Col>

                                        <Col md={2}>
                                            <div className="input-group" >
                                                <Label>Surgery</Label>
                                                <FormGroup>
                                                    <Input
                                                        id="surgery"
                                                        type="select"
                                                        {...formik.getFieldProps('surgery')}
                                                    >
                                                        <option value="">Select</option>
                                                        <option value="Yes">Yes</option>
                                                        <option value="No">No</option>
                                                    </Input>
                                                    {formik.touched.surgery && formik.errors.surgery ? (
                                                        <div className="validation_error">{formik.errors.surgery}</div>
                                                    ) : null}
                                                </FormGroup>
                                            </div>
                                        </Col>
                                        <Col md={4}>
                                            <div className="input-group">
                                                <Label>(Yes/No (Date))</Label>
                                                {
                                                    formik.values.surgery === 'Yes' &&
                                                    <div className="date-picker-container">
                                                        <Input
                                                            id="surgery_date"
                                                            name="surgery_date"
                                                            placeholder="date placeholder"
                                                            max={new Date().toISOString().split('T')[0]}
                                                            min="1980-01-01"
                                                            type="date"
                                                            {...formik.getFieldProps("surgery_date")}
                                                            className={formik.touched.surgery_date && formik.errors.surgery_date ? 'is-invalid' : ""}
                                                        />
                                                        {formik.errors.surgery_date ? <small className='validation_error'>{formik.errors.surgery_date}</small> : null}
                                                    </div>}
                                                {/* <div className="date-picker-container">
                                                    <DatePicker
                                                        selected={selectedDate}
                                                        onChange={handleDateChange}
                                                        dateFormat="dd/MM/yyyy"
                                                        placeholderText="Select"
                                                        className='input-datepicker'
                                                    />
                                                    <div className="calendar-icon">
                                                        <svg
                                                            xmlns="http://www.w3.org/2000/svg"
                                                            width="16"
                                                            height="16"
                                                            fill="currentColor"
                                                            className="bi bi-calendar"
                                                            viewBox="0 0 16 16"
                                                        >
                                                            <path
                                                                fillRule="evenodd"
                                                                d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM1 4v10a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1V4H1z"
                                                            />
                                                        </svg>
                                                    </div>
                                                </div> */}
                                            </div>
                                        </Col>



                                    </Row>
                                    {/* Fourt Row Start */}
                                    <Row>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="clinicalTrialName">Clinical Trail Name (If any)</Label>
                                                <Input
                                                    id="clinicalTrialName"
                                                    type="text"
                                                    {...formik.getFieldProps('clinicalTrialName')}
                                                />
                                                {formik.touched.clinicalTrialName && formik.errors.clinicalTrialName ? (
                                                    <div className="validation_error">{formik.errors.clinicalTrialName}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="clinicalTrialYear">Year</Label>
                                                <Input
                                                    id="clinicalTrialYear"
                                                    type="select"
                                                    {...formik.getFieldProps('clinicalTrialYear')}
                                                >
                                                    <option value="">Select</option>
                                                    {dropDownData?.year.length ?
                                                        dropDownData?.year.map((item, ind) => (

                                                            <option value={item.value} key={ind}>{item.label}</option>
                                                        ))
                                                        : ""
                                                    }
                                                </Input>
                                                {formik.touched.clinicalTrialYear && formik.errors.clinicalTrialYear ? (
                                                    <div className="validation_error">{formik.errors.clinicalTrialYear}</div>
                                                ) : null}
                                            </FormGroup>
                                        </Col>
                                    </Row>

                                    <div className="button-container">
                                        {/* <Link to={'/new-appointment-4'}> */}
                                        <Button color="primary" className='next-button' type="submit">
                                            Next
                                        </Button>
                                        {/* </Link> */}

                                    </div>
                                </Form>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <Footer />

        </>
    )
}

export default NewAppointment3
