import React, { useState, useEffect, useRef } from 'react';
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import Sidebar from '../../common/Sidebar/Sidebar'
import {
    FormGroup, Form, Button, Input, Label, Col, Row, Modal, ModalFooter,
    ModalHeader, ModalBody
} from 'reactstrap'
import { Formik, useFormik } from 'formik'
import AppointNavbar from '../../common/AppointmentNavbar/AppointNavbar'
import Checkpoint from '../../../assests/images/check-read-svgrepo-com.png'
import Footer from '../../common/Footer/Footer'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import authenticationServices from "../../../services";
import { useSelector } from 'react-redux';
import * as Yup from 'yup';
import { toast } from "react-toastify";
import SpinnerLoader from '../../common/Spinner'
import { checkSpace } from '../../../utils';
import CouponForm from '../../common/CouponForm/CouponForm';
import CreditCardForm from '../../common/CreditCardForm/CreditCardForm';
import ModalCmp from '../../common/Modal/Index';
function NewAppointment7() {
    const location = useLocation()
    const dropDownData = useSelector((state) => state.allDropDown.data);
    const navigate = useNavigate()
    const [IsLoader, setIsLoader] = useState(false);
    const [paymentMethod, setpaymentMethod] = useState("");
    const appointmentId = location?.state?.appointmentId
    const [modal, setModal] = useState(false);
    const [openCard, setOpenCard] = useState(false);
    const [OpenCoupan, setOpenCoupan] = useState(false);
    const [OpenSuccess, setOpenSuccess] = useState(false);
    const [isCardAdded, setisCardAdded] = useState(false);
    const [allCardData, setallCardData] = useState([]);
    const [selectedCardId, setselectedCardId] = useState("");

    const successToggle = (routes) => {
        setOpenSuccess(!OpenSuccess)
        // console.log(routes);
        if (routes != undefined) {
            navigate(`${routes}`, { replace: true })
        }
    };

    const cardToggle = () => {
        setOpenCard(!openCard)
    }
    const couponToggle = () => {
        setOpenCoupan(!OpenCoupan)
    }

    useEffect(() => {
        getAllCardApi()
    }, [])

    const getAllCardApi = async () => {
        try {
            setIsLoader(true);
            let res = await authenticationServices.getAllCard();
            // console.log("getAllCard>>>==", res);
            if (res.data.status === 200) {
                setIsLoader(false);
                const result = res.data.data.addCardDetails
                setallCardData(result)
            }
        } catch (error) {
            setIsLoader(false);
            toast.error(error, {
                position: toast.POSITION.TOP_RIGHT,
            });
        }
    }


    // useEffect to redirect step 1 if previous form not submitted
    // useEffect(() => {
    //     if (appointmentId === '' || appointmentId === undefined) {
    //         navigate("/new-appointment-1")
    //     }
    // }, [appointmentId])
    useEffect(() => {
        if (paymentMethod != "card" && paymentMethod != "coupon") {
            setselectedCardId(paymentMethod)
        } else {
            setselectedCardId('')
        }
        if (paymentMethod === "card") {
            cardToggle()
        }
        // if (selectedCardId) {
        //     cardToggle()
        // }
        if (paymentMethod === "coupon") {
            couponToggle()
        }
    }, [paymentMethod])

    useEffect(() => {
        if (selectedCardId) {
            cardToggle()
        }
    }, [selectedCardId])

    const handleSubmit = async () => {
        successToggle()
        const payload = {
            "cardId": selectedCardId,
            "appointmentId": appointmentId
        }
        try {
            console.log("appointmentBook step 7 payload=", payload);
            setIsLoader(true);
            let res = await authenticationServices.appointmentBook(payload, 7);
            console.log("appointmentBook step 7 result==", res);
            if (res.data.status === 200) {
                setIsLoader(false);
                successToggle()
                // toast.success(res.data.message, {
                //     position: toast.POSITION.TOP_RIGHT,
                // });
            } else {
                setIsLoader(false);
                toast.error(res.data.message, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        } catch (error) {
            toast.error(error, {
                position: toast.POSITION.TOP_RIGHT,
            });
        }
    }

    const cardAdded = (value) => {
        console.log("value+++", value);
        setisCardAdded(value)
    }

    return (
        <>
            <div className="new-appointment7">
                {IsLoader && <SpinnerLoader />}
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className=" parent-div">
                        <Sidebar />
                        <div className=" child-div">
                            <div className="child-navabar">
                                <AppointNavbar />
                            </div>

                            <div className="crad-payment-details">


                                <Form >
                                    <Col md={12}>
                                        <FormGroup>
                                            <Label>Payment Option</Label>
                                            <Input
                                                name='paymentMethod'
                                                id='paymentMethod'
                                                type='select'
                                                value={paymentMethod}
                                                onChange={(e) => setpaymentMethod(e.target.value)}
                                                className='form-control'
                                            >

                                                <option value="">Select Payment Method</option>
                                                <option value="card">Add Card Details</option>
                                                <option value="coupon">Coupon Code</option>
                                                {allCardData?.length ?
                                                    allCardData?.map((item, ind) => (
                                                        <option value={item._id} key={ind}>Card - {item?.cardNumber}</option>
                                                    ))

                                                    : null}
                                            </Input>
                                        </FormGroup>
                                    </Col>

                                </Form>
                                {/* {
                                    paymentMethod === "coupon"
                                        ?
                                        <CouponForm />
                                        :
                                        < CreditCardForm allCardData={allCardData} selectedCardId={selectedCardId} />

                                } */}

                            </div>
                            <div className="button-container" >
                                <Button color={!isCardAdded ? "secondary" : "primary"} className='next-button' onClick={handleSubmit} style={{ cursor: "pointer" }} disabled={!isCardAdded}>
                                    Submit
                                </Button>

                            </div>
                        </div>
                    </div>
                </div>
                <Modal isOpen={openCard} className="custom-modal ">
                    <div className="modal-overlay credit-card-modal">
                        <ModalHeader toggle={cardToggle} />
                        <ModalBody>
                            <div style={{ textAlign: '' }}>
                                < CreditCardForm allCardData={allCardData} selectedCardId={selectedCardId} openCard={openCard} setOpenCard={setOpenCard} getAllCardApi={getAllCardApi} cardAdded={cardAdded} />
                                {/* <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '120px' }}>
                                    <img src={Checkpoint} alt="Icon" />
                                </div>
                                <div >
                                    <h2 style={{ fontSize: "22px", marginBottom: "15px" }}>
                                        Your appointment has been requested. You will get a notification soon.
                                    </h2>

                                </div> */}
                            </div>
                        </ModalBody>
                    </div>
                </Modal>
                <Modal isOpen={OpenCoupan} className="custom-modal">
                    <div className="modal-overlay credit-card-modal">
                        <ModalHeader toggle={couponToggle} />
                        <ModalBody>
                            <div style={{ textAlign: 'left' }}>
                                <CouponForm />
                                {/* <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '120px' }}>
                                    <img src={Checkpoint} alt="Icon" />
                                </div>
                                <div >
                                    <h2 style={{ fontSize: "22px", marginBottom: "15px" }}>
                                        Your appointment has been requested. You will get a notification soon.
                                    </h2>

                                </div> */}
                            </div>
                        </ModalBody>
                    </div>
                </Modal>
                <Modal isOpen={OpenSuccess} className="custom-modal">
                    <div className="modal-overlay credit-card-modal">
                        <ModalHeader toggle={() => successToggle("/scheduled-appointments")} />
                        <ModalBody>
                            <div style={{ textAlign: 'center' }}>
                                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '120px' }}>
                                    <img src={Checkpoint} alt="Icon" />
                                </div>
                                <div >
                                    <h2 style={{ fontSize: "22px", marginBottom: "15px" }}>
                                        Your appointment has been requested. You will get a notification soon.
                                    </h2>

                                </div>
                            </div>
                        </ModalBody>
                    </div>
                </Modal>
                {/* {openModal && <ModalCmp openModal={openModal} setOpenModal={setOpenModal}></ModalCmp>} */}
            </div>
            <Footer />


        </>
    )
}

export default NewAppointment7
