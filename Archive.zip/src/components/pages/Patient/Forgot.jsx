import React, { useState } from 'react'
import { FormGroup, Input, Label, Form, FormText, Button } from 'reactstrap';
import cpnLogo from "../../../assests/images/CPNHealthFINAL_fontembed.svg";
import patientForgot from "../../../assests/images/Mask Group 16.png";
import { useNavigate, useLocation } from 'react-router-dom';
import { useFormik } from "formik";
import * as Yup from "yup";
import { checkSpace } from "../../../utils";
import authenticationServices from "../../../services";
import authenticationCpnIsServices from "../../../services/cpnIsServices";
import authenticationExpertServices from "../../../services/expertServices";
import { toast } from "react-toastify";
import SpinnerLoader from '../../common/Spinner';
const PatientForgot = () => {
    const navigate = useNavigate()
    const location = useLocation()
    console.log("location=-=++++=>>", location);
    const comingFrom = location?.state?.comingFrom
    const [IsLoader, setIsLoader] = useState(false);
    const formik = useFormik({
        initialValues: {
            email: "",
        },
        validationSchema: Yup.object({
            email: Yup.string().email("Invalid email address").required("*Email is required."),
        }),

        onSubmit: async (values) => {
            const payload = {
                emailId: values.email,
            };
            try {
                // console.log("login payload=", payload);
                setIsLoader(true);
                let res;
                if (comingFrom === "cpn-login") {
                    res = await authenticationCpnIsServices.cpnForgetPassword(payload);
                } else if (comingFrom === "expert-login") {
                    res = await authenticationExpertServices.expertForgetPassword(payload);
                }
                else {
                    res = await authenticationServices.patientForgetPassword(payload);
                }
                console.log("forget result==", res);
                if (res.data.status === 200) {
                    setIsLoader(false);
                    const userId = res?.data?.response?.userId
                    navigate("/otp", { state: { userId: userId, comingFrom: comingFrom } })
                    toast.success(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });

                } else {
                    setIsLoader(false);
                    toast.error(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                }
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        },
    });

    return (
        <div className='patient-forgot'>
            {IsLoader && <SpinnerLoader />}
            <div className="container-fluid ">
                <div className="image">
                    <img src={patientForgot} />
                    <div className="content-image">
                        <p>The Checkpoint Now</p>
                        <h1> Consult our trusted cancer experts</h1>
                        <h6>- We understand cancer, its treatments and its side effects </h6>
                        <h6>- Make An Appointment </h6>
                    </div>
                </div>

                {/* Second Right side */}

                <div className="right-side">
                    <div className="form-container">

                        <img className='right-div-logo' src={cpnLogo} alt="Logo" />
                        <h1 className='login-expert'>Forgot Password</h1>
                        <div className="logo-patient-para">
                            <p>Enter your email for the verification process, we will send 4 digits code to your email.</p>
                        </div>

                        <Form onSubmit={formik.handleSubmit} className='form-size'>
                            <FormGroup>
                                <Label for="exampleEmail">
                                    Email Address
                                </Label>
                                <Input
                                    id="exampleEmail"
                                    name="email"
                                    placeholder="Enter Email Address"
                                    type="email"
                                    {...formik.getFieldProps("email")}
                                    onKeyDown={checkSpace}
                                    invalid={formik.touched.email && formik.errors.email ? true : false}
                                />
                                {formik.touched.email && formik.errors.email ? <small className="validation_error">{formik.errors.email}</small> : null}
                            </FormGroup>

                            <Button className='btn-secondry mt-4' type='submit'>
                                Continue
                            </Button>


                        </Form>

                        <div className="last-form-content mt-4">
                            {/* <!-- <p>Forgot Password</p>

                                    <h6>Don't have an account?<a href="" style="font-size: 14px;">Sign Up </a>
                                    </h6> --> */}

                            <h3 onClick={() => navigate(-1)}>Go to Back</h3>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    )
}

export default PatientForgot