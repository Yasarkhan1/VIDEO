import React, { useState, useEffect } from 'react'
import { FormGroup, Input, Progress, Label, Button, Form } from 'reactstrap';
import tick from "../../../assests/images/check-circle-svgrepo-com (2).svg";
import blueTick from "../../../assests/images/blue-tick.svg";
import cpnLogo from "../../../assests/images/CPNHealthFINAL_fontembed.svg";
import Footer from '../../common/Footer/Footer';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { useFormik } from "formik";
import * as Yup from "yup";
import authenticationServices from "../../../services";
import { toast } from "react-toastify";
import { checkSpace, detectPlatform } from "../../../utils";
import { deviceToken } from "../../../getDeviceToken";
const PatientSignup3 = () => {
    const navigate = useNavigate()
    const location = useLocation()
    const step2Payload = location?.state?.step2Payload
    const [IsLoader, setIsLoader] = useState(false);
    const [acceptPrivacy, setAcceptPrivacy] = useState(false)
    const [acceptTnC, setAcceptTnC] = useState(false)

    useEffect(() => {
        const patientSignupData = localStorage.getItem("patientSignupData")
            ? JSON.parse(localStorage.getItem("patientSignupData"))
            : "";
        const { email, password } = patientSignupData
        if (!email || !password) {
            navigate('/signup-as-patient-1')
        }
    }, [])

    const deviceType = detectPlatform()
    let devicetoken = "";
    deviceToken.subscribe((res) => {
        devicetoken = res;
    });

    const formik = useFormik({
        initialValues: {
            fullName: "",
        },
        validationSchema: Yup.object({
            fullName: Yup.string()
                .required("*First name is required.")
                .min(3, "minimum three character are required."),
        }),

        onSubmit: async (values) => {
            const patientSignupData = localStorage.getItem("patientSignupData")
                ? JSON.parse(localStorage.getItem("patientSignupData"))
                : "";
            const { email, password } = patientSignupData
            if (!acceptPrivacy) {
                toast.warn("Please select Data privacy aggrement", {
                    position: toast.POSITION.TOP_RIGHT,
                });
                return
            }
            else if (!acceptTnC) {
                toast.warn("Please select Terms & conditions", {
                    position: toast.POSITION.TOP_RIGHT,
                });
                return
            } else {
                const payload = {
                    ...patientSignupData,
                    fullName: values.fullName
                };

                try {
                    console.log("Final patient details payload=", payload);
                    const jsonData = step2Payload
                    const formData = new FormData();
                    formData.append("email", jsonData.email);
                    formData.append("password", jsonData.password);
                    formData.append("name", jsonData.name);
                    formData.append("dateOfBirth", jsonData.dateOfBirth);
                    formData.append("sex", jsonData.sex);
                    formData.append("address", jsonData.address);
                    formData.append("contactNumber", jsonData.contactNumber);
                    formData.append("country", jsonData.country);
                    formData.append("image", jsonData.image); // Convert object to string
                    formData.append("countryCode", jsonData.countryCode);
                    formData.append("deviceType", deviceType);
                    formData.append("deviceToken", devicetoken);
                    formData.append("hipaaAgreement", JSON.stringify(jsonData.hipaaAgreement))
                    // console.log("fformData", JSON.stringify(jsonData.hipaaAgreement));
                    setIsLoader(true);
                    let res = await authenticationServices.patientSignup(formData);
                    // console.log("login result==", res);
                    if (res.data.status === 200) {
                        localStorage.clear()
                        toast.success(res.data.message, {
                            position: toast.POSITION.TOP_RIGHT,
                        });
                        navigate("/login-as-patient")
                    } else {
                        setIsLoader(false);
                        toast.error(res.data.message, {
                            position: toast.POSITION.TOP_RIGHT,
                        });
                    }
                } catch (error) {
                    toast.error(error, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                }
            }
        }
    });



    return (
        <>
        
        <div className='patient-sign-aggrement'>
            <div className="container">
                <div className="logo-container">
                    <div className="logo-cpn">
                        <Link to="/">
                            <img src={cpnLogo} alt="Logo" />
                        </Link>
                    </div>
                    <div className="login-button">
                        <Link to="/login-as-patient">
                            <Button>
                                Login
                            </Button>
                        </Link>
                    </div>
                </div>
                <div className="otp-input">
                    <Progress multi>
                        <Progress
                            bar
                            value="33.33"
                            style={{
                                height: '5px'
                            }}
                        />
                        <Progress
                            bar
                            color="success"
                            value="33.33"

                        />
                        <Progress
                            bar
                            color="info"
                            value="33.33"

                        />
                    </Progress>
                </div>
                <div className="text-sign-up">
                    <h1>Sign Up as a Patient</h1>
                </div>

                <div className="text-sign-up-2">
                            <img src={tick} alt="" />
                            <h1>Sign HiPAA Agreement, CPN Agreement</h1>
                        </div>
            </div>
            <div className="container">
                <div className="content-date">
                    <div className="login-detail">
                        <div className="login-detail-img">
                            <img src={tick} alt="" />
                            <h1>Login Details</h1>
                        </div>
                        
                        <div className="login-detail-img2-data">
                            <img src={tick} alt="" />
                            <h1>Personal Details</h1>
                        </div>
                        <div className="login-detail-img3-data">
                            <img src={tick} alt="" />
                            <h1>Sign HiPAA Agreement, CPN Agreement</h1>
                        </div>
                    </div>
                    <div className="form-data-container">

                        <Form onSubmit={formik.handleSubmit}>
                            <h6 className='sign-line'>Please read and sign agreement before proceeding</h6>
                            <FormGroup check>
                                <Input type="checkbox" onChange={(e) => setAcceptPrivacy(e.target.checked)} checked={acceptPrivacy} />
                                {' '}
                                <Label check>
                                    <Link to=""> Data Privacy Agreement</Link>
                                </Label>
                            </FormGroup>
                            <FormGroup check>
                                <Input type="checkbox" onChange={(e) => setAcceptTnC(e.target.checked)} checked={acceptTnC} />
                                {' '}
                                <Label check>
                                    <Link to=""> Terms & Conditions</Link>
                                </Label>
                            </FormGroup>
                            <FormGroup>
                                <div className="signagreement-c">
                                    <Label for="exampleAddress" className='exampleaddress'>
                                        Sign Agreement
                                    </Label>
                                    <Input
                                        id="exampleAddress"
                                        name="Sign Agreement"
                                        placeholder="Enter Full Name"
                                        type="text"
                                        {...formik.getFieldProps("fullName")}
                                        onKeyDown={checkSpace}
                                        className={formik.touched.fullName && formik.errors.fullName ? 'is-invalid' : ""}
                                    />
                                    {formik.touched.fullName && formik.errors.fullName ? <small className="validation_error">{formik.errors.fullName}</small> : null}

                                </div>
                            </FormGroup>



                            <Button className='btn-secondry' type='submit'>
                                Next
                            </Button>
                        </Form>
                        <br />
                        <div className="last-form-content mb-4">
                            <Link to="/signup-as-patient-2"><h3>Go to Back</h3></Link>
                        </div>
                    </div>
                </div>
            </div>
           
        </div>
        <Footer />
        
        </>
    )
}

export default PatientSignup3