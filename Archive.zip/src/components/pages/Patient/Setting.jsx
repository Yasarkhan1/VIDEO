import React from 'react'
import { Table } from 'reactstrap'
import { Link, useNavigate } from 'react-router-dom'
import { Progress, Form, FormGroup, Button } from 'reactstrap'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import Logoimage from '../../../assests/images/ys.png'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import Sidebar from '../../common/Sidebar/Sidebar'

function Setting() {
    const navigate = useNavigate();

    const logoutHandle = () => {
        console.log("logout called");
        sessionStorage.clear();
        // localStorage.clear();
        navigate("/")
        // window.location.reload()
    }
    return (
        <>
            <div className='setting'>
                <LoginNavbar />
                <div className="container mb-5">
                    <div className="parent-div">
                        <Sidebar />
                        <div className="child-div">
                            <div className="middle-contnet">
                                <div className="container overflow-hidden ">
                                    <div className="row gy-5">
                                        <div className="col-6">
                                            <div className="p-4">
                                                <h6> My Profile</h6></div>
                                        </div>
                                        <div className="col-6">
                                            <div className="p-3">
                                                <Link to="/my-profile-edit" style={{ padding: "0px 120px" }}>Edit</Link>
                                            </div>
                                        </div>

                                    </div>
                                    <div className="line"></div>
                                </div>
                                <div className="container overflow-hidden ">
                                    <div className="row gy-5">
                                        <div className="col-6">
                                            <div className="p-3">
                                                <h6>Change Password</h6></div>
                                        </div>
                                        <div className="col-6">
                                            <div className="p-3">
                                                <Link to="/change-password" style={{ padding: "0px 120px" }}>Update</Link>
                                            </div>
                                        </div>

                                    </div>
                                    <div className="line"></div>
                                </div>
                                <div className="container overflow-hidden">
                                    <div className="row gy-5">
                                        <div className="col-6">
                                            <div className="p-3">
                                                <h6>Notification</h6> </div>
                                        </div>
                                        <div className="col-6">
                                            <div className="p-3">
                                                <label className="switch">
                                                    <input type="checkbox" id="toggle" />
                                                    <span className="slider" ></span>
                                                </label>
                                            </div>
                                        </div>

                                    </div>
                                    <div className="line"></div>
                                </div>

                                <div className="container overflow-hidden">
                                    <div className="row gy-5">
                                        <div className="col-6">
                                            <div className="p-3" onClick={() => logoutHandle()}>
                                                Logout                                                {/* <Link to="/login-as-patient">Logout</Link> */}
                                            </div>
                                        </div>


                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <Footer />


        </>
    )
}

export default Setting
