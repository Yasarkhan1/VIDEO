import React, { useEffect } from 'react'
import { Table } from 'reactstrap'
import { Link, useNavigate } from 'react-router-dom'
import { Progress, Form, FormGroup, Button, Row, Label, Input, Col } from 'reactstrap'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import Logoimage from '../../../assests/images/ys.png'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import { useFormik } from 'formik'
import { checkSpace } from "../../../utils";
import * as Yup from "yup";
import { toast } from "react-toastify";
import { object } from 'prop-types'
import Sidebar from '../../common/Sidebar/Sidebar'
import dayjs from 'dayjs'

function MedicalInformation3() {

    useEffect(() => {
        const medicalStepData = localStorage.getItem("medicalStepData")
            ? JSON.parse(localStorage.getItem('medicalStepData'))
            : "";
        if (medicalStepData && Object.keys(medicalStepData)?.length && medicalStepData.hasOwnProperty("currentTreatment")) {

            getPatchform();
        }
    }, [])

    const convertDate = (inputDate) => {
        const parsedDate = dayjs(inputDate, 'DD-MM-YYYY');
        const formattedDate = parsedDate.format('YYYY-MM-DD');
        return formattedDate;
    };
    // fill to getpatch data
    const getPatchform = () => {
        const medicalStepData = localStorage.getItem("medicalStepData")
            ? JSON.parse(localStorage.getItem("medicalStepData"))
            : "";
        // if (Object.keys(medicalStepData)?.length && Object.keys(medicalStepData?.currentTreatment)?.length && Object.keys(medicalStepData?.oncologyTeam)?.length && Object.keys(medicalStepData?.diseaseHistory)?.length && Object.keys(medicalStepData?.surgicalHistory)?.length) {
{
            // const { currentTreatment: { cancer_name, cancer_date, name_of_provider, office_name, contact_number
            //     , fax_number, clinical_trail_name, name_of_disease, year_of_diagnosis, year_of_diagnosis1
            //     , name_of_disease1, current } } = currentTreatment

            const { currentTreatment, oncologyTeam, diseaseHistory, surgicalHistory } = medicalStepData
            console.log("currentTreatment", currentTreatment, oncologyTeam, diseaseHistory, surgicalHistory);


            formik.setValues({
                cancer_name: currentTreatment?.cancer_name,
                cancer_date: convertDate(currentTreatment?.cancer_date),
                name_of_provider: oncologyTeam?.name_of_provider,
                office_name: oncologyTeam?.office_name,
                contact_number: oncologyTeam?.contact_number,
                fax_number: oncologyTeam?.fax_number,
                clinical_trail_name: oncologyTeam?.clinical_trail_name,
                name_of_disease: diseaseHistory?.name_of_disease,
                year_of_diagnosis:diseaseHistory?.year_of_diagnosis,
                name_of_disease1: surgicalHistory?.name_of_disease1,
                year_of_diagnosis1: surgicalHistory?.year_of_diagnosis1,
                current: surgicalHistory?.current,
            });


        }
    };

    const validationSchema = Yup.object().shape({
        cancer_name: Yup.string().required("Enter type cancer."),
        cancer_date: Yup.string().required("Enter date."),
        name_of_provider: Yup.string().required("Please enter."),
        office_name: Yup.string().required("Enter office name."),
        // contact_number: Yup.string().required("Enter your number."),
        contact_number: Yup.string()
            .required("*Contact number is required.")
            .matches(
                /^[6-9]{1}[0-9]{9}$/,
                "Enter valid contact number"
            ),

        fax_number: Yup.string().required("Enter number."),
        clinical_trail_name: Yup.string().required("Enter contact number."),
        name_of_disease: Yup.string().required("Enter disease name."),
        year_of_diagnosis: Yup.string().required("Enter your daigonis."),
        name_of_disease1: Yup.string().required("Enter name disease."),
        year_of_diagnosis1: Yup.string().required("Please select."),
        current: Yup.string().required("Please select.")

    });
    const formik = useFormik({
        initialValues: {
            cancer_name: '',
            cancer_date: '',
            name_of_provider: '',
            office_name: '',
            contact_number: '',
            fax_number: '',
            clinical_trail_name: '',
            name_of_disease: '',
            year_of_diagnosis: '',
            name_of_disease1: '',
            year_of_diagnosis1: '',
            current: '',
        },

        validationSchema: validationSchema,
        onSubmit: async (values) => {
            // const step1Data = localStorage.getItem("currentTreatment")
            //     ? JSON.parse(localStorage.getItem("currentTreatment"))
            //     : "";
            // // const { type_of_cancer, year_of_diagnosis } = step1Data
            const previousFormData = localStorage.getItem("medicalStepData")
                ? JSON.parse(localStorage.getItem("medicalStepData"))
                : "";

            const payload = {

                ...previousFormData,
                "currentTreatment": {
                    "cancer_name": values.cancer_name,
                    "cancer_date": values.cancer_date ? dayjs(values.cancer_date).format('DD-MM-YYYY') : "NULL",
                },
                "oncologyTeam": {
                    "name_of_provider": values.name_of_provider,
                    "office_name": values.office_name,
                    "contact_number": values.contact_number.toString(),
                    "fax_number": values.fax_number.toString(),
                    "clinical_trail_name": values.clinical_trail_name
                },
                "diseaseHistory": {
                    "name_of_disease": values.name_of_disease,
                    "year_of_diagnosis": values.year_of_diagnosis
                },
                "surgicalHistory": {
                    "name_of_disease1": values.name_of_disease1,
                    "year_of_diagnosis1": values.year_of_diagnosis1,
                    "current": values.current
                },





            };
            console.log("payload")


            try {
                console.log("currentTreatment payload=", payload);
                // localStorage.setItem("currentTreatment", JSON.stringify(payload));
                localStorage.setItem("medicalStepData", JSON.stringify(payload));
                navigate("/medical-information4")
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        }
    });
    console.log("formik", formik.errors)
    const navigate = useNavigate();

    return (
        <>
            <div className='medical-information3'>
                <LoginNavbar />
                <div className="container mb-5">
                    <div className="parent-div">
                        <Sidebar />

                        <div className="child-div">
                            <div className="progress-bar-container">
                                <div className="progress-bar">
                                    <span>2</span>
                                </div>
                            </div>
                            <div className="middle-content">
                                <Form onSubmit={formik.handleSubmit}>
                                    <Row>
                                        <h1>Current Treatment</h1>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleText">
                                                    Cancer Name
                                                </Label>
                                                <Input

                                                    name="cancer_name"
                                                    type="text"
                                                    placeholder='Enter Type of Cancer'
                                                    {...formik.getFieldProps("cancer_name")}
                                                    className={formik.touched.cancer_name && formik.errors.cancer_name ? 'is-invalid' : ""}
                                                />

                                                {formik.touched.cancer_name && formik.errors.cancer_name ? <small className='validation_error'>{formik.errors.cancer_name}</small> : ""}

                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleDate">
                                                    Date
                                                </Label>
                                                <Input
                                                    name="cancer_date"
                                                    type="date"
                                                    placeholder='Select Date'
                                                    {...formik.getFieldProps("cancer_date")}
                                                    className={formik.touched.cancer_date && formik.errors.cancer_date ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.cancer_date && formik.errors.cancer_date ? <small className='validation_error'>{formik.errors.cancer_date}</small> : ""}
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <h1>Oncology Team</h1>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleText">
                                                    Name of Provider
                                                </Label>
                                                <Input

                                                    name="name_of_provider"
                                                    type="text"
                                                    placeholder='Enter Type of Cancer'
                                                    {...formik.getFieldProps("name_of_provider")}
                                                    className={formik.touched.name_of_provider && formik.errors.name_of_provider ? 'is-invalid' : ""}
                                                />

                                                {formik.touched.name_of_provider && formik.errors.name_of_provider ? <small className='validation_error'>{formik.errors.name_of_provider}</small> : ""}

                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleText">
                                                    Office Name
                                                </Label>
                                                <Input

                                                    name="office_name"
                                                    type="text"
                                                    placeholder='Enter Office Name'
                                                    {...formik.getFieldProps("office_name")}
                                                    className={formik.touched.office_name && formik.errors.office_name ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.office_name && formik.errors.office_name ? <small className='validation_error'>{formik.errors.office_name}</small> : ""}
                                            </FormGroup>
                                        </Col>

                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleText">Contact Number

                                                </Label>
                                                <Input
                                                    name="contact_number"
                                                    type="number"
                                                    placeholder='Enter Contact Number'
                                                    {...formik.getFieldProps("contact_number")}
                                                    onKeyDown={checkSpace}
                                                    onInput={(e) => (e.target.value = e.target.value.slice(0, 10))}
                                                    onWheel={(e) => e.target.blur()}
                                                    className={formik.touched.contact_number && formik.errors.contact_number ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.contact_number && formik.errors.contact_number ? <small className='validation_error'>{formik.errors.contact_number}</small> : ""}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label>FAX Number</Label>
                                                <Input

                                                    name="fax_number"
                                                    type="number"
                                                    placeholder='Enter fax_number'
                                                    {...formik.getFieldProps("fax_number")}
                                                    onKeyDown={checkSpace}
                                                    onInput={(e) => (e.target.value = e.target.value.slice(0, 8))}
                                                    onWheel={(e) => e.target.blur()}
                                                    className={formik.touched.fax_number && formik.errors.fax_number ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.fax_number && formik.errors.fax_number ? <small className='validation_error'>{formik.errors.fax_number}</small> : ""}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <Label for="exampleNumber">Clinical Trail Name (If any)</Label>
                                            <Input

                                                name="clinical_trail_name"
                                                type="text"
                                                placeholder='Enter Contact Number'
                                                {...formik.getFieldProps("clinical_trail_name")}
                                                onKeyDown={checkSpace}
                                                onInput={(e) => (e.target.value = e.target.value.slice(0, 10))}
                                                onWheel={(e) => e.target.blur()}
                                                className={formik.touched.clinical_trail_name && formik.errors.clinical_trail_name ? 'is-invalid' : ""}
                                            />
                                            {formik.touched.clinical_trail_name && formik.errors.clinical_trail_name ? <small className='validation_error'>{formik.errors.clinical_trail_name}</small> : ""}
                                        </Col>

                                    </Row>

                                    <Row className='my-3'>
                                        <h1>Medical History</h1>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleText">Name of Disease</Label>
                                                <Input

                                                    name="name_of_disease"
                                                    type="text"
                                                    placeholder='Enter name_of_disease'
                                                    {...formik.getFieldProps("name_of_disease")}
                                                    className={formik.touched.name_of_disease && formik.errors.name_of_disease ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.name_of_disease && formik.errors.name_of_disease ? <small className='validation_error'>{formik.errors.name_of_disease}</small> : ""}
                                            </FormGroup>
                                        </Col>

                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleFile">Year of Diagnosis</Label>
                                                <Input
                                                    name="year_of_diagnosis"
                                                    type="select"
                                                    {...formik.getFieldProps("year_of_diagnosis")}
                                                    className={formik.touched.year_of_diagnosis && formik.errors.year_of_diagnosis ? 'is-invalid' : ""}
                                                >
                                                    <option>Select Year</option>
                                                    <option>2023</option>
                                                    <option>2022</option>
                                                    <option>2021</option>
                                                </Input>
                                                {formik.touched.year_of_diagnosis && formik.errors.year_of_diagnosis ? <small className='validation_error'>{formik.errors.year_of_diagnosis}</small> : ""}
                                            </FormGroup>
                                        </Col>

                                    </Row>
                                    <Row>
                                        <h1>Surgical History</h1>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleFile">Name</Label>
                                                <Input

                                                    name="name_of_disease1"
                                                    type="text"
                                                    placeholder='Enter Name of Disease'
                                                    {...formik.getFieldProps("name_of_disease1")}
                                                    className={formik.touched.name_of_disease1 && formik.errors.name_of_disease1 ? 'is-invalid' : ""}

                                                />
                                                {formik.touched.name_of_disease1 && formik.errors.name_of_disease1 ? <small className='validation_error'>{formik.errors.name_of_disease1}</small> : ""}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleFile">Year of Diagnosis</Label>
                                                <Input

                                                    name="year_of_diagnosis1"
                                                    type="select"
                                                    placeholder='Enter Name of Disease'
                                                    {...formik.getFieldProps("year_of_diagnosis1")}
                                                    className={formik.touched.year_of_diagnosis1 && formik.errors.year_of_diagnosis1 ? 'is-invalid' : ""}

                                                >
                                                    <option>Select Year</option>
                                                    <option>2023</option>
                                                    <option>2022</option>
                                                    <option>2021</option>
                                                </Input>
                                                {formik.touched.year_of_diagnosis1 && formik.errors.year_of_diagnosis1 ? <small className='validation_error'>{formik.errors.year_of_diagnosis1}</small> : ""}

                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label for="exampleFile">Current (Yes/No)</Label>
                                                <Input

                                                    name="current"
                                                    type="select"
                                                    placeholder='Enter Name of Disease'
                                                    {...formik.getFieldProps("current")}
                                                    className={formik.touched.current && formik.errors.current ? 'is-invalid' : ""}


                                                >
                                                    <option>Select</option>
                                                    <option>Yes</option>
                                                    <option>No</option>
                                                </Input>
                                                {formik.touched.current && formik.errors.current ? <small className='validation_error'>{formik.errors.current}</small> : ""}
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <Button className='btn-secondry' type='submit'>
                                        Next
                                    </Button>
                                </Form>

                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <Footer />


        </>
    )
}

export default MedicalInformation3
