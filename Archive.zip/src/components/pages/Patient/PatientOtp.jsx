import React, { useState, useEffect } from 'react';
import patientOtp from "../../../assests/images/Mask Group 16.png";
import cpnLogo from "../../../assests/images/CPNHealthFINAL_fontembed.svg";
import OtpInput from "react-otp-input";
import { useNavigate, useLocation } from 'react-router-dom';
import authenticationServices from "../../../services";
import { toast } from "react-toastify";
import SpinnerLoader from '../../common/Spinner';
const PatientOtp = () => {
    const navigate = useNavigate()
    const location = useLocation()
    const comingFrom = location?.state?.comingFrom
    const [otpValue, setOtpValue] = useState(null);
    const [IsLoader, setIsLoader] = useState(false);
    const handleOtpChange = (otp) => {
        setOtpValue(otp);
    };
    const { state } = useLocation();
    const userId = state?.userId ? state?.userId : ""


    useEffect(() => {
        if (!userId) {
            navigate("/")
        }
    }, [state])
    const handleSubmitOtp = async () => {
        try {
            if (otpValue?.length === 4) {
                const payload = {
                    userId: userId,
                    enteredOTP: otpValue
                }
                setIsLoader(true);
                let res = await authenticationServices.verifyOtp(payload);
                console.log("otp result==", res);
                if (res.data.status === 200) {
                    setIsLoader(false);
                    toast.success(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                    navigate("/reset-password", { state: { userId: userId, comingFrom: comingFrom } })
                }
                else {
                    setIsLoader(false);
                    toast.error(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                }

            }
            else {
                toast.warn("Please enter 4 digit of OTP send to you", {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        } catch (error) {
            toast.error(error, {
                position: toast.POSITION.TOP_RIGHT,
            });
        }

    }
    return (
        <div className='patient-otp'>
            {IsLoader && <SpinnerLoader />}

            <div className="container-fluid ">
                <div className="image">
                    <img src={patientOtp} />
                    <div className="content-image">
                        <p>The Checkpoint Now</p>
                        <h1>Consult our trusted cancer experts</h1>
                        <h6>- We understand cancer, its treatments and its side effects </h6>
                        <h6>- Make An Appointment </h6>
                    </div>
                </div>
                <div className="right-side">
                    <div className="form-container">
                        <img className='right-div-logo' src={cpnLogo} alt="Logo" />
                        <h1 className='login-expert'>Enter 4 Digits Code</h1>
                            <p className="logo-as-patient-para">Enter the 4 digits code that you received on your email.</p>
                        
                        {/* <form> */}
                        <div className="otp-filed-input">
                            <OtpInput
                                value={otpValue}
                                onChange={handleOtpChange}
                                numInputs={4}
                                inputStyle={"otpColor"}
                                isInputNum
                            // inputType="number"
                            // renderInput={(props) => <input {...props} />}
                            // focusStyle={{ outline: "none", border: "2px solid #30A782", borderRadius: "8px" }}
                            />
                        </div>
                        <button className="btn-login" onClick={handleSubmitOtp}>Continue </button>
                        <div className="last-form-content" onClick={() => navigate(-1)}>
                            <h3>Go to Back</h3>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    )
}

export default PatientOtp