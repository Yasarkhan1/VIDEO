import React, { useEffect, useState } from 'react'
import { Table } from 'reactstrap'
import { Link } from 'react-router-dom'
import { Progress, Form, FormGroup, Button, Modal, ModalHeader, ModalBody, ModalFooter, Input, Label } from 'reactstrap'
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import medical from '../../../assests/images/file-medical-alt-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import Logoimage from '../../../assests/images/ys.png'
import Footer from '../../common/Footer/Footer'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import Sidebar from '../../common/Sidebar/Sidebar'
import authenticationExpertServices from "../../../services/expertServices";
import { toast } from "react-toastify";
import SpinnerLoader from '../../common/Spinner';
import { useSelector, useDispatch } from 'react-redux';

function CompletedAppointments() {

    const [modal, setModal] = useState(false);
    const [open1, setOpen1] = useState(false);
    const surveyToggle = () => { setOpen1(!open1) };
    const toggle = () => { setModal(!modal) };




    const [IsLoader, setIsLoader] = useState(false);
    const userData = useSelector((state) => state.user.data);
    const [allsurvey, setAllsurvey] = useState([]);

    const AllSurvey = async () => {
        try {
            setIsLoader(true);
            let res = await authenticationExpertServices.getAllSurvey();
            console.log("getAllSurvey ===>>", res);
            if (res.data.status === 200) {
                const result = res.data.survey[0]?.questions;
                setAllsurvey(result);
                setIsLoader(false);
                toast.success(res.data.message, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            } else {
                setIsLoader(false);
                toast.error(res.data.message, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        } catch (error) {
            toast.error(error, {
                position: toast.POSITION.TOP_RIGHT,
            });
        }
    }

    useEffect(() => {
        AllSurvey();
    }, []);
    console.log(allsurvey)
    return (
        <>
            <div className="completed-appointments">
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className="parent-div">
                        <Sidebar />
                        <div className="child-div">
                            <div class="child-navabar text-center">

                                <h6>Completed Appointment</h6>
                            </div>
                            <div class="dot-line"></div>

                            <div className="container-table">

                                <table className="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">S.No.</th>
                                            <th scope="col">Date & Time</th>
                                            <th scope="col">Service</th>
                                            <th scope="col">Service Charge</th>
                                            <th scope='col'>EC Name</th>
                                            <th scope='col'>Status</th>
                                            <th scope='col'>Payment</th>
                                            <th scope='col'>Notes</th>
                                            <th scope='col'>Survey</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row">1</th>
                                            <td>23 May 2023, 10:00AM</td>
                                            <td>Consultation</td>
                                            <td>$100</td>
                                            <td>Dr. Abdul Kareem</td>
                                            <td>Completed</td>
                                            <td>Pending</td>
                                            <td> <a href='#' >Pending </a></td>
                                            <td><a href='#' onClick={surveyToggle}>Survey</a></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">2</th>
                                            <td>23 May 2023, 10:00AM</td>
                                            <td>Consultation</td>
                                            <td>$100</td>
                                            <td>Dr. Abdul Kareem</td>
                                            <td>Completed</td>
                                            <td>Paid</td>
                                            <td> <a href="#" onClick={toggle}>View Notes </a></td>
                                            <td><a href='#'>Survey</a></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">3</th>
                                            <td>23 May 2023, 10:00AM</td>
                                            <td>Consultation</td>
                                            <td>$100</td>
                                            <td>Dr. Abdul Kareem</td>
                                            <td>Completed</td>
                                            <td>Pending</td>
                                            <td> <a href="#">View Notes </a></td>
                                            <td><a href='#'>Survey</a></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">4</th>
                                            <td>23 May 2023, 10:00AM</td>
                                            <td>Consultation</td>
                                            <td>$100</td>
                                            <td>Dr. Abdul Kareem</td>
                                            <td>Completed</td>
                                            <td>Pending</td>
                                            <td> <a href="#">View Notes </a></td>
                                            <td><a href='#'>Survey</a></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">5</th>
                                            <td>23 May 2023, 10:00AM</td>
                                            <td>Consultation</td>
                                            <td>$100</td>
                                            <td>Dr. Abdul Kareem</td>
                                            <td>Completed</td>
                                            <td>Paid</td>
                                            <td> <a href="#">View Notes </a></td>
                                            <td><a href='#'>Survey</a></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">6</th>
                                            <td>23 May 2023, 10:00AM</td>
                                            <td>Consultation</td>
                                            <td>$100</td>
                                            <td>Dr. Abdul Kareem</td>
                                            <td>Completed</td>
                                            <td>Paid</td>
                                            <td> <a href="#">View Notes </a></td>
                                            <td><a href='#'>Survey</a></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>



                        </div>
                    </div>
                </div>
            </div>
            <Footer />

            <div>
                <Modal isOpen={modal} toggle={toggle} className="custom-modal" centered>
                    <div className="modal-overlay">
                        <ModalHeader toggle={toggle}> Notes </ModalHeader>
                        <ModalBody>

                            <div className="text-start statusBx w-100">
                                <FormGroup>
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting
                                        industry. Lorem Ipsum has been the industry's standard dummy text
                                        ever since the 1500s, when an unknown printer took a galley of type
                                        and scrambled it to make a type specimen book.</p>

                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting
                                        industry. Lorem Ipsum has been the industry's standard dummy text
                                        ever since the 1500s, when an unknown printer took a galley of type
                                        and scrambled it to make a type specimen book.
                                    </p>
                                </FormGroup>
                            </div>

                            {/* <Button style={{
                            background: "#3A63B5 0% 0% no-repeat padding-box",
                            width: "100%"
                        }} onClick={() => { toggle() }}>Submit</Button> */}

                        </ModalBody>
                    </div>
                </Modal>
            </div>

            {/* Survey Modal */}
            <div>
                {/* <Modal isOpen={open1} toggle={surveyToggle} className="custom-modal" centered>
                    <div className="modal-overlay">
                        <ModalHeader toggle={surveyToggle}> Fill Survey </ModalHeader>
                        <ModalBody>

                            <div className="text-start statusBx w-100">
                                <FormGroup>
                                    <div className="modal-para-1">
                                        <p> Lorem Ipsum has been the industry's standard?
                                            <span className="radio-container" style={{ justifyContent: "flex-end", marginLeft: "20px" }}>
                                                <label style={{ padding: "0px 20px" }}>
                                                    <input type="radio" name="option" value="yes" style={{ margin: "0px" }} /> Yes
                                                </label>
                                                <label>
                                                    <input type="radio" name="option" value="no" /> No
                                                </label>
                                            </span>
                                        </p>
                                    </div>
                                    <hr />
                                    <div className="modal-para-2">
                                        <p> Lorem Ipsum has been the industry's standard?
                                            <span className="radio-container" style={{ justifyContent: "flex-end", marginLeft: "20px" }}>
                                                <label style={{ padding: "0px 20px" }}>
                                                    <input type="radio" name="option" value="yes" style={{ margin: "0px" }} /> Yes
                                                </label>
                                                <label>
                                                    <input type="radio" name="option" value="no" /> No
                                                </label>
                                            </span>
                                        </p>
                                    </div>
                                    <hr />
                                    <div className="modal-para-3">
                                        <p> Lorem Ipsum has been the industry's standard?
                                            <span className="radio-container" style={{ justifyContent: "flex-end", marginLeft: "20px" }}>
                                                <label style={{ padding: "0px 20px" }}>
                                                    <input type="radio" name="option" value="yes" style={{ margin: "0px" }} /> Yes
                                                </label>
                                                <label>
                                                    <input type="radio" name="option" value="no" /> No
                                                </label>
                                            </span>
                                        </p>
                                    </div>
                                    <hr />
                                    <div className="modal-para-4">
                                        <p> Lorem Ipsum has been the industry's standard?
                                            <span className="radio-container" style={{ justifyContent: "flex-end", marginLeft: "20px" }}>
                                                <label style={{ padding: "0px 20px" }}>
                                                    <input type="radio" name="option" value="yes" style={{ margin: "0px" }} /> Yes
                                                </label>
                                                <label>
                                                    <input type="radio" name="option" value="no" /> No
                                                </label>
                                            </span>
                                        </p>
                                    </div>
                                    <hr />
                                    <div className="modal-para-5">
                                        <p> Lorem Ipsum has been the industry's standard?
                                            <span className="radio-container" style={{ justifyContent: "flex-end", marginLeft: "20px" }}>
                                                <label style={{ padding: "0px 20px" }}>
                                                    <input type="radio" name="option" value="yes" style={{ margin: "0px" }} /> Yes
                                                </label>
                                                <label>
                                                    <input type="radio" name="option" value="no" /> No
                                                </label>
                                            </span>
                                        </p>
                                    </div>

                                </FormGroup>
                            </div>

                            <Button style={{
                                background: "#3A63B5 0% 0% no-repeat padding-box",
                                width: "100%"
                            }} onClick={() => { surveyToggle() }}>Submit</Button>

                        </ModalBody>
                    </div>
                </Modal> */}
                {open1 && (
                    <Modal isOpen={open1} toggle={surveyToggle} className="custom-modal" centered>
                        <div className="modal-overlay">
                            <ModalHeader toggle={surveyToggle}> Fill Survey </ModalHeader>
                            <ModalBody>
                                <div className="text-start statusBx w-100">
                                    <form>
                                        {allsurvey && allsurvey?.length > 0 ? (
                                            allsurvey?.map((surveyItem, index) => (
                                                <>
                                                    <div className="modal-para-1 d-flex" key={index}>
                                                        <p className='Question-type' style={{ flex: 1 }}>
                                                            {surveyItem?.questionText}
                                                            <hr  style={{width:"100%", marginBottom:"0"}}/>
                                                        </p>
                                                        
                                                        <span className="radio-container">
                                                            {surveyItem?.options.map((option) => (
                                                                <Label key={option} style={{ marginRight: "10px" }}>
                                                                    <input type="radio" name={`option-${index}`} value={option} style={{margin:"0px 10px"}} />
                                                                    {option}
                                                                    <hr  style={{width:"100%", marginBottom:"0"}}/>
                                                                </Label>
                                                            ))}
                                                          
                                                        </span>
                                                       
                                                    </div>
                                                   

                                                </>

                                            ))
                                        ) : (
                                            <p>No survey data available.</p>
                                        )}
                                    </form>
                                </div>
                                <Button
                                    style={{
                                        background: "#3A63B5 0% 0% no-repeat padding-box",
                                        width: "100%"
                                    }}
                                    onClick={() => { surveyToggle() }}
                                >
                                    Submit
                                </Button>
                            </ModalBody>
                        </div>
                    </Modal>
                )}
            </div>

        </>
    )
}

export default CompletedAppointments
