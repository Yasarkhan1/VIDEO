import React, { useState } from 'react'
import { Link, useNavigate, useParams, useLocation } from 'react-router-dom'
import { FormGroup, Button, Modal, ModalHeader, ModalBody, ModalFooter, Input, Label } from 'reactstrap'
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import Footer from '../../common/Footer/Footer'
import Sidebar from '../../common/Sidebar/Sidebar'
import { IsCallerDetails } from "../../../getDeviceToken";
import CreditCardForm from '../../common/CreditCardForm/CreditCardForm';
import authenticationServices from "../../../services";
import { toast } from "react-toastify";
import { useSelector } from 'react-redux';
import SpinnerLoader from '../../common/Spinner'

function InitiateCall() {
    const { appointmentId } = useParams()
    const location = useLocation()
    console.log(location)
    const navigate = useNavigate()
    const [modal, setModal] = useState(false);
    const [openCard, setOpenCard] = useState(false);
    const [acceptPrivacy, setacceptPrivacy] = useState(false);
    const [isCardAdded, setisCardAdded] = useState(false);
    const [IsLoader, setIsLoader] = useState(false);
    const [allCardData, setallCardData] = useState([]);
    const [selectedCardId, setselectedCardId] = useState("");
    const toggle = () => { setModal(!modal) };
    const userData = useSelector((state) => state.user.data);

    const cardToggle = () => {
        setOpenCard(!openCard)
    }

    const handleCall = () => {
        navigate(`/video-call/65083c187852bf8b0d1704dc/64ff01f763166250211da038/video/outgoing`, { 'path': "WFCM" })
        // navigate(`${ROUTES_CONSTANTS.VIDEO_CALL}/${PatAppointmentData?._id}/${PatAppointmentData?.serviceProviderId?._id}/${data.target.id}/outgoing`, { 'path': "WFCM" });
        IsCallerDetails.next(true);
        // saveToSessionStorage(
        //     "callerDetails",
        // JSON.stringify({
        //     fullName: "faizan",
        //     profilePic: "https://d2s5967i61e5uu.cloudfront.net/65083bfe7852bf8b0d1704d3",
        // })
        // );
        // console.log(data.target.id, PatAppointmentData);
        // if (new Date().getTime() < new Date(PatAppointmentData?.appointmentStartTime).getTime()) {
        //     ToasterFunc("error", "You can't call before your appointment time");
        // } else {
        //     if (data.target.id === "video") {
        //         navigate(`${ROUTES_CONSTANTS.VIDEO_CALL}/${PatAppointmentData?._id}/${PatAppointmentData?.serviceProviderId?._id}/${data.target.id}/outgoing`, { 'path': "WFCM" });
        //         IsCallerDetails.next(true);
        //         saveToSessionStorage(
        //             "callerDetails",
        //             JSON.stringify({
        //                 fullName: `${PatAppointmentData?.serviceProviderId?.fullName}`,
        //                 profilePic: PatAppointmentData?.serviceProviderId?.profilePic,
        //             })
        //         );
        //     } 
        // }
    };

    const cancelAppointment = async () => {
        if (!acceptPrivacy) {
            toast.warn("Please read CPN policy", {
                position: toast.POSITION.TOP_RIGHT,
            });
            return
        } else {


            try {

                const payload = {
                    "appointmentId": appointmentId
                }
                setIsLoader(true);
                let res = await authenticationServices.bookingCancellation(payload);
                console.log("cancelAppointment result==", res);
                if (res.status === 200) {
                    setModal(false)
                    setIsLoader(false);
                    toast.success(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                    navigate("/scheduled-appointments")
                } else {
                    setIsLoader(false);
                    toast.error(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                }
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        }
    }

    return (
        <>
            {IsLoader && <SpinnerLoader />}
            <div className="initiate-call">
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className="parent-div">
                        <Sidebar />
                        <div className="child-div" style={{ justifyContent: 'center', alignItems: 'center' }}>
                            <div className="box-content">
                                <div className="container-data">
                                    <div className="row">
                                        <div className="col">
                                            <h6>Expert Consultant</h6>
                                        </div>
                                        <div className="col">
                                            <p>Dr.Muhammad Ibn Abdullah</p>
                                        </div>
                                        <div className="hr-line"></div>
                                    </div>

                                </div>

                                <div className="data-content">
                                    <div className="row">
                                        <div className="col">
                                            <h6>Day of Appointment</h6>
                                        </div>
                                        <div className="col">
                                            <p>12/09/2023</p>
                                        </div>
                                    </div>
                                    <div className="hr-line"></div>
                                </div>
                                <div className="data-content">
                                    <div className="row">
                                        <div className="col">
                                            <h6>Time of Appointment</h6>
                                        </div>
                                        <div className="col">
                                            <p>11:00 AM (EST)</p>
                                        </div>
                                    </div>
                                    <div className="hr-line"></div>
                                </div>
                                <div className="buttoon">
                                    <Button className='btn-secondry' onClick={handleCall}>Initiate Call</Button>
                                    {/* <Button className='btn-secondry' onClick={cardToggle}>Initiate Call</Button> */}
                                    <Button className='btn-secondry1S' onClick={toggle}>
                                        Request to Reschedule or Cancel
                                    </Button>
                                    <h5>Read CPN policy for Rescheduling and Cancelations</h5>
                                </div>
                                <div className="paragraph-notes">
                                    <p> <strong>Note: </strong>You will be charged to the payment method selected by you, When you initiate this call.</p>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Footer />
            {/* <div>
                <Modal isOpen={openCard} className="custom-modal ">
                    <div className="modal-overlay credit-card-modal">
                        <ModalHeader toggle={cardToggle} />
                        <ModalBody>
                            <div style={{ textAlign: '' }}>
                                < CreditCardForm allCardData={allCardData} selectedCardId={selectedCardId} openCard={openCard} setOpenCard={setOpenCard} />
                            </div>
                        </ModalBody>
                    </div>
                </Modal>
            </div> */}
            <div>
                <Modal isOpen={modal} toggle={toggle} className="custom-modal" centered>
                    <div className="modal-overlay">
                        <ModalHeader toggle={toggle}> </ModalHeader>
                        <ModalBody>
                            <h5 className="text-center"> Want to Reschedule/Cancel Appointment </h5>
                            <div className="text-center statusBx w-200">
                                <FormGroup>
                                    <Input type='checkbox' checked={acceptPrivacy} onChange={(e) => setacceptPrivacy(e.target.checked)} />
                                    <Label style={{ marginLeft: '10px' }}>Read CPN policy for rescheduling and Cancelations</Label>
                                </FormGroup>
                            </div>

                            <Button style={{ background: "#3A63B5 0% 0% no-repeat padding-box", width: "100%" }} onClick={() => cancelAppointment()}>
                                Submit
                            </Button>

                        </ModalBody>
                    </div>
                </Modal>
            </div>

        </>
    )
}

export default InitiateCall
