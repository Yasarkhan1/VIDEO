import React from 'react'
import InitiateCall from '../../../assests/images/Mask Group 17@2x.png'
import Camera from '../../../assests/images/Group 839@2x.png';
import Cut from '../../../assests/images/Group 840@2x.png';
import Redcall from '../../../assests/images/Group 843@2x.png';
import Ladyimage from '../../../assests/images/Mask Group 18@2x.png';
import { Link, useNavigate } from 'react-router-dom'

const InitiateVedioCall = () => {
    return (
        <>

            <div className="initiate-vedio-call">
                <div className="initiatecall">
                    <div className="side-image">
                        <img src={Ladyimage} alt="" />
                    </div>
                    <img src={InitiateCall} className='web-image2' alt="" />
                    <div className="call-cut">
                        <div className="image-text-container">
                            <img src={Camera} alt="" style={{ marginRight: '10px ' }} />
                            <div className="image-text1"><h6>Camera</h6></div>
                        </div>
                        <div className="image-text-container">
                            <img src={Cut} alt="cut" style={{ margin: '0 10px' }} />
                            <div className="image-text2">
                                <h6>Mute</h6>
                            </div>
                        </div>
                        <div className="image-text-container">
                            <Link to={'/initiate-vedio-call'}>
                                <img src={Redcall} alt="red" style={{ marginLeft: '10px', marginBottom: '23px' }} />
                            </Link>
                            <div className="image-text"></div>
                        </div>
                    </div>
                </div>
            </div>

        </>
    )
}

export default InitiateVedioCall
