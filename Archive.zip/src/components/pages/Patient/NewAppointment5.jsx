import React, { useState, useEffect } from 'react';
import LoginNavbar from '../../common/LoginNavbar/LoginNavbar'
import Sidebar from '../../common/Sidebar/Sidebar'
import { FormGroup, Form, Button, Input, Label, Col, Row } from 'reactstrap'
import { Formik, useFormik } from 'formik'
import AppointNavbar from '../../common/AppointmentNavbar/AppointNavbar'
import Footer from '../../common/Footer/Footer'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import dayjs from "dayjs";
import authenticationServices from "../../../services";
import { useSelector } from 'react-redux';
import * as Yup from 'yup';
import { toast } from "react-toastify";
import SpinnerLoader from '../../common/Spinner'

const validationSchema = Yup.object().shape({
    // family_relation: Yup.string().required("Please select."),
    // name_of_disease: Yup.string().required("Enter your disease name."),
    // marital_status: Yup.string().required("Please select."),
    // employed: Yup.string().required("Please select."),
    // alcohol_use: Yup.string().required("Please select."),
    // tobacco_use: Yup.string().required("Enter Your Number."),
    // recreational_drug_use: Yup.string().required("Enter drug name"),
    // dose: Yup.string().required("Enter your dose name."),
    // frequency: Yup.string().required("Please select your frequency."),
    // duration: Yup.string().required("Enter your duration."),
    number_of_drinks: Yup.string().test(
        'isRequired',
        'Select numbers of drink',
        function (value) {
            const { alcohol_use } = this.parent;
            if (alcohol_use === 'Yes') {
                return Yup.string().required().isValidSync(value);
            }
            return true;
        }
    ),
    number_of_tobacco: Yup.string().test(
        'isRequired',
        'Please Enter a Number',
        function (value) {
            const { tobacco_use } = this.parent;
            if (tobacco_use === 'Yes') {
                return Yup.string().required().isValidSync(value);
            }
            return true;
        }
    ),
    recreational_drug_name: Yup.string().test(
        'isRequired',
        'Please enter active drug name',
        function (value) {
            const { recreational_drug_use } = this.parent;
            if (recreational_drug_use === 'Yes') {
                return Yup.string().required().isValidSync(value);
            }
            return true;
        }
    ),
    recreational_drug_dose: Yup.string().test(
        'isRequired',
        'Please select',
        function (value) {
            const { recreational_drug_use } = this.parent;
            if (recreational_drug_use === 'Yes') {
                return Yup.string().required().isValidSync(value);
            }
            return true;
        }
    )


});

function NewAppointment5() {
    const location = useLocation()
    const dropDownData = useSelector((state) => state.allDropDown.data);
    // console.log("dropDownData====+++", dropDownData);
    const navigate = useNavigate()
    const [IsLoader, setIsLoader] = useState(false);
    const appointmentId = location?.state?.appointmentId

    // useEffect to redirect step 1 if previous form not submitted
    // useEffect(() => {
    //     if (appointmentId === '' || appointmentId === undefined) {
    //         navigate("/new-appointment-1")
    //     }
    // }, [appointmentId])

    const formik = useFormik({
        initialValues: {
            family_relation: "",
            name_of_disease: "",
            marital_status: "",
            employed: "",
            alcohol_use: "",
            tobacco_use: "",
            recreational_drug_use: "",
            recreational_drug_name: "",
            recreational_drug_dose: "",
            dose: "",
            frequency: "",
            duration: "",
            number_of_drinks: "",
            number_of_tobacco: ""
        },
        validationSchema: validationSchema,
        onSubmit: async (values) => {
            console.log("values==", values);
            const payload = {
                "relation": values.family_relation,
                "familyNameOfDisease": values.name_of_disease,
                "married": values.marital_status,
                "employed": values.employed,
                "alcoholUse": {
                    "value": values.alcohol_use,
                    "date": "2022-02-10"
                },
                "tobaccoUse": {
                    "value": values.tobacco_use
                },
                "recreationalDrug": {
                    "value": values.recreational_drug_use
                },
                "recreationalDrug": {
                    "value": values.recreational_drug_use,
                    "day": values.recreational_drug_dose,
                    "name": values.recreational_drug_name
                },
                "medications": values.dose,
                "medicationFrequency": values.frequency,
                "medicationDuration": values.duration,
                "appointmentId": appointmentId,
            }
            try {
                console.log("appointmentBook step 5 payload=", payload);

                setIsLoader(true);
                let res = await authenticationServices.appointmentBook(payload, 5);
                console.log("appointmentBook step 5 result==", res);
                if (res.data.status === 200) {
                    const appointmentId = res.data.data.appointmentId
                    setIsLoader(false);
                    toast.success(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                    // navigate("/")
                    navigate("/new-appointment-6", { state: { appointmentId: appointmentId }, replace: true })
                } else {
                    setIsLoader(false);
                    toast.error(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                }
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        }

    });

    // useEffect to reset fields on select "No" from dropdown
    useEffect(() => {
        if (formik.values.alcohol_use === 'No') {
            formik.setFieldValue('number_of_drinks', '');
            formik.setFieldError('number_of_drinks', '');
            formik.setFieldTouched('number_of_drinks', false);
        }
        if (formik.values.tobacco_use === 'No') {
            formik.setFieldValue('number_of_tobacco', '');
            formik.setFieldError('number_of_tobacco', '');
            formik.setFieldTouched('number_of_tobacco', false);
        }
        if (formik.values.recreational_drug_use === 'No') {
            formik.setFieldValue('recreational_drug_name', '');
            formik.setFieldError('recreational_drug_name', '');
            formik.setFieldTouched('recreational_drug_name', false);
            formik.setFieldValue('recreational_drug_dose', '');
            formik.setFieldError('recreational_drug_dose', '');
            formik.setFieldTouched('recreational_drug_dose', false);
        }
    }, [formik.values.alcohol_use, formik.values.tobacco_use, formik.values.recreational_drug_use])

    return (
        <>
            <div className="new-appointment5">
                {IsLoader && <SpinnerLoader />}
                <LoginNavbar />
                <div className="container-fluid custom-container-fluid mb-5">
                    <div className=" parent-div">
                        <Sidebar />
                        <div className=" child-div">
                            <div className="child-navabar">
                                <AppointNavbar />
                            </div>

                            <div className="form-groupes">
                                <div className="header-heading">
                                    <h1> Family History</h1>
                                </div>
                                <Form onSubmit={formik.handleSubmit}>
                                    <Row>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label >
                                                    Relation
                                                </Label>
                                                <Input
                                                    name="family_relation"
                                                    type="select"
                                                    {...formik.getFieldProps("family_relation")}
                                                    className={formik.touched.family_relation && formik.errors.family_relation ? 'is-invalid' : ""}
                                                >
                                                    <option value="">Select</option>
                                                    {dropDownData?.relationship?.length ?
                                                        dropDownData?.relationship?.map((item, ind) => (

                                                            <option value={item.value} key={ind}>{item.label}</option>
                                                        ))
                                                        : ""
                                                    }
                                                </Input>
                                                {formik.touched.family_relation && formik.errors.family_relation ? <small className='validation_error'>{formik.errors.family_relation}</small> : ""}

                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label >
                                                    Name of Disease
                                                </Label>
                                                <Input

                                                    name="name_of_disease"
                                                    type="Text"
                                                    placeholder='Enter Name of Disease'
                                                    {...formik.getFieldProps("name_of_disease")}
                                                    className={formik.touched.name_of_disease && formik.errors.name_of_disease ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.name_of_disease && formik.errors.name_of_disease ? <small className='validation_error'>{formik.errors.name_of_disease}</small> : ""}


                                            </FormGroup>
                                        </Col>

                                    </Row>
                                    {/* Second Row Start */}
                                    <div className="header-heading">
                                        <h1>Social History</h1>
                                    </div>
                                    <Row>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label >
                                                    Married (Yes/No)
                                                </Label>
                                                <Input
                                                    name="marital_status"
                                                    type="select"
                                                    {...formik.getFieldProps("marital_status")}
                                                    className={formik.touched.marital_status && formik.errors.marital_status ? 'is-invalid' : ""}
                                                >
                                                    <option value="">Select</option>
                                                    {dropDownData?.married?.length ?
                                                        dropDownData?.married?.map((item, ind) => (

                                                            <option value={item.value} key={ind}>{item.label}</option>
                                                        ))
                                                        : ""
                                                    }
                                                </Input>
                                                {formik.touched.marital_status && formik.errors.marital_status ? <small className='validation_error'>{formik.errors.marital_status}</small> : ""}
                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label >
                                                    Employed (Yes/No)
                                                </Label>
                                                <Input
                                                    name="employed"
                                                    type="select"
                                                    {...formik.getFieldProps("employed")}
                                                    className={formik.touched.employed && formik.errors.employed ? 'is-invalid' : ""}
                                                >
                                                    <option value="">Select</option>
                                                    {dropDownData?.employed?.length ?
                                                        dropDownData?.employed?.map((item, ind) => (
                                                            <option value={item.value} key={ind}>{item.label}</option>
                                                        ))
                                                        : ""
                                                    }
                                                </Input>
                                                {formik.touched.employed && formik.errors.employed ? <small className='validation_error'>{formik.errors.employed}</small> : ""}
                                            </FormGroup>

                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col md={2}>
                                            <Label>Alcohol Use </Label>
                                            <FormGroup>
                                                <Input
                                                    name="alcohol_use"
                                                    type="select"
                                                    {...formik.getFieldProps("alcohol_use")}
                                                    className={formik.touched.alcohol_use && formik.errors.alcohol_use ? 'is-invalid' : ""}
                                                >
                                                    <option value="">Select</option>
                                                    {dropDownData?.alcoholUse?.length ?
                                                        dropDownData?.alcoholUse?.map((item, ind) => (

                                                            <option value={item.value} key={ind}>{item.label}</option>
                                                        ))
                                                        : ""
                                                    }
                                                </Input>
                                                {formik.touched.alcohol_use && formik.errors.alcohol_use ? <small className='validation_error'>{formik.errors.alcohol_use}</small> : ""}
                                            </FormGroup>
                                        </Col>
                                        <Col md={4}>
                                            <FormGroup>
                                                <Label>(Yes(Drinks/Week)/No)</Label>
                                                {formik.values.alcohol_use === 'Yes' &&
                                                    <>
                                                        <Input
                                                            name="number_of_drinks"
                                                            type="select"
                                                            {...formik.getFieldProps("number_of_drinks")}

                                                            className={formik.touched.number_of_drinks && formik.errors.number_of_drinks ? 'is-invalid' : ""}
                                                        >
                                                            <option value="">Select</option>
                                                            {dropDownData?.alcoholPerWeek?.length ?
                                                                dropDownData?.alcoholPerWeek?.map((item, ind) => (

                                                                    <option value={item.value} key={ind}>{item.label}</option>
                                                                ))
                                                                : ""
                                                            }
                                                        </Input>
                                                        {formik.touched.number_of_drinks && formik.errors.number_of_drinks ? <small className='validation_error'>{formik.errors.number_of_drinks}</small> : ""}
                                                    </>
                                                }
                                            </FormGroup>
                                        </Col>
                                        <Col md={2}>
                                            <FormGroup>
                                                <Label>Tobacco Use</Label>
                                                <Input
                                                    name="tobacco_use"
                                                    type="select"
                                                    {...formik.getFieldProps("tobacco_use")}
                                                    className={formik.touched.tobacco_use && formik.errors.tobacco_use ? 'is-invalid' : ""}
                                                >
                                                    <option value="">Select</option>
                                                    {dropDownData?.tobaccoUse?.length ?
                                                        dropDownData?.tobaccoUse?.map((item, ind) => (

                                                            <option value={item.value} key={ind}>{item.label}</option>
                                                        ))
                                                        : ""
                                                    }
                                                </Input>
                                                {formik.touched.tobacco_use && formik.errors.tobacco_use ? <small className='validation_error'>{formik.errors.tobacco_use}</small> : ""}
                                            </FormGroup>
                                        </Col>
                                        <Col md={4}>
                                            <FormGroup>
                                                <Label> (Yes(Number of Packs/Day)/No) </Label>
                                                {formik.values.tobacco_use === 'Yes' &&
                                                    <>
                                                        <Input
                                                            name="number_of_tobacco"
                                                            type="select"
                                                            {...formik.getFieldProps("number_of_tobacco")}

                                                            className={formik.touched.number_of_tobacco && formik.errors.number_of_tobacco ? 'is-invalid' : ""}
                                                        >
                                                            <option value="">Select</option>
                                                            {dropDownData?.tobaccoPerDay?.length ?
                                                                dropDownData?.tobaccoPerDay?.map((item, ind) => (

                                                                    <option value={item.value} key={ind}>{item.label}</option>
                                                                ))
                                                                : ""
                                                            }
                                                        </Input>
                                                        {formik.touched.number_of_tobacco && formik.errors.number_of_tobacco ? <small className='validation_error'>{formik.errors.number_of_tobacco}</small> : ""}
                                                    </>
                                                }
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Label>Recreational Drug Use (Yes(Name/Active)/No)</Label>
                                        <Col md={2}>
                                            <FormGroup>
                                                <Input
                                                    name="recreational_drug_use"
                                                    type="select"
                                                    {...formik.getFieldProps("recreational_drug_use")}
                                                    className={formik.touched.recreational_drug_use && formik.errors.recreational_drug_use ? 'is-invalid' : ""}
                                                >
                                                    <option value="">Select Yes or No</option>
                                                    <option value="Yes">Yes</option>
                                                    <option value="No">No</option>
                                                </Input>
                                                {formik.touched.recreational_drug_use && formik.errors.recreational_drug_use ? <small className='validation_error'>{formik.errors.recreational_drug_use}</small> : ""}
                                            </FormGroup>
                                        </Col>
                                        {formik.values.recreational_drug_use === "Yes" && <>
                                            <Col md={4}>
                                                <FormGroup>
                                                    {/* <Label>Recreational drug use Use</Label> */}
                                                    <Input
                                                        id='Recreational'
                                                        type='text'
                                                        placeholder='Enter'
                                                        {...formik.getFieldProps("recreational_drug_name")}
                                                        className={formik.touched.recreational_drug_name && formik.errors.recreational_drug_name ? 'is-invalid' : ""}
                                                    />
                                                    {formik.touched.recreational_drug_name && formik.errors.recreational_drug_name ? <small className='validation_error'>{formik.errors.recreational_drug_name}</small> : ""}

                                                </FormGroup>
                                            </Col>
                                            <Col md={2}>
                                                <FormGroup>
                                                    {/* <Label> </Label> */}
                                                    <Input
                                                        name="recreational_drug_dose"
                                                        type="select"
                                                        {...formik.getFieldProps("recreational_drug_dose")}

                                                        className={formik.touched.recreational_drug_dose && formik.errors.recreational_drug_dose ? 'is-invalid' : ""}
                                                    >
                                                        <option value="">Select</option>
                                                        {dropDownData?.recreationalDrug?.length ?
                                                            dropDownData?.recreationalDrug?.map((item, ind) => (

                                                                <option value={item.value} key={ind}>{item.label}</option>
                                                            ))
                                                            : ""
                                                        }
                                                    </Input>
                                                    {formik.touched.recreational_drug_dose && formik.errors.recreational_drug_dose ? <small className='validation_error'>{formik.errors.recreational_drug_dose}</small> : ""}
                                                </FormGroup>
                                            </Col>

                                        </>}
                                    </Row>
                                    {/* Second Last Div */}
                                    <div className="header-heading-past">
                                        <h1>Medication</h1>
                                    </div>
                                    <Row>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label >
                                                    Medications (Dose)
                                                </Label>
                                                <Input
                                                    name="dose"
                                                    type="text"
                                                    placeholder='Enter Medication'
                                                    {...formik.getFieldProps("dose")}
                                                    className={formik.touched.dose && formik.errors.dose ? 'is-invalid' : ""}

                                                />
                                                {formik.touched.dose && formik.errors.dose ? <small className='validation_error'>{formik.errors.dose}</small> : ""}

                                            </FormGroup>
                                        </Col>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label >
                                                    Frequency
                                                </Label>
                                                <Input
                                                    name="frequency"
                                                    type="select"
                                                    {...formik.getFieldProps("frequency")}
                                                    className={formik.touched.frequency && formik.errors.frequency ? 'is-invalid' : ""}
                                                >
                                                    <option value="">Select</option>
                                                    {dropDownData?.frequency?.length ?
                                                        dropDownData?.frequency?.map((item, ind) => (

                                                            <option value={item.value} key={ind}>{item.label}</option>
                                                        ))
                                                        : ""
                                                    }
                                                </Input>
                                                {formik.touched.frequency && formik.errors.frequency ? <small className='validation_error'>{formik.errors.frequency}</small> : ""}

                                            </FormGroup>
                                        </Col>

                                    </Row>
                                    {/* Second Row Start */}
                                    <Row>
                                        <Col md={6}>
                                            <FormGroup>
                                                <Label >
                                                    Duration
                                                </Label>
                                                <Input

                                                    name="duration"
                                                    type="text"
                                                    placeholder='Enter Duration'
                                                    {...formik.getFieldProps("duration")}
                                                    className={formik.touched.duration && formik.errors.duration ? 'is-invalid' : ""}
                                                />
                                                {formik.touched.duration && formik.errors.duration ? <small className='validation_error'>{formik.errors.duration}</small> : ""}

                                            </FormGroup>
                                        </Col>
                                    </Row>



                                    <div className="button-container">
                                        {/* <Link to={'/new-appointment-6'}> */}
                                        <Button color="primary" className='next-button' type='submit'>
                                            Next
                                        </Button>
                                        {/* </Link> */}

                                    </div>
                                </Form>
                            </div>

                        </div>
                    </div>
                </div>
            </div >
            <Footer />

        </>
    )
}

export default NewAppointment5
