import React, { useEffect } from 'react'

import waitingtoom from "../../../assests/images/waiting-room-svgrepo-com.svg";
import doctormale from "../../../assests/images/doctor-male-svgrepo-com.svg";
import medicine from "../../../assests/images/medicine-symbol-svgrepo-com.svg";
import GroupMask854 from "../../../assests/images/Group 854.png";
// import Rightarrow from "../../../assests/images/Path 453.svg";
import cpnLogo from "../../../assests/images/CPNHealthFINAL_fontembed.svg";
import { useNavigate, Link } from 'react-router-dom';
import Footer from '../../common/Footer/Footer';
import { Col } from 'reactstrap';

const LoginAs = () => {
  const navigate = useNavigate();
  useEffect(() => {
    localStorage.removeItem("expertSignupData")
    localStorage.removeItem("patientSignupData")
    localStorage.removeItem("cpnSignupData")
    localStorage.removeItem("token")
    sessionStorage.removeItem("token")
  }, [])


  return (
    <div className='login-as'>
      <div className="last-sections">
        <div className="image-lasts">
          <img className='image-last' src={GroupMask854} alt="" />
          <div className="content-images">
            <div className='cpn-logo'>
              <img src={cpnLogo} />
            </div>
            <div className="get-paras">
              <p>The Checkpoint Now</p>
            </div>
            <div className="Heading-eclinics">
              <h1>Consult our trusted cancer experts</h1>
            </div>
            <div className="The-best-moder-contents">
              <h6>- We understand cancer, its treatments and its side effects </h6>
              <h6>- Make An Appointment</h6>
            </div>

          </div>


        </div>
      </div>

      {/* Login Card and Signup card start */}

      <div className="card-group">

        <div className="card" style={{ backgroundColor: "#5454F8" }}>
          <img src={waitingtoom} className="card-img-center" alt="..." />
          <div className="card-body">
            <h5 className="card-title">Patient</h5>

            <div className="button-row">
              <Link to="/login-as-patient"><button className="login-btn"> Login </button></Link><span class="gap">Or</span>
              <Link to="/signup-as-patient-1"><button className='sign-up-btn'>Sign Up</button></Link>

            </div>
          </div>
        </div>


        <div className="card" style={{ backgroundColor: "#00BACB" }}  >
          <img src={doctormale} className="card-img-center" alt="..." />
          <div className="card-body">
            <h5 className="card-title">Expert Consultant</h5>
            <div className="button-row">
              <Link to="/login-as-expert">
                <button className='login-btn green-buttn'> Login </button ></Link><span class="gap">Or</span>
              <Link to="/signup-as-expert-1"><button className='sign-up-btn'>Sign Up</button></Link>
            </div>
          </div>
        </div>

      </div>


      {/* <!-- Faq Question Up --> */}
      <div className="container">
        <div className="row-content">
          <p>The Checkpoint Now World of Care</p>
          <h1>FAQ (Frequently Asked Questions)</h1>
          <span>The best of modern healthcare to ensure you <br /> stay healthy, always.</span> <br /><br />
          <div className="accordion" id="accordionExample">
            <div className="accordion-item">
              <h2 className="accordion-header" id="headingOne">
                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                  data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                  Why do I need to see an expert for my side effects?
                </button>
              </h2>
              <div id="collapseOne" className="accordion-collapse collapse" aria-labelledby="headingOne"
                data-bs-parent="#accordionExample">
                <div className="accordion-body">
                  Lorem ipsum dolor sit amet consectetur, adipisicing elit. Itaque beatae dolores vero est at labore voluptatibus tempora delectus laboriosam a obcaecati tenetur sed commodi saepe autem mollitia deleniti, ratione alias?
                </div>
              </div>
            </div>
            <div className="accordion-item">
              <h2 className="accordion-header" id="headingTwo">
                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                  data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                  How are these experts different from my cancer doctors and what they can offer?
                </button>
              </h2>
              <div id="collapseTwo" className="accordion-collapse collapse" aria-labelledby="headingTwo"
                data-bs-parent="#accordionExample">
                <div className="accordion-body">
                  Lorem ipsum dolor sit amet consectetur, adipisicing elit. Itaque beatae dolores vero est at labore voluptatibus tempora delectus laboriosam a obcaecati tenetur sed commodi saepe autem mollitia deleniti, ratione alias?
                </div>
              </div>
            </div>
            <div className="accordion-item">
              <h2 className="accordion-header" id="headingThree">
                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                  data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                  Who are CPN Expert Consultants?
                </button>
              </h2>
              <div id="collapseThree" className="accordion-collapse collapse" aria-labelledby="headingThree"
                data-bs-parent="#accordionExample">
                <div className="accordion-body">
                  Lorem ipsum dolor sit amet consectetur, adipisicing elit. Itaque beatae dolores vero est at labore voluptatibus tempora delectus laboriosam a obcaecati tenetur sed commodi saepe autem mollitia deleniti, ratione alias?
                </div>
              </div>
            </div>
            <div className="accordion-item">
              <h2 className="accordion-header" id="headingFour">
                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                  data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                  What happens after I request a online appointment?
                </button>
              </h2>
              <div id="collapseFour" className="accordion-collapse collapse" aria-labelledby="headingFour"
                data-bs-parent="#accordionExample">
                <div className="accordion-body">
                  Lorem ipsum dolor sit amet consectetur, adipisicing elit. Itaque beatae dolores vero est at labore voluptatibus tempora delectus laboriosam a obcaecati tenetur sed commodi saepe autem mollitia deleniti, ratione alias?
                </div>
              </div>
            </div>
            <div className="accordion-item">
              <h2 className="accordion-header" id="headingFive">
                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                  data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                  Is this an in person appointment?
                </button>
              </h2>
              <div id="collapseFive" className="accordion-collapse collapse" aria-labelledby="headingFive"
                data-bs-parent="#accordionExample">
                <div className="accordion-body">
                  Lorem ipsum dolor sit amet consectetur, adipisicing elit. Itaque beatae dolores vero est at labore voluptatibus tempora delectus laboriosam a obcaecati tenetur sed commodi saepe autem mollitia deleniti, ratione alias?
                </div>
              </div>
            </div>
            <div className="accordion-item">
              <h2 className="accordion-header" id="headingSix">
                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                  data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                  What are the requirements for a virtual visit?
                </button>
              </h2>
              <div id="collapseSix" className="accordion-collapse collapse" aria-labelledby="headingSix"
                data-bs-parent="#accordionExample">
                <div className="accordion-body">
                  Lorem ipsum dolor sit amet consectetur, adipisicing elit. Itaque beatae dolores vero est at labore voluptatibus tempora delectus laboriosam a obcaecati tenetur sed commodi saepe autem mollitia deleniti, ratione alias?
                </div>
              </div>
            </div>
            <div className="accordion-item">
              <h2 className="accordion-header" id="headingSeven">
                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                  data-bs-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                  How can my oncologist access recommendations from the CPN Expert Consultant?
                </button>
              </h2>
              <div id="collapseSeven" className="accordion-collapse collapse" aria-labelledby="headingSeven"
                data-bs-parent="#accordionExample">
                <div className="accordion-body">
                  Lorem ipsum dolor sit amet consectetur, adipisicing elit. Itaque beatae dolores vero est at labore voluptatibus tempora delectus laboriosam a obcaecati tenetur sed commodi saepe autem mollitia deleniti, ratione alias?
                </div>
              </div>
            </div>
            <div className="accordion-item">
              <h2 className="accordion-header" id="headingEight">
                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                  data-bs-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
                  I am a patient enrolled in a clinical trial. Is the process for consultation different?
                </button>
              </h2>
              <div id="collapseEight" className="accordion-collapse collapse" aria-labelledby="headingEight"
                data-bs-parent="#accordionExample">
                <div className="accordion-body">
                  Lorem ipsum dolor sit amet consectetur, adipisicing elit. Itaque beatae dolores vero est at labore voluptatibus tempora delectus laboriosam a obcaecati tenetur sed commodi saepe autem mollitia deleniti, ratione alias?
                </div>
              </div>
            </div>
            <div className="accordion-item">
              <h2 className="accordion-header" id="headingNine">
                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                  data-bs-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
                  How can I contact your office?
                </button>
              </h2>
              <div id="collapseNine" className="accordion-collapse collapse" aria-labelledby="headingNine"
                data-bs-parent="#accordionExample">
                <div className="accordion-body">
                  Lorem ipsum dolor sit amet consectetur, adipisicing elit. Itaque beatae dolores vero est at labore voluptatibus tempora delectus laboriosam a obcaecati tenetur sed commodi saepe autem mollitia deleniti, ratione alias?
                </div>
              </div>
            </div>
            <div className="accordion-item">
              <h2 className="accordion-header" id="headingTen">
                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                  data-bs-target="#collapseTen" aria-expanded="false" aria-controls="collapseTen">
                  Where do I access information regarding cost of the visit?
                </button>
              </h2>
              <div id="collapseTen" className="accordion-collapse collapse" aria-labelledby="headingTen"
                data-bs-parent="#accordionExample">
                <div className="accordion-body">
                  Lorem ipsum dolor sit amet consectetur, adipisicing elit. Itaque beatae dolores vero est at labore voluptatibus tempora delectus laboriosam a obcaecati tenetur sed commodi saepe autem mollitia deleniti, ratione alias?
                </div>
              </div>
            </div>
            <div className="accordion-item">
              <h2 className="accordion-header" id="headingEleven">
                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                  data-bs-target="#collapseEleven" aria-expanded="true" aria-controls="collapseEleven">
                  Is this service Health Savings Account (HSA) reimbursable?
                </button>
              </h2>
              <div id="collapseEleven" className="accordion-collapse collapse" aria-labelledby="headingEleven"
                data-bs-parent="#accordionExample">
                <div className="accordion-body">
                  Lorem ipsum dolor sit amet consectetur, adipisicing elit. Itaque beatae dolores vero est at labore voluptatibus tempora delectus laboriosam a obcaecati tenetur sed commodi saepe autem mollitia deleniti, ratione alias?
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>

      {/* <!-- FAQ Asked Question --> */}

      <Footer />
    </div>
  )
}

export default LoginAs