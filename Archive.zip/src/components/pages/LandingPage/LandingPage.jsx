import React from 'react'
import CpnLogo from "../../../assests/images/kindpng_4937901@2x.png";
import Lastimage from "../../../assests/images/Mask Group 9.png";
import MobileImage from "../../../assests/images/Group 903@2x.png";
import Mobileresponsive from "../../../assests/images/Group 904@2x.png";
import GroupMask from "../../../assests/images/Group 855.png";
import cpnLogo from "../../../assests/images/CPNHealthFINAL_fontembed.svg";
import Appstore from "../../../assests/images/Mask Group 25@2x.png"
import GooglePlay from "../../../assests/images/Mask Group 26@2x.png"
import Header from '../../common/Header/Header';
import Footer from '../../common/Footer/Footer';
import { Button } from 'bootstrap';
import { Link } from 'react-router-dom';
const LandingPage = () => {
    return (
        <>
            <div className='landing-page'>
                {/* <div className="last-sections">
                    <div className="image-lasts">
                        <img className='image-last' src={GroupMask} alt="" />
                        <img className='image-last mobile-image' src={MobileImage} alt="" />
                        <div className="content-images">
                            <div className='cpn-logo'>
                                <img className='cpn-logos' src={cpnLogo} />
                            </div>
                            <div className="get-paras">
                                <p>The Checkpoint Now</p>
                            </div>
                            <div className="Heading-eclinics">
                                <h1>Consult our trusted cancer experts</h1>
                            </div>
                            <div className="The-best-moder-contents">
                                <h6>- We understand cancer, its treatments and its side effects </h6>
                                <h6>- Make An Appointment</h6>
                            </div>
                        </div>

                
                        <Header/>

                    </div>
                </div> */}
                <div className="last-sections">
                    <div className="image-lasts">
                        {/* <!-- Web Image --> */}
                        <img className='image-last web-image' src={GroupMask} alt="" />

                        {/* <!-- Mobile Image --> */}
                        <img className='image-last mobile-image' src={MobileImage} alt="" />

                        <div className="content-images">
                            <div className="cpn-logo">
                                <img className="cpn-logos" src={cpnLogo} alt="" />
                            </div>
                            <div className="get-paras">
                                <p>The Checkpoint Now</p>
                            </div>
                            <div className="Heading-eclinics">
                                <h1>Consult our trusted cancer experts</h1>
                            </div>
                            <div className="The-best-moder-contents">
                                <h6>- We understand cancer, its treatments and its side effects</h6>
                                <h6>- Make An Appointment</h6>
                            </div>
                        </div>
                        <Header />
                    </div>
                </div>


                {/* //  Middle Part Sart */}
                <div className="container column">
                    <div className="choose-content">
                        <p>WHO WE ARE</p>
                    </div>
                    <div className="middile-content">
                        <h1>Why Choose Checkpoint Now Health Experts?</h1>
                    </div>
                    <div className="last-middle-content">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been
                            the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type
                            and scrambled it to make a type specimen book.</p>
                    </div>
                </div>

                {/* Last Content */}
                <div className="last-section">
                    <div className="Eclinic-image">
                        {/* web image */}
                        <img className='web-image' src={Lastimage} alt="" />
                        {/* <!-- Mobile Image --> */}
                        <img className='mobile-image' src={Mobileresponsive} alt="" />

                        <div className="content-image">
                            <div className="get-para">
                                <p>Get The Checkpoint Now eCLINIC</p>
                            </div>
                            <div className="Heading-eclinic">
                                <h1>Download our eCLINIC App to book your appointments at your finger tips</h1>
                            </div>
                            <div className="The-best-moder-content">
                                <h6>The best of modern healthcare to ensure you stay healthy, always.</h6>
                            </div>

                            <div className="col-image">
                                {/* web view */}
                                <img className='web-logo' src={CpnLogo} />

                            </div>
                            {/* Mobile view  */}
                            <div className="mobile-view">
                                <img className='appstore' src={Appstore}   />
                                <img className='googleplay' src={GooglePlay} />
                            </div>
                        </div>

                    </div>
                </div>

            </div>
            <Footer />

        </>
    )
}

export default LandingPage