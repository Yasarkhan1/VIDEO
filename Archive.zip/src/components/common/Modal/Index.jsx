import React,{useState} from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import {
    FormGroup, Form, Button, Input, Label, Col, Row, Modal, ModalFooter,
    ModalHeader, ModalBody
} from 'reactstrap'
import Checkpoint from '../../../assests/images/check-read-svgrepo-com.png'


const ModalCmp = (props) => {
    const navigate = useNavigate()
    const [open, setOpen] = useState(true);
    const { openModal, setOpenModal } = props;
    const toggle = (routes) => {
        setOpen(!open)
        console.log(routes);
        // if (routes != '') {
        //     navigate(`${routes}`, { replace: true })
        // }
    };
  return (
    <div>
      <Modal isOpen={open} toggle={() => toggle("/scheduled-appointments")} className="custom-modal">
                <div className="modal-overlay">
                    <ModalHeader toggle={() => toggle("/scheduled-appointments")} />
                    <ModalBody>
                        <div style={{ textAlign: 'center' }}>
                            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '120px' }}>
                                <img src={Checkpoint} alt="Icon" />
                            </div>
                            <div >
                                <h2 style={{ fontSize: "22px", marginBottom: "15px" }}>
                                    Your appointment has been requested. You will get a notification soon.
                                </h2>

                            </div>
                        </div>
                    </ModalBody>
                </div>
            </Modal>

    </div>
  )
}

export default ModalCmp
