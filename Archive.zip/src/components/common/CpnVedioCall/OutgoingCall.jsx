import React, { useState, useEffect } from 'react'
import InitiateCall from '../../../assests/images/Mask Group 17@2x.png'
import Camera from '../../../assests/images/Group 839@2x.png';
import Cut from '../../../assests/images/Group 844@2x.png';
import Redcall from '../../../assests/images/Group 843@2x.png';
import Ladyimage from '../../../assests/images/Mask Group 18@2x.png';
import { Link, useNavigate } from 'react-router-dom'

const OutgoingCall = ({ callDisConnect }) => {
    const [callerDetails, setCallerData] = useState();

    useEffect(() => {
        // setCallerData(JSON.parse(getSessionStorageOrDefault("callerDetails")));
    }, []);
    return (
        <>
            <div className="col-xl-12 mt-4 mb-4">
                <div class="outgoing_call incoming-call">
                    <div class="call-contents">
                        <div class="call-content-wrap">
                            <div class="user-details">
                                <div class="user-info text-center">
                                    <a>
                                        {console.log(callerDetails)}
                                        <h2>{`Calling ${callerDetails?.fullName}`}</h2>
                                    </a>
                                </div>
                                <div className="profile">
                                    <figure>
                                        <img src={callerDetails?.profilePic} alt="" />
                                    </figure>
                                </div>
                            </div>
                            <div class="user-video"></div>
                            <div class="call-footer">
                                <div class="call-icons">
                                    <ul class="call-items">
                                        <li class="call-item call-end">
                                            <a href title="Call End" data-placement="top" data-toggle="tooltip" onClick={callDisConnect}>
                                                <i class="fas fa-phone"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* <div className="Incoming-vedio-call">
                <div className="initiatecall-income">
                    <div className="call-cut-vedio">
                        <div className="image-text-container-income">
                            <Link onClick={callDisConnect}>
                                <img src={Redcall} alt="red" style={{ marginLeft: '10px', marginBottom: '23px' }} />
                            </Link>
                            <div className="image-text"></div>
                        </div>
                    </div>
                </div>
            </div> */}
        </>
    )
}

export default OutgoingCall
