import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Row, Modal, ModalHeader, ModalBody, ModalFooter, Input, Button } from 'reactstrap'
import authenticationCpnIsServices from "../../../services/cpnIsServices";
import { toast } from "react-toastify";
import SpinnerLoader from '../../common/Spinner';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { log } from 'util';
const MessageModal = (props) => {

    const [IsLoader, setIsLoader] = useState(false);

    const validationSchema = Yup.object({
        selectedUser: Yup.string().required('Please select a recepient.'),
        description: Yup.string().required('Description is required.'),
    });


    const formikPatient = useFormik({
        initialValues: {
            selectedUser: '',
            description: '',
        },
        validationSchema,
        onSubmit: async (values) => {
            const payload = {
                "message": values.description,
                "patientId": "65083bfe7852bf8b0d1704d3",
                "cpnId": props.senderId
            }
            try {
                setIsLoader(true);
                let res = await authenticationCpnIsServices.sendMessageWithPatient(payload)
                if (res.data.status === 200) {
                    setIsLoader(false);
                    toast.success(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                    props.toggle()
                } else {
                    setIsLoader(false);
                    toast.error(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                }
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        },
    });


    const formikEC = useFormik({
        initialValues: {
            selectedUser: '',
            description: '',
        },
        validationSchema,
        onSubmit: async (values) => {
            const payload = {
                "message": values.description,
                "expertConsulatant": "64faf5fa5015a03d480e5f41",
                "cpnId": props.senderId
            }
            try {
                setIsLoader(true);
                let res = await authenticationCpnIsServices.sendMessageWithExpert(payload)
                if (res.data.status === 200) {
                    setIsLoader(false);
                    toast.success(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                    props.toggle()
                } else {
                    setIsLoader(false);
                    toast.error(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                }
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }
        },
    });
    console.log(formikPatient.errors);



    return (
        <>
            {IsLoader && <SpinnerLoader />}
            {props.cmp === "PATIENT-MSG" ?
                <Modal isOpen={props.open} toggle={props.toggle} className="custom-modal" centered>
                    <div className="modal-overlay">
                        <ModalHeader toggle={props.toggle} />
                        <ModalBody>
                            <form onSubmit={formikPatient.handleSubmit}>
                                <div>
                                    <h5 style={{ marginLeft: '5px' }}>Patient</h5>
                                    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                                        <Input
                                            style={{ height: '37px' }}
                                            id='selectedUser'
                                            type='select'
                                            {...formikPatient.getFieldProps('selectedUser')}
                                        >
                                            <option value="">Select Patient</option>
                                            <option value="1">user 1</option>
                                            <option value="2">user 2</option>
                                        </Input>
                                    </div>
                                    {formikPatient.touched.selectedUser && formikPatient.errors.selectedUser ? (
                                        <div className="validation_error">{formikPatient.errors.selectedUser}</div>
                                    ) : null}
                                    <h5 style={{ marginTop: '10px', marginLeft: '5px' }}>Description</h5>
                                    <Input
                                        type='textarea'
                                        id='description'
                                        name='description'
                                        rows={6}
                                        placeholder='Type here...'
                                        {...formikPatient.getFieldProps('description')}
                                    />
                                    {formikPatient.touched.description && formikPatient.errors.description ? (
                                        <div className="validation_error">{formikPatient.errors.description}</div>
                                    ) : null}
                                    <div>
                                        <Button className='initialbutton' type="submit">Submit</Button>
                                    </div>
                                </div>
                            </form>
                        </ModalBody>
                    </div>
                </Modal>
                :
                <Modal isOpen={props.open} toggle={props.toggle} className="custom-modal" centered>
                    <div className="modal-overlay">
                        <ModalHeader toggle={props.toggle} />
                        <ModalBody>
                            <form onSubmit={formikEC.handleSubmit}>
                                <div>
                                    <h5 style={{ marginLeft: '5px' }}>Expert Consultant</h5>
                                    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                                        <Input
                                            style={{ height: '37px' }}
                                            id='selectedUser'
                                            type='select'
                                            {...formikEC.getFieldProps('selectedUser')}
                                        >
                                            <option value="">Select Expert Consultant</option>
                                            <option value="1">user 1</option>
                                            <option value="2">user 2</option>
                                        </Input>
                                    </div>
                                    {formikEC.touched.selectedUser && formikEC.errors.selectedUser ? (
                                        <div className="validation_error">{formikEC.errors.selectedUser}</div>
                                    ) : null}
                                    <h5 style={{ marginTop: '10px', marginLeft: '5px' }}>Description</h5>
                                    <Input
                                        type='textarea'
                                        id='description'
                                        name='description'
                                        rows={6}
                                        placeholder='Type here...'
                                        {...formikEC.getFieldProps('description')}
                                    />
                                    {formikEC.touched.description && formikEC.errors.description ? (
                                        <div className="validation_error">{formikEC.errors.description}</div>
                                    ) : null}
                                    <div>
                                        <Button className='initialbutton' type="submit">Submit</Button>
                                    </div>
                                </div>
                            </form>
                        </ModalBody>
                    </div>
                </Modal>}
        </>
    )
}

export default MessageModal