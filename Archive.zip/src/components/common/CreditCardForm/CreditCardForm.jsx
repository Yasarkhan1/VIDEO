import React, { useState, useEffect } from 'react';
import {
    FormGroup, Form, Button, Input, Label, Col, Row, Modal, ModalFooter,
    ModalHeader, ModalBody
} from 'reactstrap'
import { useFormik } from 'formik'
import Checkpoint from '../../../assests/images/check-read-svgrepo-com.png'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import authenticationServices from "../../../services";
import { useSelector } from 'react-redux';
import * as Yup from 'yup';
import { toast } from "react-toastify";
import SpinnerLoader from '../../common/Spinner'
import { checkSpace } from '../../../utils';
function CreditCardForm(props) {
    const location = useLocation()
    const navigate = useNavigate()
    const [IsLoader, setIsLoader] = useState(false);
    const appointmentId = location?.state?.appointmentId
    const [cvv, setCvv] = useState(null);
    const [modal, setModal] = useState(false);
    const allCardData = props?.allCardData?.length ? props.allCardData : []
    const selectedCardId = props?.selectedCardId
    const toggle = (routes) => {
        setModal(!modal)
        console.log(routes);
        if (routes != '') {
            // navigate(`${routes}`, { replace: true })
        }
    };

    console.log("cvv==>", cvv);
    useEffect(() => {
        if (selectedCardId != '' && allCardData?.length) {
            const selectedCard = allCardData.find(x => x._id === selectedCardId)
            console.log("selectedCard++", selectedCard);
            formik.setValues({
                // paymentMethod: selectedCard?.paymentMethod,
                card_number: selectedCard?.cardNumber,
                card_expiry: selectedCard?.expiry,
                // card_cvv: selectedCard?.ccv,
                card_holder_name: selectedCard?.name,
            });
            setCvv(selectedCard?.ccv)
        } else {
            // formik.resetForm()
        }
    }, [selectedCardId, allCardData])


    // Function to validate the card number using Luhn algorithm
    // const validateCardNumber = (value) => {
    //     // Remove non-digit characters
    //     const cardNumber = value.replace(/\D/g, '');

    //     let sum = 0;
    //     let doubleUp = false;
    //     for (let i = cardNumber.length - 1; i >= 0; i--) {
    //         let digit = parseInt(cardNumber.charAt(i), 10);
    //         if (doubleUp) {
    //             if ((digit *= 2) > 9) digit -= 9;
    //         }
    //         sum += digit;
    //         doubleUp = !doubleUp;
    //     }
    //     return sum % 10 === 0;
    // };

    const validateCardNumber = (value) => {
        // Remove non-digit characters
        const cardNumber = value.replace(/\D/g, '');

        // Check if the input is not a number or an empty string
        if (!/^\d+$/.test(cardNumber)) {
            throw new Error('Invalid input. Please provide a valid numeric card number.');
        }

        // Regular expressions for card types
        const visa = /^(?:4[0-9]{12}(?:[0-9]{3})?)$/;
        const mastercardRegEx = /^(?:5[1-5][0-9]{14})$/;
        const amexpRegEx = /^(?:3[47][0-9]{13})$/;
        const discovRegEx = /^(?:6(?:011|5[0-9][0-9])[0-9]{12})$/;

        // Check if the card number matches any of the known patterns
        if (visa.test(cardNumber)) {
            return true; // Visa card
        } else if (mastercardRegEx.test(cardNumber)) {
            return true; // MasterCard
        } else if (amexpRegEx.test(cardNumber)) {
            return true; // American Express
        } else if (discovRegEx.test(cardNumber)) {
            return true; // Discover
        } else {
            return false; // Card type not recognized
        }
    };


    const validationSchemaCard = Yup.object().shape({
        // paymentMethod: Yup.string().required('Select payment method'),
        card_number: Yup.string()
            .required('Card number is required.')
            .test(
                'card_number',
                'Invalid card number.',
                (value) => validateCardNumber(value)
            )
        // .matches(/^[1-9]\d*$/, 'Card number must not start with zero.')
        // .matches(/^\d+$/, 'Card number must be numeric.')
        // .matches(/^\d{16}$/, 'Invalid card number')
        // .required('Card number is required'),
        ,
        card_expiry: Yup.string().required("Enter card expiry date.")
            .test(
                'card_expiry',
                'Invalid expiry date.',
                (value) => /^(0[1-9]|1[0-2])\/\d{2}$/.test(value)
            )
            .test('card_expiry', 'Invalid expiry date.', (value) => {
                if (!value) return false;

                const currentDate = new Date();
                const currentYear = Number(currentDate.getFullYear().toString().slice(-2)); // Get the last two digits of the current year
                const currentMonth = currentDate.getMonth() + 1;

                const [expiryMonth, expiryYear] = value.split('/');
                const cardExpiryYear = parseInt(expiryYear, 10);
                const cardExpiryMonth = parseInt(expiryMonth, 10);
                // console.log("currentYear,currentMonth,cardExpiryYear,cardExpiryMonth", currentYear, currentMonth, cardExpiryYear, cardExpiryMonth);
                if (
                    cardExpiryYear < (currentYear) ||
                    ((cardExpiryYear === (currentYear)) && (cardExpiryMonth < currentMonth))
                ) {
                    return false;
                }

                return true;
            }),
        //   .matches(/^(0[1-9]|1[0-2])\/\d{2}$/, 'Invalid expiry date. Use MM/YY format.'),
        card_cvv: Yup.string().required("Enter your cvv number.").matches(/^\d{3}$/, 'CVV number must be 3 digits.'),
        card_holder_name: Yup.string().matches(/^[a-zA-Z ]*$/, 'Please enter valid name').required("Enter card holder name")

    })

    const formik = useFormik({
        initialValues: {
            paymentMethod: "Visa",
            card_number: '',
            card_expiry: '',
            card_cvv: '',
            card_holder_name: '',
        },
        validationSchema: validationSchemaCard,

        onSubmit: async (values) => {


            const payload = {
                "paymentMethod": "Visa",
                "name": values.card_holder_name,
                "cardNumber": values.card_number?.split(" ")?.join(""),
                "expiry": values.card_expiry,
                "ccv": values.card_cvv,
            }
            if (cvv != null && cvv != values.card_cvv) {
                toast.warn("Please enter correct Cvv Code", {
                    position: toast.POSITION.TOP_RIGHT,
                });
                return false
            }
            if (selectedCardId) {
                payload["cardId"] = selectedCardId
            }
            console.log("paylod_____", payload);
            try {

                setIsLoader(true);
                let res = await authenticationServices.addCardDetails(payload, 5);
                // console.log("addCardDetails==", res);
                if (res.status === 200) {
                    const appointmentId = res.data.data.appointmentId
                    setIsLoader(false);
                    toast.success(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                    props.setOpenCard(!props.openCard)
                    props.getAllCardApi()
                    props.cardAdded(true)
                    // setModal(true)

                    // navigate("/")
                    // navigate("/new-appointment-6", { state: { appointmentId: appointmentId }, replace: true })
                } else {
                    setIsLoader(false);
                    toast.error(res.data.message, {
                        position: toast.POSITION.TOP_RIGHT,
                    });
                }
            } catch (error) {
                toast.error(error, {
                    position: toast.POSITION.TOP_RIGHT,
                });
            }


        }


    });

    // const cardnumber = (inputtxt) => {
    //     var matches = inputtxt.match(/(\d+)/);
    //     var cardno = "";
    //     console.log(matches);
    //     if (matches) {
    //         cardno = inputtxt.split(" ").join("");
    //     }
    //     console.log(cardno);
    //     var cardtype1 = formik.values.card_number;
    //     //var visa = /^(?:4[0-9]{16}(?:[0-9]{3})?)$/;
    // var visa = /^(?:4[0-9]{2}?)$/;
    // var mastercardRegEx = /^(?:5[1-5][0-9]{3})$/;
    // var amexpRegEx = /^(?:3[47][0-9]{3})$/;
    // var discovRegEx = /^(?:6(?:011|5[0-9][0-9])[0-9]{5})$/;
    // console.log(visa.test(cardno));
    //     if (visa.test(cardno) === true) {
    //         //eg:4651970022334445
    //         cardtype1 = "far fa fa-3x fa-cc-visa  carddetail-cardtype";
    //     } else if (mastercardRegEx.test(cardno) === true) {
    //         cardtype1 = "far fa fa-3x fa-cc-mastercard carddetail-cardtype";
    //     } else if (amexpRegEx.test(cardno) === true) {
    //         cardtype1 = "far fa fa-3x fa-cc-amex carddetail-cardtype";
    //     } else if (discovRegEx.test(cardno) === true) {
    //         cardtype1 = "far fa fa-3x fa-cc-discover carddetail-cardtype";
    //     }
    //     return cardtype1;
    // };

    const expriy_format = (value) => {
        const expdate = value;
        const expDateFormatter =
            expdate.replace(/\//g, "").substring(0, 2) +
            (expdate.length > 2 ? "/" : "") +
            expdate.replace(/\//g, "").substring(2, 4);
        return expDateFormatter;
    };

    const cc_format = (value) => {
        const cardNo = value
        const v = cardNo?.replace(/[^0-9]/gi, "").substr(0, 16);

        const parts = [];
        for (let i = 0; i < v.length; i += 4) {
            parts.push(v.substr(i, 4));
        }
        return parts.length > 1 ? parts.join(" ") : cardNo;
    };

    return (
        <>

            {IsLoader && <SpinnerLoader />}
            <Form onSubmit={formik.handleSubmit}>
                <Col md={12}>
                    <FormGroup>
                        <div className="card-payment  flex-column">
                            <label className='card-details'>Add Card Details</label>
                            <div className="card-number mb-2">
                                <Input
                                    min={1}
                                    // maxLength={16}
                                    type="text"
                                    name='card_number'
                                    placeholder='Enter your card number'
                                    // {...formik.getFieldProps("card_number")}
                                    onBlur={formik.handleBlur}
                                    value={cc_format(formik.values.card_number)}
                                    onChange={formik.handleChange}
                                    // onKeyPress={(event) => {
                                    //     if (!/[0-9]/.test(event.key)) {
                                    //         event.preventDefault();
                                    //     }
                                    // }}
                                    onKeyDown={checkSpace}
                                    // onInput={(e) => (e.target.value = e.target.value.slice(0, 16))}
                                    // onWheel={(e) => e.target.blur()}
                                    className={formik.touched.card_number && formik.errors.card_number ? 'is-invalid' : "null"}
                                />
                                {formik.touched.card_number && formik.errors.card_number ? <p className='validation_error'>{formik.errors.card_number}</p> : ""}
                            </div>

                            <div className="container d-flex mb-2">
                                <div className="row">
                                    <div className="col">

                                        <Label>Card Expiry</Label>
                                        <Input
                                            type="text"
                                            name='card_expiry'
                                            placeholder='MM/YY'
                                            maxLength={5}
                                            // {...formik.getFieldProps("card_expiry")}
                                            onBlur={formik.handleBlur}
                                            value={expriy_format(formik.values.card_expiry)}
                                            onChange={formik.handleChange}
                                            className={formik.touched.card_expiry && formik.errors.card_expiry ? 'is-invalid' : "null"}
                                        />

                                        {formik.touched.card_expiry && formik.errors.card_expiry ? <small className='validation_error'>{formik.errors.card_expiry}</small> : ""}

                                    </div>
                                    <div className="col">
                                        <Label>Cvv</Label>
                                        <Input
                                            name='card_cvv'
                                            type='number'
                                            placeholder='Enter cvv code'
                                            {...formik.getFieldProps("card_cvv")}
                                            onKeyDown={checkSpace}
                                            onInput={(e) => (e.target.value = e.target.value.slice(0, 3))}
                                            onWheel={(e) => e.target.blur()}
                                            className={formik.touched.card_cvv && formik.errors.card_cvv ? 'is-invalid' : "null"}

                                        />
                                        {formik.touched.card_cvv && formik.errors.card_cvv ? <small className='validation_error'>{formik.errors.card_cvv}</small> : ""}
                                    </div>
                                </div>
                            </div>
                            <div className="container text-left  mb-2">
                                <div className="row">
                                    <div className="col">
                                        <Label>Card Holder Name</Label>
                                        <Input
                                            name='card_holder_name'
                                            type='text'
                                            placeholder='Enter card holder name'
                                            {...formik.getFieldProps("card_holder_name")}
                                            className={formik.touched.card_holder_name && formik.errors.card_holder_name ? 'is-invalid' : "null"}
                                        />
                                        {formik.touched.card_holder_name && formik.errors.card_holder_name ? <small className='validation_error'>{formik.errors.card_holder_name}</small> : ""}
                                    </div>
                                </div>
                            </div>

                        </div>

                    </FormGroup>

                </Col>
                <div className="button-container">
                    {/* <Link to={'/'}> */}
                    <Button color="primary" className='next-button' type='submit'>
                        Add
                    </Button>
                    {/* </Link> */}

                </div>
            </Form>


            {/* <Modal isOpen={true} toggle={() => toggle("/scheduled-appointments")} className="custom-modal">
                <div className="modal-overlay">
                    <ModalHeader toggle={() => toggle("/scheduled-appointments")} />
                    <ModalBody>
                        <Form onSubmit={formik.handleSubmit}>
                            <Col md={12}>
                                <FormGroup>
                                    <div className="card-payment  flex-column">
                                        <label className='card-details'>Add Card Details</label>
                                        <div className="card-number">
                                            <Input
                                                min={1}
                                                // maxLength={16}
                                                type="text"
                                                name='card_number'
                                                placeholder='Enter your card number'
                                                // {...formik.getFieldProps("card_number")}
                                                onBlur={formik.handleBlur}
                                                value={cc_format(formik.values.card_number)}
                                                onChange={formik.handleChange}
                                                // onKeyPress={(event) => {
                                                //     if (!/[0-9]/.test(event.key)) {
                                                //         event.preventDefault();
                                                //     }
                                                // }}
                                                onKeyDown={checkSpace}
                                                // onInput={(e) => (e.target.value = e.target.value.slice(0, 16))}
                                                // onWheel={(e) => e.target.blur()}
                                                className={formik.touched.card_number && formik.errors.card_number ? 'is-invalid' : "null"}
                                            />
                                            {formik.touched.card_number && formik.errors.card_number ? <p className='validation_error'>{formik.errors.card_number}</p> : ""}
                                        </div>

                                        <div className="container d-flex">
                                            <div className="row">
                                                <div className="col">

                                                    <Label>Card Expiry</Label>
                                                    <Input
                                                        type="text"
                                                        name='card_expiry'
                                                        placeholder='MM/YY'
                                                        maxLength={5}
                                                        // {...formik.getFieldProps("card_expiry")}
                                                        onBlur={formik.handleBlur}
                                                        value={expriy_format(formik.values.card_expiry)}
                                                        onChange={formik.handleChange}
                                                        className={formik.touched.card_expiry && formik.errors.card_expiry ? 'is-invalid' : "null"}
                                                    />

                                                    {formik.touched.card_expiry && formik.errors.card_expiry ? <small className='validation_error'>{formik.errors.card_expiry}</small> : ""}

                                                </div>
                                                <div className="col">
                                                    <Label>Cvv</Label>
                                                    <Input
                                                        name='card_cvv'
                                                        type='number'
                                                        placeholder='Enter cvv code'
                                                        {...formik.getFieldProps("card_cvv")}
                                                        onKeyDown={checkSpace}
                                                        onInput={(e) => (e.target.value = e.target.value.slice(0, 3))}
                                                        onWheel={(e) => e.target.blur()}
                                                        className={formik.touched.card_cvv && formik.errors.card_cvv ? 'is-invalid' : "null"}

                                                    />
                                                    {formik.touched.card_cvv && formik.errors.card_cvv ? <small className='validation_error'>{formik.errors.card_cvv}</small> : ""}
                                                </div>
                                            </div>
                                        </div>
                                        <div className="container text-left ">
                                            <div className="row">
                                                <div className="col">
                                                    <Label>Card Holder Name</Label>
                                                    <Input
                                                        name='card_holder_name'
                                                        type='text'
                                                        placeholder='Enter card holder name'
                                                        {...formik.getFieldProps("card_holder_name")}
                                                        className={formik.touched.card_holder_name && formik.errors.card_holder_name ? 'is-invalid' : "null"}
                                                    />
                                                    {formik.touched.card_holder_name && formik.errors.card_holder_name ? <small className='validation_error'>{formik.errors.card_holder_name}</small> : ""}
                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                </FormGroup>

                            </Col>
                            <div className="button-container">
                                <Button color="primary" className='next-button' type='submit'>
                                    Add
                                </Button>

                            </div>
                        </Form>
                    </ModalBody>
                </div>
            </Modal> */}
            {/* <div style={{ textAlign: 'center' }}>
                            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '120px' }}>
                                <img src={Checkpoint} alt="Icon" />
                            </div>
                            <div >
                                <h2 style={{ fontSize: "22px", marginBottom: "15px" }}>
                                    Your appointment has been requested. You will get a notification soon.
                                </h2>

                            </div>
                        </div> */}
        </>
    )
}

export default CreditCardForm
