import React, { useState, useEffect } from 'react'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import dashboard from '../../../assests/images/dashboard-svgrepo-com.svg'
import userprofile from '../../../assests/images/user-circle-svgrepo-com.svg'
import message from '../../../assests/images/messages-mail-svgrepo-com.svg'
import faqfile from '../../../assests/images/faq-file-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import { Navbar, Nav } from 'react-bootstrap';
import { formToJSON } from 'axios'

const Sidebar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();
  const url = location.pathname;

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };



  return (
    <>
      {/* <div className="sidebar">
      <Link to="/patient-dashboard" className='request dashboad-text'>
        <img src={dashboard} alt="" /> Dashboard</Link>

      <Link className='request'> <img src={userprofile} alt="" /> My Account
        <ul className='submenu-text text1'>
          <Link to={"/my-profile"}> -Personal Details</Link>
          <Link to={"/login-details"}> -Login Detail</Link>
        </ul>
      </Link>

      <Link className='request' to={"/patient-appointment"} ><img src={clendra} alt="" />Appointments
        <ul className='submenu-text text2'>
          <Link to={"/new-appointment-1"}> -New Appointments</Link>
          <Link to={"/scheduled-appointments"}> -Schduled Appointments</Link>
          <Link to={"/completed-appointments"}> -Completed Appointments</Link>
        </ul>
      </Link>

      <Link className='request' to={"/patient-messages"}><img src={message} alt="Medical Information" /> Message</Link>
      <Link className='request' to={"/payment-information"}><img src={Economic} alt="Payment Information" /> Payment Information</Link>
      <Link className='request'><img src={Economic} alt="" /> Agreements</Link>
      <Link className='request' to={'/patient-faq'}><img src={faqfile} alt="" /> FAQ's</Link>

    </div> */}
      <div className="sidebar">
        <Navbar bg="transparent" expand="lg">
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="flex-column">
              <Link to="/patient-dashboard" className='request dashboad-text'>
                <img src={dashboard} alt="" /> Dashboard</Link>

              <Link className='request'> <img src={userprofile} alt="" /> My Account
                <ul className='submenu-text text1'>
                  <Link to={"/my-profile"}> -Personal Details</Link>
                  <Link to={"/login-details"}> -Login Detail</Link>
                </ul>
              </Link>

              <Link className='request' to={"/patient-appointment"} ><img src={clendra} alt="" />Appointments
                <ul className='submenu-text text2'>
                  <Link to={"/new-appointment-1"}> -New Appointments</Link>
                  <Link to={"/scheduled-appointments"}> -Schduled Appointments</Link>
                  <Link to={"/completed-appointments"}> -Completed Appointments</Link>
                </ul>
              </Link>

              <Link className='request' to={"/patient-messages"}><img src={message} alt="Medical Information" /> Message</Link>
              <Link className='request' to={"/payment-information"}><img src={Economic} alt="Payment Information" /> Payment Information</Link>
              <Link className='request'><img src={Economic} alt="" /> Agreements</Link>
              <Link className='request' to={'/patient-faq'}><img src={faqfile} alt="" /> FAQ's</Link>
            </Nav>
          </Navbar.Collapse>
        </Navbar>

      </div>

    </>


  )
}

export default Sidebar

