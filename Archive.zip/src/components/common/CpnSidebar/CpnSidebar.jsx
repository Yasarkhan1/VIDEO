import React, { useState } from 'react'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import dashboard from '../../../assests/images/dashboard-svgrepo-com.svg'
import userprofile from '../../../assests/images/user-circle-svgrepo-com.svg'
import message from '../../../assests/images/messages-mail-svgrepo-com.svg'
import professionallogo from '../../../assests/images/address-card-svgrepo-com.svg';
import faqfile from '../../../assests/images/faq-file-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import { formToJSON } from 'axios'

const CpnSidebar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation()
  const url = location.pathname
  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };
  return (
    <>
      <div className="cpn-sidebar">
        <div className="sidebar">
          <Link to="/cpn-dashboard" className='request dashboad-text'>
            <img src={dashboard} alt="" /> Dashboard</Link>
          <Link className='request' to={"/cpn-my-profile"}>
            <img src={userprofile} alt="" /> My Profile </Link>
          <Link className='request' to={"/cpn-professional-details"}>
            <img src={professionallogo} alt="" /> Professional Details </Link>

          <Link className='request'><img src={clendra} alt="" /> Appointments
            <ul className='submenu-text text2'>
              <Link to={"/cpn-new-appointments"}> -New Appointments</Link>
              <Link to={"/cpn-patient-appointment"}> -Patient Appointments</Link>
              <Link to={"/cpn-ec-list"}> -EC List</Link>
              <Link to={"/cpn-surevey-notes-list"}> -Survey & Notes List</Link>

            </ul>
          </Link>
          <Link className='request'> <img src={message} alt="Medical Information" /> Messages
            <ul className='submenu-text text1'>
              <Link to={"/cpn-patient-message"}> -Patient</Link>
              <Link to={"/cpn-ec-message"}> -Expert Consultant</Link>
            </ul>
          </Link>
        </div>
      </div>
    </>
  )
}

export default CpnSidebar
