import React from 'react'
import { useLocation } from 'react-router-dom';
function AppointNavbar({ }) {

    const location = useLocation();
    const currentStep = (location.pathname.split('-')[2]); // Extract step number from the URL
    return (
        <div className='appointment-navbar'>
            <nav className="navbar navbar-expand-lg navbar-light ">
                <a className="navbar-brand">New Request Appointment:</a>
                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse " id="navbarNav">
                    <ul className="navbar-nav">
                        {[1, 2, 3, 4, 5, 6, 7].map((stepNumber) => (

                            <li className="nav-item" key={stepNumber}>
                                <a className={currentStep >= stepNumber ? ' nav-link' : 'nav-link low-opacity'} > Step {stepNumber}</a>
                            </li>


                        ))}
                        {/* <li className="nav-item">
                            <a className="nav-link" >Step 1</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link low-opacity" >Step 2</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" >Step 3</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" >Step 4</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" >Step 5</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" >Step 6</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" >Step 7</a>
                        </li> */}
                    </ul>
                </div>
            </nav>
            <div className="dot-line"></div>
        </div>
    )
}

export default AppointNavbar
