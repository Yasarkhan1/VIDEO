import React from 'react'
import { Spinner } from 'reactstrap';

function SpinnerLoader() {
    
    return (
        <div className = "loader">
            <div className = "d-flex flex-column">
                <label >
                <Spinner 
                    color="info"  
                    style={{
                        height: '3rem',
                        width: '3rem'
                    }}
                />
                </label>
            </div>
        </div>
    )
}

export default SpinnerLoader