import React, { useState } from 'react'
import clendra from '../../../assests/images/calendar-svgrepo-com (5).svg'
import dashboard from '../../../assests/images/dashboard-svgrepo-com.svg'
import userprofile from '../../../assests/images/user-circle-svgrepo-com.svg'
import message from '../../../assests/images/messages-mail-svgrepo-com.svg'
import faqfile from '../../../assests/images/faq-file-svgrepo-com.svg'
import Economic from '../../../assests/images/economic-and-information-committee-svgrepo-com.svg'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import { formToJSON } from 'axios'



const ExpertSidebar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const location = useLocation()
  const url = location.pathname;

  const toggleSidebar = () => {
    setIsSidebarOpen(isSidebarOpen);
  };




  return (

    <>
      <div className="expert-sidebar">
        <div className="sidebar">
          <Link to="/expert-dashboard" className='request dashboad-text'>
            <img src={dashboard} alt="" /> Dashboard</Link>
          <Link className='request'><img src={clendra} alt="" /> Appointments
            <ul className='submenu-text text2'>
              <Link to={"/expert-scheduled-appointment"}> -Schduled Appointments</Link>
              <Link to={"/expert-completed-appointment"}> -Completed Appointments</Link>
            </ul>
          </Link>
          <Link className='request' to={"/expert-availability"}><img src={clendra} alt="" /> My Availability </Link>
          <Link className='request'> <img src={userprofile} alt="" /> My Account
            <ul className='submenu-text text1'>
              <Link to={"/expert-my-profile"}> -Personal Details</Link>
              <Link to={"/expert-professional-details"}> -Professional Details</Link>
              <Link to={"/expert-professional-fees"} > -Professional Fee</Link>
              <Link to={"/expert-login-details"}> -Login Details</Link>
            </ul>
          </Link>
          <Link className='request' to={'/expert-payment-information'}><img src={Economic} alt="Payment Information" /> Payment Information</Link>
          <Link className='request' to={"/expert-message"} ><img src={message} alt="Medical Information" /> Message</Link>
        </div>
      </div>


    </>
  )
}

export default ExpertSidebar