import React from 'react'
import footerImg from "../../../assests/images/CPNHealthFINAL_fontembed.svg";
import fbIcon from "../../../assests/images/20673.svg";
import twitter from "../../../assests/images/1384017.svg";
import linkedIn from "../../../assests/images/1384014.svg";
import insta from "../../../assests/images/1384015.svg";
const Footer = () => {
  return (
    // < !--Last Footer Start Coding-- >
    <footer className='landing-footer'>
      <div className="container footer-info">
        <div className="d-flex footer-img">
          <div className="col last-logo">
            <img src={footerImg} alt="" />
          </div>
        </div> 
        <div className="row-left">
          <ul className='About-row-left' >
            <li>About Us</li>
            <li>Our Media Review</li>
            <li>Team</li>
            <li>Blog</li>
            <li>Career</li>
            <li>Press Sucess Stories</li>
            <li>Testmonials</li>
          </ul>
          <ul className="second-list">
            <li >
              office@checkpointnow.co</li>
            <li>
              7 (1231) 904-539</li>
            <li>Follow Us
              <img src={fbIcon} alt="" />
              <img src={twitter} alt="" />
              <img src={linkedIn} alt="" />
              <img src={insta} alt="" />

            </li>

          </ul>
          
          <ul >
            <p className='copyright' >Copyright © 2023 Checkpoint Now (Global Health Limited). All Rights Reserved.</p>
          </ul>
          </div>
        
      </div>
    </footer>
  )
}

export default Footer