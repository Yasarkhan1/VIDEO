import React, { useState, useEffect } from 'react';
import {
    FormGroup, Form, Button, Input, Label, Col, Row, Modal, ModalFooter,
    ModalHeader, ModalBody
} from 'reactstrap'
import { useFormik } from 'formik'
import Checkpoint from '../../../assests/images/check-read-svgrepo-com.png'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import authenticationServices from "../../../services";
import { useSelector } from 'react-redux';
import * as Yup from 'yup';
import { toast } from "react-toastify";
import SpinnerLoader from '../../common/Spinner'
import { checkSpace } from '../../../utils';
function CouponForm() {
    const location = useLocation()
    const navigate = useNavigate()
    const [IsLoader, setIsLoader] = useState(false);
    const appointmentId = location?.state?.appointmentId
    const [modal, setModal] = useState(false);
    const toggle = (routes) => {
        setModal(!modal)
        console.log(routes);
        if (routes != '') {
            navigate(`${routes}`, { replace: true })
        }
    };

    const validationSchemaCard = Yup.object().shape({
        couponCode: Yup.string().required('Coupon is required'),
    })

    const formik = useFormik({
        initialValues: {

            couponCode: '',
        },
        validationSchema: validationSchemaCard,

        onSubmit: async (values) => {


            const payload = {

                "couponCode": values.couponCode
            }
            // try {

            //     setIsLoader(true);
            //     let res = await authenticationServices.addCardDetails(payload, 5);
            //     // console.log("addCardDetails==", res);
            //     if (res.status === 200) {
            //         const appointmentId = res.data.data.appointmentId
            //         setIsLoader(false);
            //         toast.success(res.data.message, {
            //             position: toast.POSITION.TOP_RIGHT,
            //         });
            //         setModal(true)
            //         // navigate("/")
            //         // navigate("/new-appointment-6", { state: { appointmentId: appointmentId }, replace: true })
            //     } else {
            //         setIsLoader(false);
            //         toast.error(res.data.message, {
            //             position: toast.POSITION.TOP_RIGHT,
            //         });
            //     }
            // } catch (error) {
            //     toast.error(error, {
            //         position: toast.POSITION.TOP_RIGHT,
            //     });
            // }





        }
    })

    return (
        <>

            {IsLoader && <SpinnerLoader />}

            <Form onSubmit={formik.handleSubmit}>
                <Col md={12}>
                    <FormGroup>
                        <div className="card-payment  flex-column">
                            <label className='card-details'>Add Coupon Code</label>
                            <div className="card-number">
                                <Input
                                    min={1}
                                    maxLength={8}
                                    type='text'
                                    name='couponCode'
                                    placeholder='Enter your coupon code'
                                    {...formik.getFieldProps("couponCode")}
                                    onKeyDown={checkSpace}
                                    className={formik.touched.couponCode && formik.errors.couponCode ? 'is-invalid' : "null"}
                                />
                                {formik.touched.couponCode && formik.errors.couponCode ? <small className='validation_error'>{formik.errors.couponCode}</small> : ""}
                            </div>
                        </div>
                    </FormGroup>

                </Col>
                <div className="button-container">
                    <Button color="primary" className='next-button' type='submit'>
                        Add
                    </Button>

                </div>
            </Form>


            <Modal isOpen={modal} toggle={() => toggle("/scheduled-appointments")} className="custom-modal">
                <div className="modal-overlay">
                    <ModalHeader toggle={() => toggle("/scheduled-appointments")} />
                    <ModalBody>
                        <div style={{ textAlign: 'center' }}>
                            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '120px' }}>
                                <img src={Checkpoint} alt="Icon" />
                            </div>
                            <div >
                                <h2 style={{ fontSize: "22px", marginBottom: "15px" }}>
                                    Your appointment has been requested. You will get a notification soon.
                                </h2>

                            </div>
                        </div>
                    </ModalBody>
                </div>
            </Modal>



        </>
    )
}

export default CouponForm
