import React, { useState, useEffect } from 'react';
import { FormGroup, Input, Nav, UncontrolledDropdown, Media, DropdownToggle, Progress, DropdownMenu, DropdownItem } from 'reactstrap';
import cpn from '../../../assests/images/CPNHealthFINAL_fontembed.svg';
import Logoimage from '../../../assests/images/ys.png';
import { Link, useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import authenticationServices from "../../../services";
import authenticationCpnIsServices from "../../../services/cpnIsServices";
import authenticationExpertServices from "../../../services/expertServices";
import { toast } from "react-toastify";
import { setCpnIsUser, setExpertUser, setUser } from '../../../stateManagement/userSlice';
import { setAllDropDown } from '../../../stateManagement/allDropDownSlice';
import SpinnerLoader from '../Spinner';
import VideoCall from '../CpnVedioCall/VideoCall';
const LoginNavbar = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const dropDownData = useSelector((state) => state.allDropDown);
  // console.log("dropDownData====+++", dropDownData);
  const [IsLoader, setIsLoader] = useState(false);
  const [userData, setUserData] = useState(null);
  // console.log("userData====+++", userData);
  const userType = sessionStorage.getItem("userType") ? sessionStorage.getItem("userType") : ""
  const [IsCallstarted, setIsCallstarted] = useState(false);
  const patientData = useSelector((state) => state.user?.data)
  const expertData = useSelector((state) => state?.user.expertUser)
  const cpnIsData = useSelector((state) => state?.user?.cpnIsUser)
  // console.log("expertData===", expertData);

  useEffect(() => {
    if (userData == null || userData == undefined) {
      if (userType === "3") {
        getCpnDetails()
      }
      else if (userType === "1") {
        getPetientDetails()
      }
      else if (userType === "2") {
        getConsultantDetails()
      }
      getAlldropdownOptions()
    }
  }, [userData, userType])



  const getCpnDetails = async () => {
    try {
      setIsLoader(true);
      let res = await authenticationCpnIsServices.getCpnDetails();
      if (res.data.status === 200) {
        setIsLoader(false);
        const userData = res.data.data[0]
        dispatch(setCpnIsUser(userData));

      } else {
        setIsLoader(false);
        toast.error(res.data.responseMessage, {
          position: toast.POSITION.TOP_RIGHT,
        });
      }
    } catch (error) {
      toast.error(error, {
        position: toast.POSITION.TOP_RIGHT,
      });
    }
  }


  const getConsultantDetails = async () => {
    try {
      setIsLoader(true);
      let res = await authenticationExpertServices.getConsultantDetails();
      // console.log("getConsultantDetails detalis res==>>", res);
      if (res.data.status === 200) {
        setIsLoader(false);
        const userData = res.data.data[0]
        dispatch(setExpertUser(userData));

      } else {
        setIsLoader(false);
        toast.error(res.data.responseMessage, {
          position: toast.POSITION.TOP_RIGHT,
        });
      }
    } catch (error) {
      toast.error(error, {
        position: toast.POSITION.TOP_RIGHT,
      });
    }
  }


  const getPetientDetails = async () => {
    try {
      setIsLoader(true);
      let res = await authenticationServices.getPetientDetails();
      // console.log("patient detalis res==>>", res);
      if (res.data.status === 200) {
        setIsLoader(false);
        const userData = res.data.data[0]
        dispatch(setUser(userData));

      } else {
        setIsLoader(false);
        toast.error(res.data.responseMessage, {
          position: toast.POSITION.TOP_RIGHT,
        });
      }
    } catch (error) {
      toast.error(error, {
        position: toast.POSITION.TOP_RIGHT,
      });
    }
  }

  const getAlldropdownOptions = async () => {
    try {
      setIsLoader(true);
      let res = await authenticationServices.dropdownOptions();
      // console.log("getAlldropdownOptions>>>==", res);
      if (res.data.status === 200) {
        setIsLoader(false);
        dispatch(setAllDropDown(res.data.dropdownOptions))
        // dispatch(setUser(userData));
      }
    } catch (error) {
      setIsLoader(false);
      toast.error(error, {
        position: toast.POSITION.TOP_RIGHT,
      });
    }
  }

  const logoutHandle = () => {
    // console.log("logout called");
    sessionStorage.clear();
    localStorage.removeItem("userType")
    dispatch(setUser(null));
    dispatch(setExpertUser(null));
    dispatch(setCpnIsUser(null));
    // localStorage.clear();
    navigate("/")
    // window.location.reload()
  }


  return (
    <>

      <div className="login-navbar">
        {IsLoader && <SpinnerLoader />}
        <div className="container-fluid custom-container-fluid">
          {/* {IsLoader && <SpinnerLoader />} */}
          <Nav className="navbar">
            <div className="container-fluid logo-container">
              <Link to="/patient-dashboard">
                <img src={cpn} alt="cpn health" className='cpn-logo' />
              </Link>
              <UncontrolledDropdown nav>
                <DropdownToggle className="pr-0" nav>
                  <Media className="align-items-center">
                    {userType === "1" ?
                      <a className="navbar-brand user-logo">
                        {patientData?.personalDetails?.name} <img src={patientData?.personalDetails?.image ?? Logoimage} alt="" className='logo' />
                      </a>
                      :
                      userType === "2" ?
                        <a className="navbar-brand user-logo">
                          {expertData?.personalDetails?.name} <img src={expertData?.personalDetails?.image ?? Logoimage} alt="" className='logo' />
                        </a>
                        :
                        <a className="navbar-brand user-logo">
                          {cpnIsData?.name} <img src={cpnIsData?.image ?? Logoimage} alt="" className='logo' />
                        </a>
                    }
                  </Media>
                </DropdownToggle>
                <DropdownMenu className="dropdown-menu-arrow" end>
                  <DropdownItem onClick={() => logoutHandle()}>
                    <i className="ni ni-user-run" />

                    <span>Logout</span>
                  </DropdownItem>
                </DropdownMenu>
              </UncontrolledDropdown>

            </div>

          </Nav>

          < div className="otp-input" >

            <Progress multi>
              <Progress
                bar
                value="35.33"
                style={{
                  height: '3px'
                }}
              />
              <Progress
                bar
                color="success"
                value="35.33"
                style={{ height: '3px' }}

              />
              <Progress
                bar
                color="info"
                value="35.33"
                style={{ height: '3px' }}
              />


            </Progress>
          </div >
        </div >

        {IsCallstarted && <VideoCall IsHeaderClicked={IsCallstarted} />}
      </div>
    </>

  )
}

export default LoginNavbar
