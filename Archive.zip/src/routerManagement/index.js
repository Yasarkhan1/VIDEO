
import React, {useEffect, lazy, Suspense, useState } from 'react';
import {  Route, Routes,useLocation,useNavigate } from 'react-router-dom';
import PageNotFound from '../components/pages/PageNotFound/PageNotFound';
import publicRoutes from './publicRoutes';
import { getSessionStorageOrDefault } from "../utils";
import SpinnerLoader from '../components/common/Spinner';
import privateRoutes from './privateRoutes';
function RouterManagement() {

  const navigate=useNavigate()
  const location=useLocation()
  const [isLogin, setisLogin] = useState(false)

  // function to get all the public routes
  const renderPublicRoutes = () => {
    return publicRoutes.map((data) => {
      return <Route {...data}/>;
    });
  };
  // function to get all the private routes
  const renderPrivateRoutes = () => {
    return privateRoutes.map((data) => {
      return <Route {...data}/>;
    });
  };

 // useEffect to prevent unauthorize access
  useEffect(() => {
    console.log("useEffect 1");
    const token = getSessionStorageOrDefault("token");
    if(!token){
      if (
            privateRoutes.filter((route) => route.path == location.pathname).length > 0 &&
            privateRoutes.filter((route) => route.path == location.pathname)?.[0].authorized
          )
          {
            setisLogin(false)
            // navigate("/")
          }
    }

  }, [location])

    useEffect(() => {
      console.log("useEffect 2");
        if(sessionStorage.getItem("token")){
        setisLogin(true)
      }
    }, [sessionStorage.getItem("token")])

  return (
       
        <Suspense fallback={<SpinnerLoader />}>
            <Routes>
              {isLogin ? renderPrivateRoutes() : renderPublicRoutes()}
              <Route path="/*" element={<PageNotFound />} />
            </Routes>
          </Suspense>
  );
}

export default RouterManagement;