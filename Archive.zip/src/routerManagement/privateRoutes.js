import React, { lazy } from 'react';
import NewAppointment from '../components/pages/Patient/NewAppointment';
import NewAppointment2 from '../components/pages/Patient/NewAppointment2';
import NewAppointment3 from '../components/pages/Patient/NewAppointment3';
import NewAppointment4 from '../components/pages/Patient/NewAppointment4';
import LoginDetails from '../components/pages/Patient/LoginDetails';
import NewAppointment5 from '../components/pages/Patient/NewAppointment5';
import NewAppointment6 from '../components/pages/Patient/NewAppointment6';
import NewAppointment7 from '../components/pages/Patient/NewAppointment7';
import ExpertDashboard from '../components/pages/ExpertConsultant/ExpertDashboard';
import ExpertLoginDetails from '../components/pages/ExpertConsultant/ExpertLoginDetails';
import PatientMeassage from '../components/pages/Patient/PatientMeassage';
import CpnDashboard from '../components/pages/Cpn/CpnDashboard';
import CpnMyProfile from '../components/pages/Cpn/CpnMyProfile';
import CpnProfessional from '../components/pages/Cpn/CpnProfessional';
import CpnNewAppointments from '../components/pages/Cpn/CpnNewAppointments';
import CpnPatientAppointment from '../components/pages/Cpn/CpnPatientAppointment';
import CpnEcList from '../components/pages/Cpn/CpnEcList';
import CpnSureveyNotesList from '../components/pages/Cpn/CpnSureveyNotesList';
import NewAppointmentPatientDetails from '../components/pages/Cpn/NewAppointmentPatientDetails';
import NewAppointmentSchedule from '../components/pages/Cpn/NewAppointmentSchedule';
import ExpertMyProfileEdit from '../components/pages/ExpertConsultant/ExpertMyProfileEdit';

import CpnMyProfileEdit from '../components/pages/Cpn/CpnMyProfileEdit';
import PaymentMethod from '../components/pages/Patient/PaymentMethod';
import InitiateVedioCall from '../components/pages/Patient/InitiateVedioCall';
import CpnECMessage from '../components/pages/Cpn/CpnECMessage';
import CpnPatientMessage from '../components/pages/Cpn/CpnPatientMessage';
import ExpertMessage from '../components/pages/ExpertConsultant/ExpertMessage';
import ExpertMessageView from '../components/pages/ExpertConsultant/ExpertMessageView';
import PatientViewMessage from '../components/pages/Patient/PatientViewMessage';
import CpnMessageView from '../components/pages/Cpn/CpnMessageView';
import CpnEcMessageView from '../components/pages/Cpn/CpnEcMessageView';
import ExpertProfessionalDetails from '../components/pages/ExpertConsultant/ExpertProfessionalDetails';
import ExpertProfessionalFees from '../components/pages/ExpertConsultant/ExpertProfessionalFees';


const PageNotFound = lazy(() => import('../components/pages/PageNotFound/PageNotFound'));
const PatientDashboard = lazy(() => import('../components/pages/Patient/PatientDashboard'));
const RequestNewAppointment = lazy(() => import('../components/pages/Patient/RequestNewAppointment'));
const ScheduledAppointments = lazy(() => import('../components/pages/Patient/ScheduledAppointments'));
const InitiateCall = lazy(() => import('../components/pages/Patient/InitiateCall'));
const CompletedAppointments = lazy(() => import('../components/pages/Patient/CompletedAppointments'));
const PaymentInformation = lazy(() => import('../components/pages/Patient/PaymentInformation'));
const Setting = lazy(() => import('../components/pages/Patient/Setting'));
const MyProfile = lazy(() => import('../components/pages/Patient/MyProfile'));
const ChangePassword = lazy(() => import('../components/pages/Patient/ChangePassword'));
const MyProfileEdit = lazy(() => import('../components/pages/Patient/MyProfileEdit'));
const MedicalInformation1 = lazy(() => import('../components/pages/Patient/MedicalInformation1'));
const MedicalInformation2 = lazy(() => import('../components/pages/Patient/MedicalInformation2'));
const MedicalInformation3 = lazy(() => import('../components/pages/Patient/MedicalInformation3'));
const MedicalInformation4 = lazy(() => import('../components/pages/Patient/MedicalInformation4'));
const MedicalInformation5 = lazy(() => import('../components/pages/Patient/MedicalInformation5'));
const ExpertAvailability = lazy(() => import('../components/pages/ExpertConsultant/ExpertAvailability'));
const ExpertScheduledAppointments = lazy(() => import('../components/pages/ExpertConsultant/ExpertScheduledAppointments'));
const ExpertCompletedAppoint = lazy(() => import('../components/pages/ExpertConsultant/ExpertCompletedAppoint'));
const ExpertPaymentInformation = lazy(() => import('../components/pages/ExpertConsultant/ExpertPaymentInformation'));
const ExpertSetting = lazy(() => import('../components/pages/ExpertConsultant/ExpertSetting'));
const ExpertMyProfile = lazy(() => import('../components/pages/ExpertConsultant/ExpertMyProfile'));
const ExpertChangePass = lazy(() => import('../components/pages/ExpertConsultant/ExpertChangePass'));
const ExpertPatientAppoint = lazy(() => import('../components/pages/ExpertConsultant/ExpertPatientAppoint'));
const ExpertProfileEdit = lazy(() => import('../components/pages/ExpertConsultant/ExpertProfileEdit'));
const VideoCall = lazy(() => import('../components/common/CpnVedioCall/VideoCall'));
const OutgoingCall = lazy(() => import('../components/common/CpnVedioCall/OutgoingCall'));
const IncomingCall = lazy(() => import('../components/common/CpnVedioCall/IncomingCall'));
const MessageDetails = lazy(() => import('../components/pages/Cpn/MessageDetails'));
const PatientFAQ = lazy(() => import('../components/pages/Patient/PatientFAQ'));
const Appointment = lazy(() => import('../components/pages/Patient/Appointment'));


const privateRoutes = [


  // {
  //   path: '/',
  //   element: <PatientDashboard/>,
  //   authorized: true,
  //   name:""
  // },
  {
    path: '/patient-dashboard',
    element: <PatientDashboard />,
    authorized: false,
    name: "PATIENT DASHBOARD"
  },
  {
    path: '/patient-messages',
    element: <PatientMeassage />,
    authorized: false,
    name: "PATIENT MESSAGES"
  },

  {
    path: '/scheduled-appointments',
    element: <ScheduledAppointments />,
    authorized: false,
    name: "SCHEDULED APPOINTMENT"
  },
  {
    path: '/initiate-call/:appointmentId',
    element: <InitiateCall />,
    authorized: false,
    name: "INIAL CALL"
  },

  {
    path: '/completed-appointments',
    element: <CompletedAppointments />,
    authorized: false,
    name: "COMPLETED APPOINTMENT"
  },
  {
    path: '/payment-information',
    element: <PaymentInformation />,
    authorized: false,
    name: "PAYMENT INFORMATION"
  },
  {
    path: "/payment-method",
    element: <PaymentMethod />,
    authorized: false,
    name: "PAYMENT METHOD"
  },
  {
    path: '/setting',
    element: <Setting />,
    authorized: true,
    name: "SETTING"
  },
  {
    path: '/my-profile',
    element: <MyProfile />,
    authorized: false,
    name: "MY PROFILE"
  },
  {
    path: '/change-password',
    element: <ChangePassword />,
    authorized: true,
    name: "CHANGE PASSWORD"
  },
  {
    path: '/my-profile-edit',
    element: <MyProfileEdit />,
    authorized: false,
    name: "MY PROFILE EDIT"
  },
  {
    path: '/expert-my-profile-edit',
    element: <ExpertMyProfileEdit />,
    authorized: false,
    name: "MY PROFILE EDIT"
  },
  {
    path: '/medical-information1',
    element: <MedicalInformation1 />,
    authorized: false,
    name: "MEDICAL INFO 1"
  },
  {
    path: '/medical-information2',
    element: <MedicalInformation2 />,
    authorized: true,
    name: "MEDICAL INFO 2"
  },
  {
    path: '/medical-information3',
    element: <MedicalInformation3 />,
    authorized: true,
    name: "MEDICAL INFO 3"
  },
  {
    path: '/medical-information4',
    element: <MedicalInformation4 />,
    authorized: true,
    name: "MEDICAL INFO 4"
  },
  {
    path: '/medical-information5',
    element: <MedicalInformation5 />,
    authorized: true,
    name: "MEDICAL INFO 5"
  },

  {
    path: "/initiate-vedio-call",
    element: <InitiateVedioCall />,
    authorized: false,
    name: "INITIATE VEDIO CALL"
  },
  // {
  //   path: "/incoming-vedio-call",
  //   element: <InitiateIncomingCall />,
  //   authorized: false,
  //   name: "INCOMING VEDIO CALL"
  // },
  {
    path: "/patient-appointment",
    element: <Appointment />,
    authorized: false,
    name: "PATIENT APPOINTMENT"

  },
  {
    path: "/patient-faq",
    element: <PatientFAQ />,
    authorized: false,
    name: "PATIENT FAQ"
  },
  {
    path: "/patient-view-message",
    element: <PatientViewMessage />,
    authorized: false,
    name: "PATIENT VIEW MESSAGE"
  },

  // Expert Routing
  {
    path: '/expert-dashboard',
    element: <ExpertDashboard />,
    authorized: false,
    name: "Expert DASHBOARD"
  },
  {
    path: '/expert-availability',
    element: <ExpertAvailability />,
    authorized: false,
    name: "EXPERT AVAILABILITY"
  },
  {
    path: '/expert-scheduled-appointment',
    element: <ExpertScheduledAppointments />,
    authorized: false,
    name: "EXPERT SCHEDULED APPOINT"
  },
  {
    path: '/expert-completed-appointment',
    element: <ExpertCompletedAppoint />,
    authorized: false,
    name: "EXPERT COMPLETED APPOINT"
  },
  {
    path: '/expert-payment-information',
    element: <ExpertPaymentInformation />,
    authorized: false,
    name: "EXPERT PAYMENT INFORMATION"
  },
  {
    path: '/expert-setting',
    element: <ExpertSetting />,
    authorized: true,
    name: "EXPERT Setting"
  },
  {
    path: '/expert-my-profile',
    element: <ExpertMyProfile />,
    authorized: false,
    name: "EXPERT MY PROFILE"
  },
  {
    path: '/expert-login-details',
    element: <ExpertLoginDetails />,
    authorized: false,
    name: "EXPERT LOGIN DETAILS"
  },
  {
    path: '/expert-change-pass',
    element: <ExpertChangePass />,
    authorized: true,
    name: "EXPERT CHANGE PASSWORD"
  },
  {
    path: '/expert-patient-appointment',
    element: <ExpertPatientAppoint />,
    authorized: true,
    name: "EXPERT PATIENT APPOINT"
  },
  {
    path: '/expert-profile-edit',
    element: <ExpertProfileEdit />,
    authorized: true,
    name: "EXPERT PROFILE EDIT"
  },
  {
    path: '/new-appointment-1',
    element: <NewAppointment />,
    authorized: false,
    name: "New Appointment1"
  },
  {
    path: '/new-appointment-2',
    element: <NewAppointment2 />,
    authorized: false,
    name: "New Appointment2"
  },
  {
    path: '/new-appointment-3',
    element: <NewAppointment3 />,
    authorized: false,
    name: "New Appointment3"
  },
  {
    path: '/new-appointment-4',
    element: <NewAppointment4 />,
    authorized: false,
    name: "New Appointment4"
  },
  {
    path: '/login-details',
    element: <LoginDetails />,
    authorized: false,
    name: "Login Detail"
  },
  {
    path: '/new-appointment-5',
    element: <NewAppointment5 />,
    authorized: false,
    name: "New Appointment5"
  },
  {
    path: '/new-appointment-6',
    element: <NewAppointment6 />,
    authorized: false,
    name: "New Appointment6"
  },
  {
    path: '/new-appointment-7',
    element: <NewAppointment7 />,
    authorized: false,
    name: "New Appointment7"
  },
  {
    path: "/expert-message",
    element: <ExpertMessage />,
    authorized: false,
    name: "EXPERT MESSAGE"
  },
  {
    path: "/expert-message-view",
    element: <ExpertMessageView />,
    authorized: false,
    name: "EXPERT MESSAGE VIEW"
  },
  {
    path: "/expert-professional-details",
    element: <ExpertProfessionalDetails />,
    authorized: false,
    name: "EXPERT PROFESSIONAL DETAILS"
  },
  {
    path: "/expert-professional-fees",
    element: <ExpertProfessionalFees />,
    authorized: false,
    name: "EXPERT PROFESSIONAL FEES"
  },

  // CPN ROUNTING START
  {
    path: "/cpn-dashboard",
    element: <CpnDashboard />,
    authorized: false,
    name: "CPN DASHBOARD"
  },
  {
    path: "/cpn-my-profile",
    element: <CpnMyProfile />,
    authorized: false,
    name: "CPN MY PROFILE"
  },
  {
    path: "/cpn-my-profile-edit",
    element: <CpnMyProfileEdit />,
    authorized: false,
    name: "CPN MY PROFILE EDIT"
  },
  {
    path: "/cpn-professional-details",
    element: <CpnProfessional />,
    authorized: false,
    name: "CPN PROFESSIONAL DETAILS"
  },
  {
    path: "/cpn-new-appointments",
    element: <CpnNewAppointments />,
    authorized: false,
    name: "CPN NEW APPOINTMENTS"
  },
  {
    path: "/cpn-patient-appointment",
    element: <CpnPatientAppointment />,
    authorized: false,
    name: "CPN PATIENT APPOINTMENTS"
  },
  {
    path: "/cpn-ec-list",
    element: <CpnEcList />,
    authorized: false,
    name: "CPN EC LIST"
  },
  {
    path: "/cpn-surevey-notes-list",
    element: <CpnSureveyNotesList />,
    authorized: false,
    name: "CPN SURVEY NOTES LIST"
  },
  {
    path: "/cpn-patient-message",
    element: <CpnPatientMessage />,
    authorized: false,
    name: "CPN PATIENT MESSAGE"
  },
  {
    path: "/cpn-ec-message",
    element: <CpnECMessage />,
    authorized: false,
    name: "CPN EXPERT CONSULTANT MESSAGE"
  },
  {
    path: "/cpn-new-appointment-pateint-details/:appointmentId",
    element: <NewAppointmentPatientDetails />,
    authorized: false,
    name: "New APPOINTMENT PATIENT DETAILS"
  },
  {
    path: "/cpn-new-appointment-schedule/:appointmentId",
    element: <NewAppointmentSchedule />,
    authorized: false,
    name: "NEW APPOINTMENT SCHEDULE"
  },
  {
    path: "/cpn-message-view/:messageId",
    element: <CpnMessageView />,
    authorized: false,
    name: "CPN MESSAGE VIEW"
  },
  {
    path: "/cpn-expert-message-view/:messageId",
    element: <CpnEcMessageView />,
    authorized: false,
    name: "CPN EC MESSAGE VIEW"
  },
  {
    path: "/incoming-call",
    element: <IncomingCall />,
    authorized: true,
    name: "Incoming CALL"
  },
  {
    path: "/outgoing-call",
    element: <OutgoingCall />,
    authorized: true,
    name: "Outgoing CALL"
  },
  {
    path: "/video-call/:appointmentId/:receiverId/:pushType/:userType",
    element: <VideoCall />,
    authorized: true,
    name: "VIDEO CALL"
  },

  {
    path: "/message-details",
    element: <MessageDetails />,
    authorized: false,
    name: "Message-details"
  },
  {
    path: '/*',
    element: <PageNotFound />,
  },

]


export default privateRoutes;