
import React, { lazy } from 'react';
import CpnSignUp1 from '../components/pages/Cpn/CpnSignUp1';
import CpnSignUp2 from '../components/pages/Cpn/CpnSignUp2';
import CpnSignUp3 from '../components/pages/Cpn/CpnSignUp3';
import { element } from 'prop-types';
import CpnLogin from '../components/pages/Cpn/CpnLogin';
// import ExpertProfSignup3 from '../components/pages/ExpertConsultant/ExpertProfSignup3';
// import ExpertScheduledAppoint from '../components/pages/ExpertConsultant/ExpertScheduledAppointments';


const PageNotFound = lazy(() => import('../components/pages/PageNotFound/PageNotFound'));
const LandingPage = lazy(() => import('../components/pages/LandingPage/LandingPage'));
const LoginAs = lazy(() => import('../components/pages/Login-as/LoginAs'));
const PatientLogin = lazy(() => import('../components/pages/Patient/PatientLogin'));
const Forgot = lazy(() => import('../components/pages/Patient/Forgot'));
const Otp = lazy(() => import('../components/pages/Patient/PatientOtp'));
const ResetPassword = lazy(() => import('../components/pages/Patient/ResetPassword'));
const PatientSignup1 = lazy(() => import('../components/pages/Patient/PatientSignup1'));
const PatientSignup2 = lazy(() => import('../components/pages/Patient/PatientSignup2'));
const PatientSignup3 = lazy(() => import('../components/pages/Patient/PatientSignup3'));
const ExpertLogin = lazy(() => import('../components/pages/ExpertConsultant/ExpertLogin'));
const ExpertSignUp1 = lazy(() => import('../components/pages/ExpertConsultant/ExpertSignUp1'));
const ExpertSignUp2 = lazy(() => import('../components/pages/ExpertConsultant/ExpertSignUp2'));
const ExpertSignUp3 = lazy(() => import('../components/pages/ExpertConsultant/ExpertSignUp3'));
const ExpertSignUp4 = lazy(() => import('../components/pages/ExpertConsultant/ExpertSignUp4'));
const ExpertSignUp5 = lazy(() => import('../components/pages/ExpertConsultant/ExpertSignUp5'));
const ExpertEmployedSignup4 = lazy(() => import('../components/pages/ExpertConsultant/ExpertEmployedSignup4'));
const ExpertAvailabilitySignUp5 = lazy(() => import('../components/pages/ExpertConsultant/ExpertAvailabilitySignUp5'));

const publicRoutes = [
  {
    path: '/',
    element: <LandingPage />,
    authorized: false,
    name: "LANDING PAGE"
  },
  {
    path: '/login-as',
    element: <LoginAs />,
    authorized: false,
    name: "LOGIN AS"
  },
  {
    path: '/login-as-expert',
    element: <ExpertLogin />,
    authorized: false,
    name: "EXPERT LOGIN"
  },
  {
    path: '/login-as-patient',
    element: <PatientLogin />,
    authorized: false,
    name: "PATIENT LOGIN"
  },
  {
    path: '/forgot-password',
    element: <Forgot />,
    authorized: false,
    name: "FORGOT PASSWORD"
  },
  {
    path: '/otp',
    element: <Otp />,
    authorized: false,
    name: "OTP"
  },
  {
    path: '/reset-password',
    element: <ResetPassword />,
    authorized: false,
    name: "RESET PASSWORD"
  },
  {
    path: '/signup-as-patient-1',
    element: <PatientSignup1 />,
    authorized: false,
    name: "PATIENT SIGNUP 1"
  },
  {
    path: '/signup-as-patient-1/:email',
    element: <PatientSignup1 />,
    authorized: false,
    name: "PATIENT SIGNUP 1"
  },
  {
    path: '/signup-as-patient-2',
    element: <PatientSignup2 />,
    authorized: false,
    name: "PATIENT SIGNUP 2"
  },
  {
    path: '/signup-as-patient-3',
    element: <PatientSignup3 />,
    authorized: false,
    name: "PATIENT SIGNUP 3"
  },
  {
    path: '/signup-as-expert-1',
    element: <ExpertSignUp1 />,
    authorized: false,
    name: "EXPERT SIGNUP"
  },
  {
    path: '/signup-as-expert-1/:email',
    element: <ExpertSignUp1 />,
    authorized: false,
    name: "EXPERT SIGNUP"
  },
  {
    path: '/signup-as-expert-2',
    element: <ExpertSignUp2 />,
    authorized: false,
    name: "EXPERT SIGNUP 2"
  },

  {
    path: "/signup-as-expert-3",
    element: <ExpertSignUp3 />,
    authorized: false,
    name: "Expert Professional 3"
  },
  {
    path: '/signup-as-expert-4',
    element: <ExpertEmployedSignup4 />,
    authorized: false,
    name: "EXPERT SIGNUP 4"
  },
  {
    path: '/signup-as-expert-5',
    element: <ExpertAvailabilitySignUp5 />,
    authorized: false,
    name: "EXPERT SIGNUP 5"
  },
  {
    path: '/signup-as-expert-6',
    element: <ExpertSignUp4 />,
    authorized: false,
    name: "EXPERT SIGNUP 6"
  },

  {
    path: '/signup-as-expert-7',
    element: <ExpertSignUp5 />,
    authorized: false,
    name: "EXPERT SIGNUP 7"
  },

  // CPN Routing
  {
    path: "/login-as-cpn",
    element: <CpnLogin />,
    authorized: false,
    name: "CPN LOGIN"
  },
  {
    path: '/signup-as-cpn-1',
    element: <CpnSignUp1 />,
    authorized: false,
    name: "CPN SIGNUP 1"
  },
  {
    path: '/signup-as-cpn-1/:email',
    element: <CpnSignUp1 />,
    authorized: false,
    name: "CPN SIGNUP 1"
  },
  {
    path: "/signup-as-cpn-2",
    element: <CpnSignUp2 />,
    authorized: false,
    name: "CPN SIGNUP 2"
  },
  {
    path: "/signup-as-cpn-3",
    element: <CpnSignUp3 />,
    authorized: false,
    name: "CPN SIGNUP 3"
  },
  {
    path: '/*',
    element: <PageNotFound />,
  },


]
export default publicRoutes;
