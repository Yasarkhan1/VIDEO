import { createSlice } from '@reduxjs/toolkit';

const allDropDown = createSlice({
    name: 'allDropDown',
    initialState: {
        data: null,
    },
    reducers: {
        setAllDropDown: (state, action) => {
            state.data = action.payload;
        },
    },
});

export const { setAllDropDown } = allDropDown.actions;
export default allDropDown.reducer;