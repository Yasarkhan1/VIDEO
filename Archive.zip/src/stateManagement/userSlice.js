import { createSlice } from '@reduxjs/toolkit';

const userSlice = createSlice({
  name: 'user',
  initialState: {
    data: null,
    expertUser: null, // New variable to store expert user data
    cpnIsUser: null,  // New variable to store cpnIs user data
  },
  reducers: {
    setUser: (state, action) => {
      state.data = action.payload;
    },
    setExpertUser: (state, action) => {
      state.expertUser = action.payload;
    },
    setCpnIsUser: (state, action) => {
      state.cpnIsUser = action.payload;
    },
  },
});

export const { setUser, setExpertUser, setCpnIsUser } = userSlice.actions;
export default userSlice.reducer;
