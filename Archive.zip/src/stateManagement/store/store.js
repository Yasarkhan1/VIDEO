import { configureStore } from '@reduxjs/toolkit';
import userReducer from '../userSlice';
import dropdownOptionsReducer from '../allDropDownSlice';

const store = configureStore({
  reducer: {
    user: userReducer,
    allDropDown: dropdownOptionsReducer,
  },
});

export default store;