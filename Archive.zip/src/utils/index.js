export const getSessionStorageOrDefault = (key, defaultValue = null) => {
  const stored = JSON.parse(sessionStorage.getItem(key));
  if (!stored || stored === "undefined") {
    return defaultValue;
  }
  return JSON.parse(stored);
};

export const saveToSessionStorage = (key, value) => {
  sessionStorage.setItem(key, JSON.stringify(value));
};

export const logOutManage = () => {
  sessionStorage.clear();
  localStorage.clear();
};

export const checkSpace = (e) => {
  let input = e.target;
  // let val = input.value;
  // let end = input.selectionEnd;
  let start = input.selectionStart;
  if (e.which === 32 && start === 0) {
    e.preventDefault();
  } else if (e.which === 32 && e.target.value.substr(-1) === " ") {
    e.preventDefault();
  }
};

export const numberCheck = (e) => {
  // var k;
  let re;
  if (e.target.value.length > 0) {
    re = /^[0-9]*$/g;
  } else {
    re = /^[1-9]*$/g;
  }
  if (!re.test(e.key)) {
    e.preventDefault();
  }
};

export const otpCheck = (event) => {
  let re;
  if (event?.key === "-" || event?.key === "+") {
    event.preventDefault();
  }
  if (event.target.value.length > 5) {
    event.preventDefault();
  }
  if (event.target.value.length > 0) {
    re = /^[0-9]*$/g;
  } else {
    re = /^[0-9]*$/g;
  }
  if (!re.test(event.key)) {
    event.preventDefault();
  }
};

export const detectPlatform = () => {
  const userAgent = window.navigator.userAgent.toLowerCase();

  if (userAgent.includes("android")) {
    return "Android";
  } else if (userAgent.includes("iphone") || userAgent.includes("ipad")) {
    return "iOS";
  } else {
    return "WEB";
  }
};