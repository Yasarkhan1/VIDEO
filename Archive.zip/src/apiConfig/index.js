import axios from "axios";
import { getSessionStorageOrDefault } from "../utils";

const baseURL = `${process.env.REACT_APP_CPN_BACKEND_BASE_URL}`;
// REACT_APP_CPN_BACKEND_BASE_URL= http://3.111.156.172:8800/api/
// console.log("baseURL==",baseURL);
// Add a request interceptor
axios.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token");
    if (token) {
      // config.headers["Authorization"] = "Bearer " + token;
      config.headers["x-access-token"] = token;
    }
    return config;
  },
  (error) => {
    Promise.reject(error);
  }
);

axios.interceptors.response.use(
  (response) => {
    if (response && response.data.responseCode === 401) {
      // window.localStorage.clear();
      window.location.pathname = "/";
      window.location.reload();
      window.sessionStorage.clear();
    }
    return response;
  },
  function (error) {

    if (error && error.response && error.response.status === 401) {
      // window.localStorage.clear();
      window.sessionStorage.clear();
      window.location.href = "/";
      window.location.reload();
    }
    // Do something with response error
    return Promise.reject(error);
  }
);


export async function getForm(uri, authName) {
  try {
    const { data, status } = await axios.get(`${baseURL}` + uri, {
      headers: {
        'x-access-token': ` ${JSON.parse(sessionStorage.getItem(authName))}`
      },
    });
    return {
      data,
      status,
    };
  } catch (error) {
    if (error?.response?.data && error?.response?.data?.responseMessage) {
      return {
        data: { responseMessage: error?.response?.data?.responseMessage },
        status: error?.response?.status,
      };
    }
    return {
      data: {},
      status: 404,
    };
  }
}

export async function postByFormData(uri, payload, authName) {
  try {
    const { data, status } = await axios.post(`${baseURL}` + uri, payload, {

      // headers: { Authorization: `Bearer ${getSessionStorageOrDefault(authName)}`},
      headers: {
        "Content-type": "multipart/form-data",
        'x-access-token': `${JSON.parse(sessionStorage.getItem(authName))}`
      },
    });

    return {
      data,
      status,
    };
  } catch (error) {
    console.log("error===", error);
    if (error?.response?.data && error?.response?.data?.responseMessage) {
      return {
        data: { responseMessage: error?.response?.data?.responseMessage },
        status: error?.response?.status,
      };
    }
    return {
      data: {},
      status: 404,
    };
  }
}

export async function postForm(uri, payload, authName) {
  try {
    const { data, status } = await axios.post(`${baseURL}` + uri, payload, {

      // headers: { Authorization: `Bearer ${getSessionStorageOrDefault(authName)}`},
      headers: {

        'Content-Type': 'application/json',
        // "Content-type": "multipart/form-data",
        'x-access-token': ` ${JSON.parse(sessionStorage.getItem(authName))}`
      },
    });

    return {
      data,
      status,
    };
  } catch (error) {
    console.log("error===", error);
    if (error?.response?.data && error?.response?.data?.responseMessage) {
      return {
        data: { responseMessage: error?.response?.data?.responseMessage },
        status: error?.response?.status,
      };
    }
    return {
      data: {},
      status: 404,
    };
  }
}


export async function patchForm(uri, payload, authName) {
  try {
    const { data, status } = await axios.patch(`${baseURL}` + uri, payload, {
      headers: {
        'Content-Type': 'application/json',
        'x-access-token': `  ${JSON.parse(sessionStorage.getItem(authName))}`
      },
    });

    return {
      data,
      status,
    };
  } catch (error) {
    if (error.response && error.response.data) {
      return {
        data: error.response.data,
        status: error.response.status,
      };
    }
    return {
      data: {},
      status: 404,
    };
  }
}

export async function patchByFormData(uri, payload, authName) {
  try {
    const { data, status } = await axios.patch(`${baseURL}` + uri, payload, {
      headers: {
        "Content-type": "multipart/form-data",
        'x-access-token': `  ${JSON.parse(sessionStorage.getItem(authName))}`
      },
    });

    return {
      data,
      status,
    };
  } catch (error) {
    if (error.response && error.response.data) {
      return {
        data: error.response.data,
        status: error.response.status,
      };
    }
    return {
      data: {},
      status: 404,
    };
  }
}

export async function putForm(uri, payload, authName) {
  try {
    const { data, status } = await axios.put(`${baseURL}` + uri, payload, {
      headers: {
        token: getSessionStorageOrDefault(authName),
      },
    });

    return {
      data,
      status,
    };
  } catch (error) {
    if (error.response && error.response.data) {
      return {
        data: error.response.data,
        status: error.response.status,
      };
    }
    return {
      data: {},
      status: 404,
    };
  }
}

export async function axiosGet(uri, authName) {
  try {
    const { data, status } = await axios.get(`${baseURL}` + uri, {
      headers: { Authorization: `Bearer ${getSessionStorageOrDefault(authName)}` },
    });

    return {
      data,
      status,
    };
  } catch (error) {
    if (error.response && error.response.data) {
      return {
        data: error.response.data,
        status: error.response.status,
      };
    }
    return {
      data: {},
      status: 404,
    };
  }
}

export async function deleteForm(uri, payload, authName) {
  console.log("uri, payload, authName", uri, payload, authName);
  try {
    const { data, status } = await axios.delete(`${baseURL}` + uri, {
      data: payload,
      headers: { Authorization: `Bearer ${getSessionStorageOrDefault(authName)}` },
    });

    return {
      data,
      status,
    };
  } catch (error) {
    if (error.response && error.response.data) {
      return {
        data: error.response.data,
        status: error.response.status,
      };
    }
    return {
      data: {},
      status: 404,
    };
  }
}