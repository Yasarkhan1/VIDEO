/ eslint-disable no-undef /
importScripts("https://www.gstatic.com/firebasejs/8.9.1/firebase-app.js");
importScripts("https://www.gstatic.com/firebasejs/8.9.1/firebase-messaging.js");

// Initialize Firebase
firebase.initializeApp({
    // cpn credentials

    apiKey: `AIzaSyBD5204r4CI_STvHxzcZfpWxeB2sql4IAw`,
    authDomain: `cpn-health.firebaseapp.com`,
    projectId: `cpn-health`,
    storageBucket: `cpn-health.appspot.com`,
    messagingSenderId: `923376313938`,
    appId: '1:923376313938:web:3967e77e2f7f661051a18b',
    measurementId: 'G-R4GEQEBWV7'

    //gymdoc credentials
    // apiKey: `AIzaSyATz3lpNEJKLYbTVFpb-Yn30q15Htd4qp4`,
    // authDomain: `gymdoctor.firebaseapp.com`,
    // projectId: `gymdoctor`,
    // storageBucket: `gymdoctor.appspot.com`,
    // messagingSenderId: `51684953869`,
    // appId: '1:51684953869:web:782b536cbb62b952c9aa4',
    // measurementId: 'G-9KY6PJ8NNY'
});

const FirebaseMessaging = firebase.messaging();

FirebaseMessaging.onBackgroundMessage(function (payload) {
    console.log('Received background message ', payload);

    const notificationTitle = payload.data?.notification ? JSON.parse(payload.data.notification).title : "";
    const notificationOptions = {
        body: payload.data?.notification ? JSON.parse(payload.data.notification).body : ""
    };

    self.registration.showNotification(notificationTitle,
        notificationOptions);
})


